# UI, UX & Accessibility Audit

## 1. 감사 근거

UI 평가는 다음을 결합했다.

- SwiftUI/UIView 코드의 레이아웃·폰트·컴포넌트·상태 처리
- `DESIGN.md`, 토큰/UI specification 문서
- 저장소가 보관한 iOS QA 증거 화면: Inbox, Settings dark, Folders dark, Share Extension, App Lock, full-screen image viewer
- Apple Human Interface Guidelines, Dynamic Type, VoiceOver 및 WCAG 2.2 원칙

`[검증 필요]` 실제 터치·VoiceOver rotor·Reduce Motion·Switch Control·색 대비 수치는 simulator/실기기에서 재검증해야 한다.

## 2. 화면 인벤토리

| 화면/상태 | 목적 | 주요 요소 | 진입 | 종료 | 핵심 문제 |
|---|---|---|---|---|---|
| Inbox | 저장 항목 훑기 | 제목, 필터 grid, list rows, bottom tabs | 앱 기본 | 상세/탭 | 빈 상태·sample 구분, 5열 고정 필터 |
| Clip Detail | 내용 확인·편집·열기 | preview, metadata, tags, memo, actions | Inbox/Search/Folder | Back | 고정 높이, 오류/저장 상태, 링크 신뢰 |
| Search | 전체 검색 | field, recent queries, results | bottom tab | 상세/탭 | substring 중심, filter scope 부족 |
| Folders | 폴더 목록·관리 | folder rows/counts, add/rename | bottom tab | folder content | 삭제/병합 정책·iPad sidebar 부재 |
| Folder Detail | 폴더 항목 | filtered clip list | folder row | detail/back | smart view와 정보 구조 중복 |
| Add | 앱 내 캡처 | 현재 workflow sheet/CTA | center tab | save/cancel | 실제 입력이 아닌 demo clip 생성 |
| Sort Later | 미정리 항목 분류 | clip, destination, tags | CTA/action | next/done | batch triage 없음 |
| Settings | 앱 설정·데이터 관리 | theme, language, lock, share mode, import/export, danger zone | bottom tab | subflows | 설정 저장 실패 가시성·storage dashboard 없음 |
| Tag Management | tag add/rename/delete | rows/editor | Settings/detail | back | 영향 미리보기·Undo 부족 |
| App Lock | 인증 전 차단 | icon, title, unlock CTA/error | launch/foreground | 인증 성공 | fail-open, app switcher shield 없음 |
| Share Quick | 즉시 캡처 | compact saved feedback | iOS Share Sheet | host return | 2초 고정 지연, timeout/error semantics |
| Share Review | 캡처 검토 | preview, folder, tags/memo, save | iOS Share Sheet | host return | custom accessibility·keyboard·long content |
| Import | JSON 선택·적용 | file picker/confirmation | Settings | success/error | version/preview/rollback 부족 |
| Export | backup 공유 | share sheet | Settings | dismiss | 평문/범위 고지 부족 |
| Delete Confirmation | 파괴 행동 확인 | warning/actions | row/detail/settings | cancel/delete | 영구 삭제, 복구 없음 |
| Toast/Banner | 작업 피드백 | transient text | mutations | timeout | 실패와 성공 구분, VoiceOver 공지 |
| Full-screen Image | 확대 보기 | image, close, zoom | detail | close/back | zoom 후 pan·controls·a11y 보강 |
| Loading/Recovery | 저장소 초기화/복구 | 현재 명확한 전용 화면 미확인 | launch | ready/retry | degraded/recovery state가 없음 |
| Empty | 첫 사용/검색 없음 | 현재 evidence 제한 | no data/no result | capture/filter reset | 행동 중심 안내 필요 |

## 3. 비주얼 디자인 평가

### 강점

- `[확인됨]` 따뜻한 아이보리 배경과 노란 accent가 기억 가능한 브랜드 톤을 만든다.
- `[확인됨]` 최신 evidence의 list-first Inbox는 초기 카드 중심 UI보다 정보 밀도와 스캔 효율이 개선됐다.
- `[확인됨]` 다크 Settings/Folders에서 표면·구분선·강조 색이 비교적 일관된다.
- `[확인됨]` 폴더·설정 행을 공통 컴포넌트로 통합하려는 흔적이 있어 시각 정렬이 안정적이다.
- `[확인됨]` bottom tab의 5개 핵심 영역은 제품 구조를 빠르게 이해하게 한다.

### 약점

- `[확인됨]` 타이포그래피가 semantic text style보다 고정 `Font.custom(..., size:)` 중심이다.
- `[확인됨]` 5열×2행 선택기는 12pt 안팎 텍스트를 축소하며 `minimumScaleFactor`에 의존한다. 이는 “맞춰 넣기”이지 적응형 설계가 아니다.
- `[확인됨]` 여러 행·preview·editor가 고정 높이를 사용해 큰 글자와 긴 콘텐츠를 레이아웃이 아닌 잘림/축소로 해결한다.
- `[검증 필요]` tertiary gray, muted yellow, dark surface 조합의 실제 대비 측정 결과가 없다.
- `[추정]` 중앙 Add가 핵심 CTA처럼 강조되지만 실제로는 demo를 생성하므로 시각 계층이 잘못된 기능을 과도하게 약속한다.
- `[추정]` 작은 ellipsis, close, chip은 시각 크기뿐 아니라 hit target도 부족할 수 있다.

## 4. 디자인 시스템 감사

### 현재 있는 것

- 컬러·spacing·corner·typography에 해당하는 token 구조
- Pretendard Regular/SemiBold/Bold 번들
- 라이트/다크 theme
- 공통 destination row/divider, chip, button, card 계열
- 일관된 yellow accent와 warm neutral surface

### 부족한 것

| 토큰/규칙 | 현재 위험 | 권장 정의 |
|---|---|---|
| Semantic typography | fixed pixel size | `.title`, `.headline`, `.body`, `.caption`, `.button`을 Dynamic Type relative style로 정의 |
| Minimum hit area | 일부 40pt | 모든 interactive primitive 44×44 이상 |
| Content width | phone 기준 고정 | compact/regular width, iPad max readable width, split-view rules |
| State colors | success/error/warning/disabled 근거 부족 | light/dark/high-contrast pair와 텍스트 대비 수치 문서화 |
| Motion | transition 규칙 불명확 | duration/easing, Reduce Motion 대체, haptic policy |
| Focus/accessibility | custom component 규칙 부족 | label/value/hint/trait/focus order contract |
| Empty/error/loading | 화면별 임시 구현 가능성 | 공통 `StateView` + primary/secondary action |
| Iconography | 시스템/custom 사용 규칙 불명확 | SF Symbols 우선, 크기·weight·mirroring·label 규칙 |
| Destructive action | 영구 삭제 중심 | danger hierarchy + Undo/Trash standard |

### 제안하는 최소 semantic token

```swift
enum AppTextStyle {
    case screenTitle, sectionTitle, rowTitle, body, metadata, chip, button
}

extension Font {
    static func app(_ style: AppTextStyle) -> Font {
        switch style {
        case .screenTitle: return .custom("Pretendard-Bold", size: 28, relativeTo: .largeTitle)
        case .sectionTitle: return .custom("Pretendard-SemiBold", size: 17, relativeTo: .headline)
        case .rowTitle: return .custom("Pretendard-SemiBold", size: 15, relativeTo: .body)
        case .body: return .custom("Pretendard-Regular", size: 15, relativeTo: .body)
        case .metadata: return .custom("Pretendard-Regular", size: 13, relativeTo: .caption)
        case .chip: return .custom("Pretendard-SemiBold", size: 13, relativeTo: .callout)
        case .button: return .custom("Pretendard-SemiBold", size: 16, relativeTo: .headline)
        }
    }
}
```

고정 frame 대신 `minHeight`, `fixedSize(horizontal:false, vertical:true)`, `ViewThatFits`, `DynamicTypeSize`별 layout variant를 사용한다.

## 5. 정보 구조

### 현재 구조

- Inbox
- Folders
- Add
- Search
- Settings

이 구조 자체는 단순하지만, Inbox 상단에 **타입 + 고정 태그 + 미정리**가 함께 놓여 있고, Folders와 Tags가 별도 관리되며, Bookmark는 직접 목적지가 약하다.

### 권장 구조

```text
Library
├── Inbox (all active)
├── Unsorted
├── Favorites
├── Recent
├── Images / Links / Text
├── Folders
└── Trash

Capture
├── Manual Add
└── Share Extension Guide

Search
└── Query + type/folder/tag/date filters

Settings
├── Capture behavior
├── Privacy & Lock
├── Storage & Retention
├── Backup & Restore
├── Appearance & Language
└── Help & Privacy
```

bottom tab는 Inbox / Folders(or Library) / Add / Search / Settings로 유지할 수 있다. 단, Inbox 상단 10개 고정 chip을 smart-filter horizontal row 또는 filter button/sheet로 단순화한다.

## 6. 핵심 UX 문제

### 6.1 핵심 CTA와 실제 기능 불일치

중앙 Add는 사용자가 새 콘텐츠를 넣는 가장 강한 affordance다. 실제 구현이 하드코딩 샘플을 생성하면 제품 전체 신뢰가 깨진다.

- 해결 A: URL, Text, Photo, Memo 4개 quick add
- 해결 B: Add 탭을 “Share Guide”로 바꾸고 수동 입력을 넣지 않음
- 권장: A. Share Sheet가 주 경로여도 앱 내부의 탈출구는 있어야 한다.

### 6.2 첫 성공까지의 발견성

사용자는 앱 설치만으로 Share Extension이 자동 노출·상단 고정되는 방식을 알지 못한다.

**온보딩 제안**

1. “어디서든 공유 → Clip Inbox” 한 문장
2. 애니메이션이 아닌 실제 3컷 정적 가이드
3. Quick/Review 선택
4. “연습용 링크 저장” 또는 수동 URL 입력
5. 성공 후 Inbox에서 항목 하이라이트

건너뛰기와 설정에서 다시 보기 기능을 제공한다.

### 6.3 저장 신뢰

성공 토스트는 파일 commit 후에만 나와야 한다. 저장이 실패하면 기술 오류보다 사용자 행동을 제시한다.

- “저장하지 못했습니다. 기기 저장 공간을 확인한 뒤 다시 시도하세요.”
- “복구 가능한 임시 항목 1개가 있습니다.”
- “백업에서 23개 항목을 복구했습니다. 손상 파일은 내보낼 수 있습니다.”

### 6.4 삭제 복구

- row swipe 또는 menu Delete → 즉시 soft-delete
- 6초 Undo banner
- Trash에서 복원/영구 삭제
- 이미지 파일은 retention 종료 후 삭제
- Delete All은 내보내기 제안, typed confirmation, transaction

### 6.5 분류 부담

캡처 순간에는 폴더·태그를 강제하지 않는다. Quick save의 기본은 Inbox이고, Review는 사용자가 원할 때만 확장한다. 나중 정리 화면에서 최근 폴더, 추천 태그, swipe action을 제공한다.

## 7. 접근성 감사

### 7.1 Dynamic Type

- `[확인됨]` fixed custom font와 `minimumScaleFactor`가 많다.
- `[확인됨]` row/preview/editor 고정 높이가 있다.
- 결과: 큰 글자에서는 정보가 축소되거나 잘리고, target 사이 간격이 부족할 수 있다.

**출시 기준:** iOS의 가장 큰 accessibility size에서도 저장·검색·삭제 복구·설정을 완료할 수 있어야 한다. 한 화면에 모든 것을 우겨 넣는 목표는 버리고 vertical scroll/reflow를 허용한다.

### 7.2 VoiceOver

- custom Share Extension UI와 custom chips는 label/value/selected trait/announcement를 명시해야 한다.
- 저장 성공, 오류, 태그 선택, 폴더 이동, 잠금 상태는 시각 토스트만으로 전달하지 않는다.
- 이미지 label은 “이미지”만이 아니라 클립 제목·출처·상태를 조합한다.
- ellipsis menu는 “더 보기” 대신 “{클립 제목} 작업”으로 context를 제공한다.

### 7.3 터치와 운동 접근성

- `[확인됨]` design token의 chip target 40은 44pt 권장 기준에 못 미친다.
- 모든 작은 icon에는 padding을 포함한 44pt `contentShape`를 보장한다.
- custom edge swipe가 AssistiveTouch/ScrollView와 충돌하지 않는지 확인한다.
- Reduce Motion이 켜지면 확대·전환을 fade/cross-dissolve로 대체한다.

### 7.4 색과 대비

- text contrast는 normal text 4.5:1, large text 3:1을 기본 목표로 한다.
- 색만으로 selected/error 상태를 표현하지 않는다. checkmark, border, label을 병행한다.
- Increase Contrast 환경에서 token override를 제공한다.

### 7.5 다국어와 방향성

- 한국어/영어/일본어가 구현됐으나, 고정 5열은 영어에서 취약하다.
- pseudo-localization 40% expansion을 CI snapshot에 넣는다.
- 하드코딩 한국어 accessibility label을 제거한다.
- 향후 RTL을 당장 지원하지 않더라도 leading/trailing과 SF Symbol mirroring을 깨지 않도록 한다.

## 8. UX 문제 우선순위

| 문제 | 사용자 영향 | 빈도 | 심각도 | 난이도 | 우선순위 | 제안 |
|---|---|---:|---:|---:|---:|---|
| Add가 demo 생성 | 매우 큼 | 높음 | 10 | M | P0 | 실제 capture form |
| 저장 실패 false-success | 매우 큼 | 낮음~중간 | 10 | L | P0 | transaction + durable feedback |
| 온보딩 없음 | 큼 | 첫 사용자 모두 | 9 | M | P1 | guided first capture |
| 영구 삭제 | 큼 | 중간 | 9 | M | P1 | Undo + Trash |
| Dynamic Type 취약 | 큼 | 접근성 사용자 | 9 | L | P1 | semantic typography/reflow |
| 잠금 preview/fail-open | 매우 큼 | 조건부 | 10 | M | P0/P1 | fail-closed + shield |
| 이미지 무제한 | 큼 | 이미지 사용자 | 9 | L | P0/P1 | cap/optimize/storage UI |
| 5열 필터 | 중간 | 높음 | 7 | M | P1 | adaptive chips/filter sheet |
| 검색 기능 제한 | 중간 | 반복 | 6 | L | P2 | scoped/tokenized search |
| Sort Later 단건 | 중간 | backlog 사용자 | 6 | L | P2 | batch/swipe triage |
| iPad 단일 컬럼 | 중간 | iPad 사용자 | 6 | L | P2 | NavigationSplitView |
| 이미지 viewer pan 부족 | 낮음~중간 | 이미지 사용자 | 5 | M | P2 | scroll-based zoom viewer |

## 9. UI/UX 최종 판정

**시각적 토대는 유지할 가치가 있다.** 새로운 디자인을 전면 재작업하기보다, 현재 브랜드와 리스트 UI를 보존하면서 다음을 바꾼다.

1. fixed-size 디자인을 semantic/adaptive system으로 전환
2. Add/Onboarding/Empty/Recovery 같은 “제품 의미 화면” 완성
3. 영구 행동을 Undo/Trash로 전환
4. 저장·잠금·export에 신뢰 메시지 추가
5. iPad·VoiceOver·큰 글자를 release gate로 승격

이 작업이 끝나면 현재 74점 수준의 시각 디자인이 실제 UX·접근성 품질과 일치하게 된다.
