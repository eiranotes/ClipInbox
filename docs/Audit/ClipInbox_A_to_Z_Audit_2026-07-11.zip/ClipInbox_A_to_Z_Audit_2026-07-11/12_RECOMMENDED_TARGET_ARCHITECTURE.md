# Recommended Target Architecture

## 1. 목표

현재 앱을 전면 재작성하지 않고 다음 속성을 만든다.

1. 저장 성공과 UI 성공이 동일한 의미를 가진다.
2. 손상·미지원 버전·부분 실패를 복구할 수 있다.
3. Share Extension과 앱의 자산 생명주기가 idempotent하다.
4. UI는 파일 시스템·App Group 세부 구현을 모른다.
5. 저장 backend를 snapshot에서 SQLite/SwiftData로 바꿔도 화면을 다시 쓰지 않는다.
6. 테스트가 disk full, timeout, corruption, clock, ID를 결정적으로 재현한다.
7. local-only·privacy 원칙을 모듈 경계에 반영한다.

## 2. 권장 계층

```text
┌─────────────────────────────────────────────────────┐
│ Presentation                                        │
│ SwiftUI Screens / Share UIKit / ViewModels          │
└───────────────────┬─────────────────────────────────┘
                    │ user intents / view state
┌───────────────────▼─────────────────────────────────┐
│ Application                                         │
│ CaptureClip, UpdateClip, Delete/Restore, Search,    │
│ Import/Export, RecoverStore, ManagePreferences      │
└───────────────────┬─────────────────────────────────┘
                    │ domain protocols
┌───────────────────▼─────────────────────────────────┐
│ Domain                                              │
│ Clip, Folder, Tag, CapturePayload, DeletionState,   │
│ Stable enums, validation rules, errors              │
└───────────────────┬─────────────────────────────────┘
                    │ repository interfaces
┌───────────────────▼─────────────────────────────────┐
│ Infrastructure                                      │
│ File/SQLite Repository, Snapshot Codec/Migrator,    │
│ Shared Queue, Image Store, Preferences, OSLog       │
└───────────────────┬─────────────────────────────────┘
                    │
┌───────────────────▼─────────────────────────────────┐
│ Platform                                            │
│ FileManager, App Group, LocalAuthentication,        │
│ NSItemProvider, PhotosPicker, UIApplication         │
└─────────────────────────────────────────────────────┘
```

## 3. 모듈/타깃 제안

초기에는 Xcode target을 과도하게 늘리지 않고 폴더·Swift package 경계로 시작한다.

```text
ios/
├── App/
│   ├── ClipInboxApp.swift
│   ├── AppCoordinator.swift
│   └── AppEnvironment.swift
├── Domain/
│   ├── Models/
│   │   ├── Clip.swift
│   │   ├── Folder.swift
│   │   ├── Tag.swift
│   │   └── Preferences.swift
│   ├── Errors/
│   └── Validation/
├── Application/
│   ├── UseCases/
│   │   ├── CaptureClip.swift
│   │   ├── UpdateClip.swift
│   │   ├── DeleteClip.swift
│   │   ├── RestoreClip.swift
│   │   ├── ImportArchive.swift
│   │   └── RecoverLibrary.swift
│   └── Ports/
│       ├── ClipRepository.swift
│       ├── ImageStore.swift
│       ├── CaptureQueue.swift
│       ├── PreferencesStore.swift
│       └── Diagnostics.swift
├── Infrastructure/
│   ├── Persistence/
│   │   ├── FileClipRepository.swift
│   │   ├── SQLiteClipRepository.swift       # 필요 시 후속
│   │   ├── SnapshotCodec.swift
│   │   ├── SnapshotMigrator.swift
│   │   └── SnapshotRecovery.swift
│   ├── Assets/
│   │   ├── AppGroupImageStore.swift
│   │   └── ThumbnailPipeline.swift
│   ├── Sharing/
│   │   └── FileCaptureQueue.swift
│   ├── Settings/
│   └── Logging/
├── Features/
│   ├── Inbox/
│   ├── Detail/
│   ├── Capture/
│   ├── Search/
│   ├── Library/
│   ├── Trash/
│   ├── Settings/
│   ├── Onboarding/
│   └── Recovery/
├── DesignSystem/
│   ├── Tokens/
│   ├── Components/
│   └── Accessibility/
├── SharedContract/                     # 앱+extension에서 빌드
│   ├── CapturePayload.swift
│   ├── CaptureConfiguration.swift
│   └── QueueEnvelope.swift
├── ClipShareExtension/
│   ├── ShareCoordinator.swift
│   ├── ProviderLoader.swift
│   ├── ImageIngestor.swift
│   └── ShareViewController.swift
└── Tests/
    ├── Unit/
    ├── Integration/
    ├── UI/
    ├── Fixtures/
    └── Performance/
```

## 4. 핵심 protocol

```swift
protocol ClipRepository: Sendable {
    func bootstrap() async throws -> BootstrapResult
    func readLibrary() async throws -> LibrarySnapshot
    func transaction<T: Sendable>(
        _ operation: @Sendable (inout LibraryDraft) throws -> T
    ) async throws -> TransactionResult<T>
}

protocol CaptureQueue: Sendable {
    func enqueue(_ envelope: CaptureEnvelope) async throws
    func pending() async throws -> [QueuedCapture]
    func acknowledge(_ id: UUID) async throws
    func quarantine(_ id: UUID, reason: QueueFailure) async throws
    func reconcile() async throws -> QueueHealth
}

protocol ImageStore: Sendable {
    func stage(_ source: ImageSource, policy: ImagePolicy) async throws -> StagedImage
    func commit(_ staged: StagedImage, ownerID: Clip.ID) async throws -> ImageAsset
    func rollback(_ staged: StagedImage) async
    func delete(_ asset: ImageAsset) async throws
    func thumbnail(for asset: ImageAsset, targetPixels: CGSize) async throws -> CGImage
}
```

### 계약 원칙

- `transaction` 밖에서 in-memory 모델을 먼저 변경하지 않는다.
- 성공은 current state가 durable하고 다시 decode/validate 가능한 상태를 뜻한다.
- image/queue/clip은 idempotency key를 공유한다.
- 오류는 사용자 행동으로 매핑 가능한 typed category를 가진다.
- UI는 Bool `persist()`를 호출하지 않는다.

## 5. 데이터 모델

### Clip

```swift
struct Clip: Identifiable, Codable, Sendable, Equatable {
    typealias ID = UUID

    let id: ID
    var kind: ClipKind
    var createdAt: Date
    var updatedAt: Date
    var source: SourceMetadata
    var content: ClipContent
    var folderID: Folder.ID?
    var tagIDs: Set<Tag.ID>
    var isFavorite: Bool
    var sortingState: SortingState
    var deletion: DeletionState
    var assetIDs: [ImageAsset.ID]
}
```

### Stable enum

```swift
enum ThemePreference: String, Codable {
    case system, light, dark
}

enum ShareSaveMode: String, Codable {
    case quick, review
}
```

번역 문자열은 `L10n`에서 만들며 raw storage에 한국어 “켬/끔”을 저장하지 않는다.

### Date

- `createdAt`, `updatedAt`, optional `capturedAt`, `deletedAt`
- JSON에서는 ISO 8601 with fractional seconds 또는 epoch; 한 방식으로 고정
- 상대 시간은 렌더링 시 계산

### IDs와 참조

- Clip/Folder/Tag/Image는 UUID
- 삭제된 folder/tag 참조 migration 규칙
- import 시 external ID namespace 또는 remap table
- 중복 canonical key는 별도 index

## 6. Snapshot 포맷

내부 snapshot을 당분간 유지한다면 다음 envelope를 쓴다.

```json
{
  "format": "clipinbox-library",
  "schemaVersion": 3,
  "createdAt": "2026-07-11T00:00:00.000Z",
  "appVersion": "0.4.0",
  "recordCount": 123,
  "payloadChecksum": "sha256:...",
  "payload": {
    "clips": [],
    "folders": [],
    "tags": [],
    "preferences": {}
  }
}
```

### Load state machine

```text
no current
 └─ firstRun(empty library)

valid current
 └─ ready

invalid current + valid previous
 └─ recovered(previous), current quarantined

invalid current + invalid previous
 └─ recoveryRequired (절대 sample로 overwrite하지 않음)

future schema
 └─ updateRequired / unsupportedVersion
```

### Commit algorithm

1. actor에서 current state copy를 draft로 생성
2. operation과 domain validation
3. encode compact
4. decode roundtrip + semantic check
5. temp fsync/atomic write
6. current→previous rotate
7. temp→current replace
8. asset transaction commit
9. state publish
10. previous retention policy 적용

운영체제 API가 명시적 fsync를 추상화하는 수준과 atomic replace semantics는 실제 구현에서 검증한다.

## 7. SQLite/SwiftData 이전 판단

### snapshot 유지가 가능한 조건

- 라이브러리 상한이 명확함(예: 2,000 clips)
- save p95가 성능 예산 내
- 검색 index를 별도 유지 가능
- migration/recovery가 충분히 테스트됨

### DB가 필요한 조건

- “무제한” 보관 마케팅
- 5,000+ clip
- full-text/복합 필터/날짜 정렬
- batch mutation
- sync conflict/versioning
- 부분 로드와 background indexing

### 선택

- Apple-only, 단순 CRUD: SwiftData
- migration/FTS/transaction 세밀 제어: SQLite/GRDB 계열
- 외부 dependency를 피하고 싶다면 SQLite C API wrapper 또는 Core Data도 가능

본 보고서는 특정 라이브러리를 즉시 도입하라고 강제하지 않는다. 먼저 `ClipRepository`를 만들면 backend 선택이 가역적이다.

## 8. Share Extension 설계

```text
NSItemProvider
  └─ ProviderLoader(deadline, cancellation)
      ├─ URL/Text normalizer
      └─ ImageIngestor
          ├─ file representation preferred
          ├─ metadata/byte/pixel validation
          ├─ preview downsample
          └─ staged original/optimized copy
                ↓
         QueueEnvelope + staged asset reference
                ↓ atomic commit
         App Group queue
```

### 제한 정책 예시

- text: 100KB 또는 product-specific cap
- URL: 8KB
- single image: 50MB encoded, 100MP decoded pixel cap 등 실측 기반
- queue: 500 items 또는 2GB 중 먼저 도달
- pending TTL: 30일, 삭제 전 사용자/앱에 diagnostics

숫자는 제품 정책 예시이며 실제 기기 benchmark 후 확정한다.

## 9. Image pipeline

### 저장

- 원본 파일 확장자만 신뢰하지 않고 type sniffing
- staged temporary file
- image metadata validate
- optional optimized copy
- content hash와 pixel dimensions 저장
- clip commit 후 owner reference

### 표시

- 목록은 target-size thumbnail만 decode
- detail도 screen pixel size에 맞춰 downsample
- full-screen에서 필요 시 더 큰 decode
- `NSCache.totalCostLimit`, memory warning purge
- corrupt/missing asset placeholder + repair action

### 삭제

- soft-deleted clip 동안 asset 유지
- trash purge transaction에서 ref count 0인 자산 삭제
- periodic orphan reconciliation

## 10. 검색

### 단기

- Unicode normalization, lowercasing/diacritic folding
- title/source/url/memo/tag token index
- query debounce와 background actor
- folder/type/favorite/date scope

### DB 이후

- FTS table
- canonical URL host index
- exact tag/folder foreign keys
- duplicate hash index
- incremental indexing

검색어와 결과를 외부 서버로 보내지 않는다.

## 11. App Lock/Privacy architecture

```text
LockController state:
disabled
locked(reason)
authenticating
unlocked(sessionExpiry)
errorRecoverable
```

- scene inactive → privacy cover는 lock state와 무관하게 즉시 표시 가능
- background → session expire policy
- capability unavailable → locked/error, never unlocked by default
- repository encryption을 도입하면 lock controller와 key access policy를 분리
- UI는 잠금 전 민감 feature view를 instantiate하지 않거나 redaction layer를 보장

## 12. Presentation state

```swift
enum LibraryViewState {
    case loading
    case ready(LibraryPresentation)
    case empty
    case recovered(RecoveryNotice)
    case degraded(RecoverableProblem)
    case failed(FatalProblem)
}
```

Toast 하나로 모든 상태를 처리하지 않는다. 성공은 accessibility announcement, Undo는 action banner, 복구는 persistent state screen, validation은 inline error로 분리한다.

## 13. 의존성 주입

```swift
struct AppEnvironment {
    let repository: any ClipRepository
    let queue: any CaptureQueue
    let images: any ImageStore
    let preferences: any PreferencesStore
    let lock: LockController
    let clock: any Clock
    let ids: any IDGenerator
    let diagnostics: any Diagnostics
}
```

- production/simulator/preview/test environment
- sample data는 preview environment에만
- release URL/App Group은 generated config
- 테스트는 temporary directory와 deterministic clock/IDs 사용

## 14. 관측성과 개인정보

- OSLog category: bootstrap, transaction, queue, image, import, lock
- 메시지에는 error code, byte bucket, count, duration만
- URL/title/text/tag/folder/path는 `.private` 또는 기록하지 않음
- signpost로 launch/search/save/share duration
- 사용자가 export할 diagnostics는 redacted summary

## 15. 단계적 이전

### Migration 0 — Characterization

현재 성공 흐름을 테스트로 고정한다. 단, false-success 같은 버그를 expected behavior로 고정하지 않는다.

### Migration 1 — Interface wrapping

현재 JSON/queue 구현을 protocol 뒤에 감싼다. UI 동작은 유지한다.

### Migration 2 — Typed model

localized strings→enum, `time`→Date, Int ID→UUID를 schema migrator로 이전한다.

### Migration 3 — Transaction/recovery

모든 mutation과 image lifecycle을 원자적 계약으로 전환한다.

### Migration 4 — UI state/a11y

async state, error/recovery, semantic typography를 적용한다.

### Migration 5 — Backend decision

benchmark 후 snapshot 유지 또는 SQLite repository 추가. 둘 다 같은 use cases를 사용한다.

## 16. 비목표

- Clean Architecture 명칭을 맞추기 위한 과도한 파일 분할
- 모든 protocol을 public framework로 만들기
- 1.0 전에 sync conflict engine 구현
- 단순 설정까지 복잡한 use case 객체로 감싸기
- 현재 잘 작동하는 SwiftUI 화면을 UIKit/타 프레임워크로 재작성

## 17. 목표 아키텍처 완료 기준

- View가 `FileManager`, App Group URL, JSON encoder를 직접 알지 않음
- 모든 mutation failure injection 가능
- 손상/미지원 schema가 sample data로 대체되지 않음
- queue/image/clip commit가 idempotent하고 orphan reconciliation 가능
- AppStore/ViewModel 300줄 이하 또는 책임 기준으로 명확히 분리
- 5k fixture에서 성능 예산 측정 가능
- release archive와 동일 configuration을 CI/QA에서 재현 가능
