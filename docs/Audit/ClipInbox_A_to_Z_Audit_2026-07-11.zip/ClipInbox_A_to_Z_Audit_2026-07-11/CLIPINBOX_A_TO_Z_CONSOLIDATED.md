# ClipInbox A–Z Comprehensive Audit — Consolidated

- Audit date: 2026-07-11
- Verdict: 현재 공개 App Store 출시 부적합 — 주요 수정 후 출시 가능
- Overall score: 58/100

> This file concatenates the 16 numbered reports. Use README.md for navigation.

---

# ClipInbox A–Z 종합 감사 — Executive Summary

- 감사 기준일: 2026-07-11 (Asia/Seoul)
- 대상: `eiranotes/ClipInbox` 공개 저장소 `main` 브랜치
- 제품 기준 소스: `ios/` 네이티브 SwiftUI 앱 및 Share Extension
- 보조 자료: 루트 정적 웹 프로토타입, 저장소 문서, QA 증거 화면, Apple 공식 정책, 경쟁 제품 공식 페이지
- 판정: **현재 공개 App Store 출시 부적합 — 주요 수정 후 출시 가능**
- 종합 점수: **58/100**

> 이 문서의 표식: `[확인됨]` 저장소 코드·설정·문서에서 확인, `[추정]` 정적 분석 기반 판단, `[검증 필요]` macOS/Xcode·실기기·App Store Connect가 필요한 항목, `[중대 위험]` 출시 또는 사용자 데이터에 직접 영향을 줄 수 있는 항목.

## 1. 한 줄 정의

**ClipInbox는 iOS 공유 시트로 사용자가 명시적으로 보낸 링크·텍스트·이미지를 계정과 서버 없이 로컬에 모아 두고, 폴더·태그·검색·Sort Later로 정리하는 프라이버시 중심 캡처 인박스다.**

`ClipInbox`라는 이름 때문에 운영체제 클립보드를 백그라운드에서 자동 수집하는 앱으로 오해될 수 있으나, 현재 프로덕션 구현은 Share Extension 중심이다. 따라서 제품 포지셔닝도 “클립보드 히스토리”보다 **“프라이빗 Share-to-Inbox”**가 정확하고 심사·신뢰 측면에서도 유리하다.

## 2. 현재 상태

### 확인된 구현 범위

- `[확인됨]` SwiftUI iPhone/iPad 앱, UIKit 기반 Share Extension, XcodeGen 프로젝트 정의가 있다.
- `[확인됨]` iOS 17.0+, Swift 5.10, 앱 버전 0.3.0/build 1이다.
- `[확인됨]` 로컬 JSON 스냅샷, App Group 기반 공유 큐, 원본 이미지 파일 저장을 사용한다.
- `[확인됨]` 링크·텍스트·이미지 저장, 폴더·태그·즐겨찾기, 검색, Sort Later, JSON 가져오기/내보내기, 테마·언어, 선택적 앱 잠금이 구현돼 있다.
- `[확인됨]` 한국어·영어·일본어와 라이트·다크 테마를 고려했다.
- `[확인됨]` 외부 런타임 SDK나 서버 의존성이 보이지 않아 데이터 최소화와 공급망 표면이 작다.
- `[확인됨]` 루트 `src/`는 역사적 정적 웹 프로토타입이며, 저장소 지침상 실제 제품 소스는 `ios/`다.

### 독립 검증 제한

- `[검증 필요]` 현재 감사 환경은 macOS/Xcode·iOS Simulator·물리 iPhone을 제공하지 않아, 저장소가 기록한 빌드·시뮬레이터 QA를 독립적으로 재실행하지 못했다.
- `[검증 필요]` 저장소의 자체 증거는 앱/확장 빌드, Safari·Photos 공유 흐름을 통과했다고 기록하지만, 본 보고서에서는 이를 **저장소 작성자의 실행 증거**로만 취급한다.
- `[검증 필요]` App Group 배포 서명, Face ID 등록 기기, App Store Archive/Privacy Report, 메모리 압박 하의 Share Extension은 반드시 별도 검증해야 한다.

## 3. 가장 큰 장점

1. **명확한 로컬 우선 원칙** — 계정·서버·광고·트래킹이 없는 현재 범위는 신뢰와 구현 집중도 면에서 강점이다.
2. **실제 iOS 사용 흐름과 맞는 Share Extension** — iOS 정책상 조용한 클립보드 감시보다 사용자가 명시적으로 공유하는 흐름이 예측 가능하다.
3. **초기 제품치고 양호한 시각 일관성** — 따뜻한 아이보리·노란색 포인트, 다크 모드, 리스트 중심 정보 구조가 일관된다.
4. **방어적 입력 정규화 일부 구현** — URL 스킴 제한, 문자열 길이 제한, UUID 이미지 파일명 검증, 원자적 파일 쓰기, App Group 파일 보호가 포함돼 있다.
5. **범위 통제가 좋음** — 클라우드·AI·소셜 기능을 억지로 넣지 않아 MVP의 차별점이 흐려지지 않았다.

## 4. 출시 차단 문제

| 순위 | ID | 문제 | 영향 | 판정 |
|---:|---|---|---|---|
| 1 | DATA-001 | 손상된 주 JSON을 첫 실행과 구분하지 않고 샘플 데이터로 대체 | 실제 데이터 손상 은폐·후속 덮어쓰기 가능 | `[중대 위험]` P0 |
| 2 | DATA-002 | 다수 변경 함수가 저장 실패를 무시하고 성공 토스트 표시 | UI 상태와 디스크 불일치, 재실행 후 데이터 소실 | `[중대 위험]` P0 |
| 3 | UX-001 | 중앙 “추가”가 실제 입력이 아니라 하드코딩 샘플 클립 생성 | 핵심 CTA가 제품 약속과 불일치, 심사·신뢰 위험 | P0 |
| 4 | REL-001 | Share Extension이 대용량 이미지를 `Data`/`UIImage`로 전부 메모리에 적재 | 확장 종료, 저장 실패, 원본 이미지 무제한 증가 | P0 |
| 5 | SEC-001 | 생체인증을 평가할 수 없으면 앱 잠금이 fail-open | 사용자가 잠금으로 믿은 데이터가 그대로 노출 | P0 |
| 6 | DATA-003 | 스냅샷 버전 검증·마이그레이션·백업 복구가 없음 | 업데이트 후 호환성·복구 실패 | P0 |
| 7 | TEST-001 | CI와 실패 경로·확장 E2E·아카이브 게이트가 없음 | 회귀를 출시 전에 안정적으로 차단할 수 없음 | P0/P1 |
| 8 | REL-010 | 지원 이메일·개인정보 URL·App Store 자료가 placeholder/미완료 | App Review 제출 불가 또는 거절 가능 | P0 |
| 9 | A11Y-001 | 고정 폰트·높이·40pt 터치 영역, 5열 고정 선택기 | Dynamic Type·VoiceOver·긴 번역에서 사용 곤란 | P1 |
| 10 | SEC-002 | 앱 전환기 스냅샷 보호가 없음 | 잠금 중에도 최근 클립이 시스템 미리보기에 노출 가능 | P1 |

## 5. 종합 점수

| 영역 | 점수 | 핵심 근거 |
|---|---:|---|
| 제품 컨셉 | 82 | 로컬 우선·명시적 캡처 가치가 명확함 |
| 기능 완성도 | 64 | 기본 정리 흐름은 있으나 실제 수동 추가·휴지통·중복 처리 부족 |
| 코드 품질 | 56 | 정규화 장점은 있으나 오류 삼키기·문자열 상태·대형 파일 존재 |
| 아키텍처 | 52 | 단일 AppStore가 상태·도메인·I/O를 과도하게 담당 |
| UI | 74 | 시각 체계는 안정적이나 적응형 레이아웃 부족 |
| UX | 64 | Share-to-Inbox 핵심은 좋으나 온보딩·복구·CTA 정합성 부족 |
| 접근성 | 45 | 고정 크기·축소 텍스트·불완전한 커스텀 컨트롤 의미론 |
| 성능 | 55 | 소규모에는 충분, 전체 JSON 재작성·원본 이미지 디코딩이 확장 한계 |
| 안정성 | 48 | 저장/큐 오류와 확장 메모리 경로가 약함 |
| 보안 | 56 | 공격 표면은 작으나 잠금 fail-open·미리보기 노출·평문 export 주의 부족 |
| 개인정보 보호 | 67 | 서버 없음은 강점, 파일 보호·고지·보존 통제가 미완성 |
| 테스트 | 42 | 단일 단위 테스트 파일은 있으나 핵심 실패·E2E·CI 부족 |
| 배포 준비도 | 41 | 프로젝트/manifest는 있으나 실기기·서명·스토어 자산이 미완료 |
| 문서화 | 70 | 내부 작업·결정 문서는 좋으나 루트 README·LICENSE·보안정책 부족 |
| 경쟁력 | 56 | 프라이버시·단순함은 강점, 시장 표준 검색·복구·동기화 옵션과 격차 |
| **종합** | **58** | **내부 베타 전 단계. P0 해소 후 제한 베타, P1 해소 후 공개 출시 권장** |

## 6. 권장 출시 전략

### Gate A — 데이터 안전 베타

아래 항목이 끝나기 전에는 외부 TestFlight도 제한한다.

- 손상 파일을 격리하고 `.bak`/마지막 정상 스냅샷으로 복구
- 모든 변경을 트랜잭션화하고 저장 성공 후에만 성공 UI 표시
- 스냅샷 버전 강제 검증과 v1→v2 이상 마이그레이션 테스트
- Share Extension 이미지 바이트·픽셀·시간 제한 및 썸네일 생성
- 앱 잠금 fail-closed, 앱 전환기 privacy shield
- 실제 Add 폼 또는 Add 탭 제거/재정의

### Gate B — 실기기 비공개 베타

- Safari URL, 선택 텍스트, Photos HEIC/JPEG/PNG, 대형 이미지, 저용량 디스크, 잠금 상태에서 실기기 테스트
- Dynamic Type 최대 크기, VoiceOver, iPad Split View, 한국어/영어/일본어 스크린 검증
- CI에서 XcodeGen drift, build, unit/UI tests, privacy manifest 검사
- 100/1,000/5,000 클립과 100MB/1GB 이미지 성능 기준 측정

### Gate C — App Store 공개 출시

- 소유한 HTTPS 지원·개인정보 URL과 모니터링 이메일
- distribution signing, signed archive, Privacy Report, TestFlight crash-free 기준
- 정확한 메타데이터: “Share-to-Inbox”, 로컬 저장, 잠금은 암호화가 아님을 명시
- 실제 화면 기반 스크린샷, 온보딩, 빈 상태, 삭제 복구, 저장 공간 관리

## 7. 제품 방향 권고

### 유지할 핵심

- 로컬 전용 기본값
- 계정 없음
- 명시적 공유 캡처
- 빠른 저장/검토 저장 두 모드
- 폴더·태그·Sort Later
- 한국어·영어·일본어

### 즉시 추가할 기능

- 실제 수동 URL/텍스트/이미지 추가
- 휴지통·Undo
- 중복 감지
- Share Extension 활성화 온보딩
- 저장 공간/보존 기간 관리
- 복구 가능한 백업·버전 마이그레이션
- 접근 가능한 적응형 UI

### 나중에 검토할 기능

- 선택적 iCloud 동기화
- OCR·의미 검색·자동 태깅: 기본적으로 온디바이스, 명확한 opt-in
- Shortcuts·위젯·Spotlight
- Mac companion app

구독은 현 상태에서 정당화하기 어렵다. **무료 기본 + 일회성 Pro** 또는 **일회성 구매**가 제품 철학과 가장 잘 맞는다. 지속 서버 비용이 생기는 선택적 동기화·AI를 도입할 때만 구독을 별도 검토한다.

## 8. 예상 개발 규모

- P0 안정성·데이터·CTA·잠금: 2–4주
- 접근성·온보딩·휴지통·스토리지·CI: 추가 3–6주
- 공개 출시 준비·실기기 검증·스토어 자산: 추가 1–3주
- 경쟁 제품 수준 검색·선택 동기화·자동화: 2–4개월+

위 추정은 1명의 숙련 iOS 개발자 기준의 범위 추정이며, 디자인·QA·법률 검토와 App Review 대기 시간을 포함하지 않는다.

## 9. 최종 경영 판단

- **계속 개발할 가치가 있다.** 현재 구현은 단순 목업을 넘어 실제 iOS Share Extension과 로컬 저장 흐름을 갖췄다.
- 다만 핵심 가치가 “개인 데이터 보관”인 만큼, 화려한 기능보다 **데이터가 절대 조용히 사라지지 않는 것**이 우선이다.
- 가장 큰 실패 위험은 기능 부족이 아니라 **사용자는 저장됐다고 믿는데 디스크에는 저장되지 않거나, 손상이 샘플 데이터로 가려지는 것**이다.
- 가장 큰 가능성은 Paste류의 광범위한 클립보드 히스토리와 Raindrop/Readwise류의 무거운 지식 관리 사이에서, **작고 빠르고 계정 없는 iOS 캡처 인박스**로 자리 잡는 것이다.


---

# Repository & Architecture Audit

## 1. 감사 범위와 방법

- `[확인됨]` 공개 저장소 `main` 브랜치의 파일 트리, Swift 소스, XcodeGen 설정, plist/entitlement/privacy manifest, 테스트, 내부 문서, QA 증거 화면을 정적 검토했다.
- `[확인됨]` Apple 공식 App Review·Privacy Manifest·접근성 자료와 경쟁 제품의 공식 기능/가격 페이지를 2026-07-11 기준으로 대조했다.
- `[검증 필요]` 감사 런타임은 macOS/Xcode를 제공하지 않아 `xcodegen`, `xcodebuild`, XCTest, Instruments, signed archive를 독립 실행하지 못했다. 저장소의 `.superloopy/evidence`와 문서가 보고한 simulator build/share QA는 참고 증거이며 독립 재현 결과가 아니다.
- `[검증 필요]` Git clone 또한 감사 런타임의 네트워크 제약으로 수행하지 못했으므로, 공개 GitHub 파일 뷰를 기준으로 분석했다. 따라서 숨겨진 branch·비공개 CI·App Store Connect 상태는 범위 밖이다.

## 2. 저장소 개요

| 항목 | 확인 결과 | 평가 |
|---|---|---|
| 저장소 | 공개 GitHub, `main`, 확인 시점 9 commits, release 없음 | 초기 제품 저장소 |
| 프로덕션 소스 | `ios/` | 저장소 `AGENTS.md`가 명시 |
| 역사적 프로토타입 | `src/`, `public/`, `index.html` | 정적 웹 디자인/상호작용 참조 |
| iOS 프로젝트 생성 | `ios/project.yml`, XcodeGen 2.45.4+ | 재현 가능한 project definition은 장점 |
| 언어/프레임워크 | Swift 5.10, SwiftUI + Share Extension의 UIKit | 네이티브 iOS 집중 |
| 최소 OS | iOS 17.0 | 범위는 선명하나 도달 범위 축소 |
| 지원 기기 | iPhone/iPad (`TARGETED_DEVICE_FAMILY=1,2`) | iPad UI 최적화는 별도 검증 필요 |
| 버전 | 0.3.0, build 1 | pre-1.0 단계 |
| 런타임 외부 의존성 | 확인되지 않음 | 공급망·개인정보 측면 강점 |
| 저장소 라이선스 | 루트 LICENSE를 확인하지 못함 | 공개 배포·기여 권리 불명확 |
| CI | `.github/workflows`를 확인하지 못함 | 출시 게이트 부재 |
| 문서 | `docs/CHANGELOG.md`, `CODE_REVIEW.md`, `DECISIONS.md`, `PROJECT_STATUS.md`, `TASKS.md`, app-store 문서 | 내부 진행 기록은 양호 |
| 루트 README | 확인하지 못함 | 외부 DX·제품 설명에 큰 공백 |

## 3. 상위 디렉터리 해석

```text
ClipInbox/
├── ios/                         # 프로덕션 SwiftUI 앱, Share Extension, 테스트, XcodeGen
│   ├── ClipInbox/               # 앱 코드/리소스/entitlement/privacy manifest
│   │   ├── Models/              # Clip, Folder, Preferences, DataSnapshot, DefaultData
│   │   ├── Store/               # AppStore: 상태·검색·mutation·저장·import/export
│   │   ├── Shared/              # 앱/확장 공용 payload, queue, image asset, localization
│   │   └── Views/               # Inbox, Detail, Search, Folders, Settings, 공통 컴포넌트
│   ├── ClipShareExtension/      # ShareViewController, Info.plist, entitlement
│   ├── ClipInboxTests/          # 단위 테스트
│   └── project.yml              # XcodeGen source of truth
├── src/, public/, index.html    # 역사적 정적 웹 프로토타입
├── scripts/                     # 프로토타입 QA/static validation
├── Reference/                   # 디자인 참조
├── docs/                        # 상태·결정·릴리스·App Store 문서
├── .superloopy/evidence/        # 저장소 작성자의 QA 증거
├── AGENTS.md                    # source-of-truth 및 빌드 지침
├── DESIGN.md                    # 디자인 정의
└── package.json                 # 의존성 없는 정적 프로토타입 스크립트
```

`AGENTS.md`가 `ios/`를 프로덕션 source of truth로 명시한 점은 좋다. 그러나 루트에서 웹과 iOS가 같은 무게로 보여 신규 기여자가 잘못된 트리를 수정할 가능성이 있다. 프로토타입을 `prototypes/web/`로 이동하거나 루트 README 첫 화면에서 구조를 시각적으로 구분하는 것이 바람직하다.

## 4. 현재 런타임 아키텍처

```text
SwiftUI Screens / UIKit Share UI
          │
          ▼
     AppStore (@Observable)
  ┌───────┼────────┬───────────┐
  │       │        │           │
검색/필터  Mutation  Import/Export  Preferences
  │       │        │           │
  └───────┴────────┴───────────┘
          │
          ▼
Application Support/clip-inbox-data.json
          ▲
          │ import on app activation
App Group Queue (per-item JSON) + Original Images
          ▲
          │
Share Extension / NSItemProvider
```

### 장점

- `[확인됨]` Share Extension과 앱이 단일 거대한 공유 스냅샷을 동시에 쓰지 않고, **항목별 원자적 queue 파일**을 사용한다. 동시 쓰기 충돌을 줄이는 좋은 선택이다.
- `[확인됨]` queue와 원본 이미지 쓰기에 `.atomic`과 `.completeFileProtectionUnlessOpen`을 사용한다.
- `[확인됨]` 이미지 파일명은 UUID와 허용 확장자로 검증하고 path traversal을 막는다.
- `[확인됨]` 외부 URL은 http/https로 제한하고, 여러 문자열에 길이 상한을 둔다.
- `[확인됨]` XcodeGen이 target·entitlement·resource를 코드화해 project file 수동 drift를 줄인다.

### 구조적 약점

- `[중대 위험]` `AppStore`가 약 662줄로 상태, UI toast, 검색, 정규화, mutation, JSON I/O, Share queue import, import/export, UserDefaults까지 담당한다.
- `[확인됨]` 파일 I/O가 protocol/actor 뒤에 있지 않아 disk full·permission·corruption을 주입하기 어렵고, UI thread 지연 가능성이 있다.
- `[확인됨]` mutation의 성공 계약이 통일돼 있지 않다. 일부 rename은 rollback하지만 대부분은 `persist()` 반환값을 무시한다.
- `[확인됨]` `Preferences`와 Share 설정에 번역된 문자열이 저장돼 도메인 모델과 표현 계층이 결합된다.
- `[확인됨]` `DataSnapshot.version`은 있으나 load/import 단계에서 지원 버전 검증과 migrator가 없다.
- `[확인됨]` 내부 데이터 저장과 사용자 export가 같은 JSON 모델에 가깝게 결합돼 내부 스키마 변경이 public backup contract에 영향을 준다.

## 5. 핵심 파일 리뷰

### 5.1 `ios/ClipInbox/Store/AppStore.swift`

**책임:** 전체 앱 상태, 검색/필터, 폴더·태그·클립 mutation, 저장, Share queue import, JSON import/export, 토스트.

#### 발견 1 — 손상과 첫 실행의 혼동

초기화에서 파일 읽기/디코딩 실패를 `try?`로 처리하고 `DefaultData`로 대체한다. 파일이 없는 정상 첫 실행과 기존 파일이 손상된 상황이 구분되지 않는다.

- 심각도: Critical / P0
- 사용자 영향: 실제 데이터가 보이지 않고 샘플로 바뀌며, 다음 mutation이 샘플을 주 파일에 기록할 수 있음
- 수정: `StoreBootstrapResult`를 `.firstRun`, `.loaded`, `.recoveredBackup`, `.corrupt(URL)`, `.unsupportedVersion`으로 모델링한다.

#### 발견 2 — 저장 전 메모리 mutation

`deleteClip`, `updateMemo`, `updateTags`, `saveNewClip`, 설정 변경 등 다수 경로가 먼저 배열/설정을 변경한 뒤 `persist()` 실패를 무시한다.

- 심각도: Critical / P0
- 수정: `repository.transaction { draft in ... }`가 임시 스냅샷을 작성·검증·교체한 뒤 성공 결과를 반환하고, ViewModel은 성공 후에만 상태를 publish한다.

#### 발견 3 — 실제 Add가 아님

`saveNewClip`은 사용자 입력 URL/콘텐츠가 아니라 `brunch.co.kr` 샘플 제목·URL·이미지를 하드코딩해 새 클립으로 만든다.

- 심각도: Critical / P0
- 영향: 핵심 CTA와 실제 기능 불일치, App Review 최소 기능성·정확한 메타데이터 위험

#### 발견 4 — 전체 스냅샷 재작성

모든 mutation이 pretty-printed 전체 JSON을 다시 인코딩하고 atomic write한다.

- 소규모 MVP에는 단순하고 안전한 장점이 있으나, 수천 항목·다수 이미지 메타에서 main-thread latency와 쓰기 증폭이 커진다.
- 단기: StorageActor + compact encoding + debounce/coalesce
- 중기: SQLite/SwiftData/GRDB 등 record store로 이전하고 JSON은 export 전용으로 유지

### 5.2 `ios/ClipInbox/Models/Models.swift`

- `[확인됨]` `Clip.id`는 `Int`, 시간은 `String`, 폴더·태그는 문자열 참조다.
- `[확인됨]` `Preferences` decoder가 필드별 `try?`와 기본값을 사용한다. 호환성에는 관대하지만 손상을 조용히 숨길 수 있다.
- `[확인됨]` 샘플 클립·폴더가 `DefaultData`에 production 기본값으로 들어 있다.

**권장 모델:**

```swift
struct Clip: Identifiable, Codable, Sendable {
    let id: UUID
    var kind: ClipKind
    var createdAt: Date
    var updatedAt: Date
    var source: ClipSource
    var content: ClipContent
    var folderID: Folder.ID?
    var tags: Set<Tag.ID>
    var deletion: DeletionState
}
```

표현 문자열은 localization 계층에서 생성하고, raw 데이터에는 `Date`, UUID, enum key만 보관한다.

### 5.3 `ios/ClipInbox/Shared/SharedClipQueue.swift`

**좋은 부분:** 항목별 JSON, atomic write, App Group file protection, UUID 이미지 파일명, 이미지 형식 검증.

**문제:**

- queue 정렬이 UUID 파일명 기준이므로 캡처 순서를 보장하지 않는다.
- decode 실패 항목은 `compactMap`으로 조용히 제외돼 파일이 영구 잔류한다.
- queue count/bytes/TTL 제한이 없다.
- config save와 legacy migration 실패가 `try?`로 사라진다.
- clip commit과 이미지 이동/삭제가 하나의 트랜잭션이 아니다.

### 5.4 `ios/ClipShareExtension/ShareViewController.swift`

- `[확인됨]` Quick/Review 두 모드, URL/webpage/text/image 지원, compact confirmation을 구현했다.
- `[중대 위험]` `loadDataRepresentation`, `Data(contentsOf:)`, `UIImage.pngData()`가 원본을 전부 메모리에 올린다.
- `[확인됨]` provider callback에 timeout/cancellation이 없다.
- `[확인됨]` 여러 fallback 오류가 `try?`로 사라진다.
- `[개선 권장]` 파일 representation을 우선하고 byte/pixel budget을 적용한다. 미리보기만 downsample하고, 원본 보존은 용량 정책 내에서 streaming/copy한다.

### 5.5 UI 및 Settings 파일

- `Components.swift` 약 640줄, `SettingsView.swift` 약 473줄로 공통 스타일과 많은 화면 책임이 뭉쳐 있다.
- `[확인됨]` 디자인 토큰과 공통 row 구성은 재사용을 높이지만, fixed size 중심이어서 접근성 적응이 약하다.
- `[개선 권장]` `Primitive`, `Composite`, `Feature` 컴포넌트로 나누고 semantic typography를 토큰의 1급 요소로 만든다.

## 6. 코드 품질 평가

| 항목 | 점수 | 근거 | 개선 |
|---|---:|---|---|
| 네이밍/가독성 | 7/10 | 함수·모델 이름이 대체로 목적을 드러냄 | 표시 문자열과 domain key 분리 |
| 타입 안정성 | 5/10 | Swift enum 일부 사용, 설정·시간·참조는 문자열 | UUID/Date/Codable enum |
| 오류 처리 | 3/10 | `try?`, Bool persist, false-success | typed error/result, rollback |
| 모듈성 | 4/10 | AppStore/Components 과대 | services/use cases/repositories |
| 테스트 가능성 | 4/10 | fileURL 주입 장점, FileManager·queue 직접 결합 | protocols/fakes/clock/id injection |
| 문서/주석 | 7/10 | 내부 결정·작업 기록과 일부 주석 양호 | root README/runbook/API contract |
| 보안 기본기 | 6/10 | 로컬·file protection·URL/path 검증 | fail-closed/file protection/export warning |
| 확장성 | 4/10 | 전체 메모리/JSON 모델 | record store/index/asset lifecycle |
| 일관성 | 6/10 | 디자인·localization 체계 있음 | mutation/error contract 통일 |

## 7. 코드 지표와 핫스팟

| 파일/영역 | 확인된 규모 | 위험 |
|---|---:|---|
| `AppStore.swift` | 662 lines / 588 LOC | God object, 데이터 신뢰 핵심 |
| `Components.swift` | 약 640 lines / 567 LOC | 디자인 primitive와 feature component 혼합 |
| `SettingsView.swift` | 약 473 lines / 429 LOC | 설정·import/export·위험 행동 복잡도 |
| `AppStoreTests.swift` | 약 223 lines / 179 LOC | 기능 대비 테스트 폭이 좁음 |
| Share Extension controller | 단일 대형 UIKit controller | provider·UI·save orchestration 결합 |

정확한 cyclomatic complexity와 dead-code 수치는 로컬 checkout과 SwiftSyntax/Periphery 실행이 필요해 `[검증 필요]`다. 다만 정적 검토만으로도 저장·공유·설정에 고위험 책임이 집중된 것은 명확하다.

## 8. 권장 리팩터링 경로

### 단계 1 — 동작 보존형 분리

1. `ClipRepository`와 `FileClipRepository` 생성
2. `SnapshotCodec`, `SnapshotMigrator`, `SnapshotRecovery` 분리
3. `PreferencesStore`, `SharedCaptureQueue`, `ImageStore` protocol화
4. 모든 mutation을 `Result<CommittedState, StoreError>`로 통일
5. `AppStore`는 화면 상태와 use-case 호출만 담당

### 단계 2 — 안전한 비동기와 자산 트랜잭션

1. `StorageActor`에서 load/save/import 수행
2. `ImageStoreTransaction`으로 write/commit/rollback 제공
3. queue quarantine와 idempotency key 추가
4. UI에 loading/degraded/recovery 상태 추가

### 단계 3 — 규모에 따른 저장소 이전

- 1,000개 이하가 명확한 제품 제한이라면 안전한 versioned snapshot도 유지 가능하다.
- 무제한 보관을 약속한다면 SQLite/SwiftData 기반 record store가 필요하다.
- JSON export contract는 내부 DB와 분리하고 명시적 `ExportSchemaVersion`을 둔다.

## 9. 의존성·공급망·라이선스

- `[확인됨]` iOS 런타임 외부 패키지는 보이지 않아 dependency CVE 표면이 작다.
- `[확인됨]` Pretendard 폰트가 번들된다. 폰트 라이선스 파일/고지는 release bundle과 `THIRD_PARTY_NOTICES`에서 확인해야 한다.
- `[중대 위험]` 루트 LICENSE가 없으면 공개 저장소 코드를 제3자가 합법적으로 재사용·기여할 조건이 명확하지 않다.
- `[검증 필요]` `public/`, `Reference/`, 앱 아이콘·샘플 이미지의 출처와 배포 권리를 자산 인벤토리로 확인해야 한다.

## 10. 최종 아키텍처 판정

**전면 재작성은 권장하지 않는다.** 현재 네이티브 UI, Share Extension, localization, 기본 모델은 보존 가치가 있다. 그러나 데이터 신뢰 경계는 부분 리팩터링이 아니라 **명확한 repository transaction·migration·recovery 계층**으로 구조를 바꿔야 한다. 이 조치 없이 기능을 더하면 false-success와 손상 복구 문제가 더 넓어진다.


---

# Functional Completeness Audit

## 1. 제품 기능 정의

현재 구현의 핵심은 **iOS Share Extension을 통한 명시적 캡처 → 로컬 인박스 → 나중에 분류·검색·재사용**이다. 백그라운드 클립보드 감시, 계정, 서버 동기화, 웹 스크래핑, 소셜 협업은 현재 제품 범위가 아니다.

### 제품 컨셉 평가

| 평가 항목 | 점수 | 근거 | 문제점 | 개선 방향 |
|---|---:|---|---|---|
| 문제 정의 명확성 | 8/10 | 여러 앱에서 본 링크·이미지를 한 곳에 임시 수집 | “Clip” 명칭이 자동 clipboard history로 오해될 수 있음 | Share-to-Inbox 메시지 명확화 |
| 핵심 가치 전달력 | 7/10 | 계정·서버 없이 빠르게 저장 | 온보딩과 실제 Add가 미완성 | 첫 실행에서 30초 내 첫 공유 성공 |
| 사용 흐름 일관성 | 6/10 | 공유→인박스→분류 흐름은 일관 | 중앙 Add는 데모, 삭제는 영구 | 실제 입력·Undo·복구 상태 추가 |
| 차별성 | 7/10 | 로컬 전용·단순한 캡처 인박스 | 경쟁 앱의 동기화·고급 검색과 격차 | 프라이버시·속도·명시적 캡처 집중 |
| 제품 완성도 | 6/10 | 작동 가능한 앱/확장 구조 | 데이터 신뢰·접근성·배포 미완료 | P0/P1 gate 순서대로 완성 |

## 2. 기능 인벤토리

| 기능 | 구현 상태 | 관련 화면/경로 | 관련 파일/영역 | 정상 경로 | 주요 예외·누락 | 출시 준비도 |
|---|---|---|---|---|---|---|
| 앱 최초 실행 | 부분 구현 | App root | `AppStore.init`, DefaultData | JSON load 또는 기본값 | 손상과 첫 실행 미구분, 샘플 데이터 노출 | 차단 |
| 온보딩 | 미구현 | 없음 | 없음 | — | Share Extension 활성화·Favorites·모드 설명 없음 | 차단/High |
| Share URL | 구현 | Share Extension | `ShareViewController.swift` | URL payload enqueue→앱 import | timeout·queue cleanup·signed host 검증 | 베타 전 수정 |
| Share 웹페이지 | 구현 | Share Extension | activation rules/controller | webpage URL/텍스트 수집 | host별 provider 차이 | 검증 필요 |
| Share 선택 텍스트 | 구현 | Share Extension | controller | text enqueue | 매우 긴 텍스트·encoding E2E 부족 | 보강 |
| Share 이미지 | 부분 구현 | Share Extension | controller/queue | 원본 bytes 저장 | 대형 이미지 메모리·용량 무제한 | 차단 |
| Share 스크린샷 | 이미지로 구현 | Share Extension | image path | Photos/host에서 공유 | 별도 screenshot type 추론 일관성 검증 | 검증 필요 |
| Quick save | 구현 | Share Extension | configuration/controller | 즉시 저장 후 confirmation | 고정 2초 대기, 실패 의미론 | 보강 |
| Review save | 구현 | Share Extension | review form | 폴더·메모 검토 후 저장 | 접근성·긴 내용·host keyboard | 보강 |
| 앱 내 수동 추가 | UI/로직 불일치 | 중앙 Add | `saveNewClip` | 하드코딩 데모 생성 | 실제 URL/text/image 입력 없음 | 차단 |
| Inbox 목록 | 구현 | Inbox tab | Inbox/Components | 최근 항목 목록 | 대규모 데이터·빈 상태·sample badge | 보강 |
| 클립 상세 | 구현 | Detail | Detail views | 이미지/링크/메모/태그 조회 | 고정 높이·오류 상태·접근성 | 보강 |
| 검색 | 구현 | Search tab | AppStore/Search views | title/source/tag/memo 등 substring | 고급 필터·오타·날짜·도메인 scope 없음 | 출시 가능, 개선 |
| 최근 검색 | 구현 | Search | UserDefaults | 최근 query 보관 | export에 포함되지 않음 | 출시 가능 |
| 타입 필터 | 구현 | Inbox top | `InboxFilter` | link/image/memo/screenshot | 5열 고정·긴 번역 | 보강 |
| 태그 필터 | 구현 | Inbox top | filter tags | 상단 기본 태그 | 고정 기본 태그와 사용자 태그 관계 불명확 | 보강 |
| 폴더 목록 | 구현 | Folders tab | Folder views | 폴더별 수/진입 | 삭제·병합 정책 확인 필요 | 부분 |
| 폴더 생성 | 구현 | Folder workflow | AppStore | 중복 검사 후 생성 | persist 실패 false-success 가능 | 차단 |
| 폴더 이름 변경 | 구현 | Folder workflow | AppStore | clip 참조 전파/rollback | 충돌·실패 테스트 확대 필요 | 양호 |
| 폴더 삭제/병합 | 미확인/미비 | Folder workflow | 코드에서 명확한 계약 미확인 | — | 포함 클립 이동·기본 폴더 보호 필요 | 검증 필요 |
| 태그 추가 | 구현 | Settings/detail | AppStore | 정규화·catalog merge | persist 실패 처리 | 보강 |
| 태그 이름 변경 | 구현 | Settings | AppStore | clip/folder 참조 전파 | 대규모 transaction·rollback test | 양호/보강 |
| 태그 삭제 | 구현 | Settings | AppStore | 참조 제거 | Undo/영향 미리보기 없음 | 보강 |
| 즐겨찾기 | 구현 | row/detail | AppStore | bookmark toggle | 전용 smart view/발견성 약함 | 개선 |
| Sort Later | 구현 | sorting flow | AppStore/UI | 미정리 1건 분류 | 대량 batch/keyboard 없음 | 출시 가능, 개선 |
| 메모 편집 | 구현 | Detail | AppStore | 1,000자 정규화 저장 | 저장 실패에도 성공 토스트 | 차단 |
| 클립 편집 | 구현 | Detail | AppStore | title/folder/tags/memo 변경 | transaction 일관성 부족 | 차단 |
| 클립 이동 | 구현 | actions/sheet | AppStore | 폴더 변경 | 저장 실패·Undo 부족 | 차단 |
| 클립 삭제 | 구현 | actions/detail | AppStore | 배열 제거→persist→image delete | persist 실패 rollback 없음, 영구 삭제 | 차단 |
| 전체 데이터 삭제 | 구현 | Settings danger zone | AppStore | state/defaults/image 제거 | 부분 실패 시 불일치·복구 없음 | 차단 |
| JSON 내보내기 | 구현 | Settings | import/export service in store | snapshot file 공유 | 평문 위험, 이미지/일부 settings 제외 가능 | 보강 |
| JSON 가져오기 | 구현 | Settings | AppStore | 5MB cap→decode→normalize | version 검증·rollback·object budget 부족 | 차단 |
| 백업/복원 | JSON import/export 수준 | Settings | snapshot | 수동 roundtrip | 완전 백업 아님, 암호화/자산 manifest 부족 | 부분 |
| 기기 간 동기화 | 미구현 | 없음 | 없음 | — | 제품 의도상 선택적 | MVP 비필수 |
| 테마 | 구현 | Settings | Preferences/L10n/design tokens | light/dark/system | 문자열 persistence, contrast 검증 | 보강 |
| 언어 | 구현 | Settings | L10n/Preferences | 한국어/영어/일본어 | 하드코딩 label·긴 번역 QA | 보강 |
| 앱 잠금 | 부분 구현 | Lock/Settings | LocalAuthentication lifecycle | 인증 후 화면 표시 | fail-open·app switcher·암호화 오해 | 차단 |
| 링크 열기 방식 | 구현 | Settings/detail | LinkOpenMode | direct/confirm | direct default와 피싱 인지 | 개선 |
| 전체 화면 이미지 | 구현 | Detail | viewer | pinch/double tap | pan·rotation·VoiceOver 보강 | 개선 |
| 다크 모드 | 구현 | 전체 | theme/tokens | 앱/extension theme 전달 | contrast·모든 상태 검증 | 보강 |
| iPad | target 지원 | 전체 | project.yml | portrait/landscape 허용 | split view·sidebar 최적화 미확인 | 검증 필요 |
| 오프라인 | 기본 지원 | 대부분 | local-only | 저장·검색·정리 | 외부 링크/metadata는 제한 | 강점 |
| 알림 | 미구현 | 없음 | 없음 | — | 핵심에 불필요; reminder 추가 시 opt-in | MVP 비필수 |
| 위젯/Shortcuts/Spotlight | 미구현 | 없음 | 없음 | — | 파워유저 확장 기회 | 후속 |
| 진단/복구 센터 | 미구현 | 없음 | 없음 | — | queue corruption·backup recovery 가시성 없음 | P1 |
| 저장 공간 관리 | 미구현 | Settings 없음 | image store | — | 원본 누적·큰 파일 정리 불가 | P1 |
| 휴지통/Undo | 미구현 | 없음 | data model | — | 영구 삭제 | P1 |
| 중복 감지 | 미구현 | 없음 | capture/import | — | 동일 URL/image 반복 | P2 |

## 3. 사용자 시나리오 감사

### 3.1 최초 설치와 첫 저장

**현재 예상 흐름**

1. 앱 실행
2. 샘플 클립이 있는 Inbox 확인
3. 사용자가 직접 iOS Share Sheet에서 ClipInbox를 찾아야 함
4. Quick 또는 Review 모드로 저장
5. 앱을 다시 열어 queue import

**문제**

- `[확인됨]` Share Extension 사용법을 앱이 단계적으로 가르치는 온보딩이 보이지 않는다.
- `[확인됨]` 샘플이 진짜 사용자 데이터처럼 보여 앱의 실제 상태와 캡처 성공을 혼동한다.
- `[추정]` Share Sheet Favorites에 확장을 고정하지 않으면 첫 저장 마찰이 크다.
- `[중대 위험]` 중앙 Add를 누르면 실제 입력이 아니라 샘플 링크가 추가된다.

**권장 목표 흐름**

1. 빈 Inbox + “공유해서 저장” 설명
2. 20초 interactive guide: Safari 샘플 URL 공유 또는 수동 Add
3. Quick/Review 선택의 의미 설명
4. 첫 성공 후 saved card와 Inbox 하이라이트
5. Share Extension을 Favorites에 두는 방법을 설정에서 언제든 재확인

### 3.2 반복 캡처

- Quick 모드는 제품의 가장 강한 반복 사용 흐름이다.
- 성공은 queue JSON이 durable하게 저장된 뒤에만 표시해야 한다.
- 앱이 열리지 않아도 queue가 쌓이므로 count/bytes/age 상한과 diagnostics가 필요하다.
- 동일 URL/텍스트/이미지를 반복 공유할 때 merge·duplicate UX가 필요하다.

### 3.3 나중에 찾기

현재 검색·타입/태그 필터·폴더·즐겨찾기가 있으나 개념이 겹친다.

- 폴더: 항목이 위치하는 하나의 기본 장소
- 태그: 여러 속성
- Smart view: Inbox, Unsorted, Favorites, Recent, Images, Trash

위처럼 의미를 분리해야 사용자가 “폴더와 태그 중 무엇을 써야 하는가”를 덜 고민한다.

### 3.4 정리와 삭제

- Sort Later는 좋은 제품 컨셉이나 한 번에 1개를 처리하는 현재 형태는 backlog가 커질수록 피로하다.
- swipe triage, batch select, 최근 사용 폴더, tag suggestion을 단계적으로 추가한다.
- 모든 삭제는 soft delete가 기본이며, 이미지 파일도 trash retention이 끝날 때 제거해야 한다.

### 3.5 백업·기기 변경

현재 JSON export/import는 최소 생존 기능이지만 “완전 백업”이라고 부르기 어렵다.

- 일부 UserDefaults 상태가 빠진다.
- 이미지 원본 포함 여부와 manifest 계약이 불명확하다.
- schema version을 검사하지 않는다.
- 평문 파일이 다른 앱/클라우드에 남을 위험을 충분히 알려야 한다.

**1.0 요구:** versioned archive, preview, checksum, optional encryption, atomic restore, 기존 데이터 merge/replace 선택, 실패 rollback.

## 4. 주요 예외 흐름

| 조건 | 현재 위험 | 권장 동작 |
|---|---|---|
| 주 JSON 손상 | 샘플로 조용히 대체 | current 격리→backup 검증→복구 선택 |
| 저장 공간 부족 | mutation은 성공처럼 보일 수 있음 | rollback, 필요한 용량·정리 CTA 표시 |
| 권한/App Group 실패 | Share 저장 실패 또는 config 불일치 | 명시 오류, retry, signing diagnostics |
| 대형 이미지 | extension memory 종료 가능 | 용량/픽셀 제한, file copy, optimize 선택 |
| provider 응답 없음 | extension hang | timeout, cancel, host 복귀 |
| 앱 강제 종료 | 마지막 mutation durability 불명확 | commit 시점 명확화, journal/transaction |
| 미래 버전 import | 기존 데이터 왜곡 가능 | import 차단, 앱 업데이트 안내 |
| 중복 ID/URL | collision·노이즈 | UUID + canonical duplicate UX |
| 매우 긴 다국어 | 잘림·축소·정규화 | semantic layout, explicit limits/counters |
| 저사양/대량 데이터 | 검색·목록·저장 지연 | performance budget, index/downsample |
| 잠금 인증 불가 | 콘텐츠 노출 | fail-closed, recovery 안내 |
| 삭제 실수 | 영구 손실 | Undo + Trash |

## 5. 플랫폼별 기능 상태

### iOS/iPadOS

- 유일한 프로덕션 플랫폼이다.
- iOS 17+, iPhone/iPad target, Share Extension, App Group, LocalAuthentication이 중심이다.
- 물리 기기에서 Face ID, Photos provider, App Group release signing, file protection, iPad split view를 검증해야 한다.

### Android

- `[확인됨]` Android 구현은 없다.
- 현재는 누락 결함이 아니라 iOS 집중 전략으로 본다.
- Android clipboard/background 정책과 구현 비용은 iOS PMF 확인 이후 별도 제품으로 평가한다.

### Web/Desktop

- 루트 웹 앱은 역사적 정적 프로토타입이다.
- production 배포 대상으로 취급하면 persistence/auth/security/hosting/accessibility가 거의 새 프로젝트 수준으로 필요하다.
- 단기에는 “웹 앱도 제공한다”는 마케팅을 하지 않는다.

## 6. MVP 정의 재설정

### 반드시 포함

- 실제 URL/text/image/manual memo 추가
- Share URL/text/image quick/review
- 데이터 손상 복구와 저장 실패 rollback
- Inbox, Search, Folders/Tags, Favorites, Sort Later
- 휴지통/Undo
- JSON versioned backup/restore
- storage controls
- 앱 잠금 fail-closed + privacy shield
- 접근 가능한 3개 언어/다크 모드

### 출시 후 가능

- OCR, semantic search, metadata fetching
- iCloud sync
- Shortcuts/Spotlight/widgets
- Mac companion

### 구현 비추천

- 사용자가 모르는 백그라운드 clipboard 수집
- 광고 SDK
- 기본값 서버 업로드
- 데이터 신뢰를 완성하기 전 AI 요약·자동 분류

## 7. 기능 완성도 판정

- **내부 프로토타입:** 통과
- **제한 TestFlight:** P0 데이터/extension/lock/Add 수정 후 통과 가능
- **공개 App Store:** P0 + 온보딩·접근성·삭제 복구·release/legal gate 완료 전 부적합


---

# UI, UX & Accessibility Audit

## 1. 감사 근거

UI 평가는 다음을 결합했다.

- SwiftUI/UIView 코드의 레이아웃·폰트·컴포넌트·상태 처리
- `DESIGN.md`, 토큰/UI specification 문서
- 저장소가 보관한 iOS QA 증거 화면: Inbox, Settings dark, Folders dark, Share Extension, App Lock, full-screen image viewer
- Apple Human Interface Guidelines, Dynamic Type, VoiceOver 및 WCAG 2.2 원칙

`[검증 필요]` 실제 터치·VoiceOver rotor·Reduce Motion·Switch Control·색 대비 수치는 simulator/실기기에서 재검증해야 한다.

## 2. 화면 인벤토리

| 화면/상태 | 목적 | 주요 요소 | 진입 | 종료 | 핵심 문제 |
|---|---|---|---|---|---|
| Inbox | 저장 항목 훑기 | 제목, 필터 grid, list rows, bottom tabs | 앱 기본 | 상세/탭 | 빈 상태·sample 구분, 5열 고정 필터 |
| Clip Detail | 내용 확인·편집·열기 | preview, metadata, tags, memo, actions | Inbox/Search/Folder | Back | 고정 높이, 오류/저장 상태, 링크 신뢰 |
| Search | 전체 검색 | field, recent queries, results | bottom tab | 상세/탭 | substring 중심, filter scope 부족 |
| Folders | 폴더 목록·관리 | folder rows/counts, add/rename | bottom tab | folder content | 삭제/병합 정책·iPad sidebar 부재 |
| Folder Detail | 폴더 항목 | filtered clip list | folder row | detail/back | smart view와 정보 구조 중복 |
| Add | 앱 내 캡처 | 현재 workflow sheet/CTA | center tab | save/cancel | 실제 입력이 아닌 demo clip 생성 |
| Sort Later | 미정리 항목 분류 | clip, destination, tags | CTA/action | next/done | batch triage 없음 |
| Settings | 앱 설정·데이터 관리 | theme, language, lock, share mode, import/export, danger zone | bottom tab | subflows | 설정 저장 실패 가시성·storage dashboard 없음 |
| Tag Management | tag add/rename/delete | rows/editor | Settings/detail | back | 영향 미리보기·Undo 부족 |
| App Lock | 인증 전 차단 | icon, title, unlock CTA/error | launch/foreground | 인증 성공 | fail-open, app switcher shield 없음 |
| Share Quick | 즉시 캡처 | compact saved feedback | iOS Share Sheet | host return | 2초 고정 지연, timeout/error semantics |
| Share Review | 캡처 검토 | preview, folder, tags/memo, save | iOS Share Sheet | host return | custom accessibility·keyboard·long content |
| Import | JSON 선택·적용 | file picker/confirmation | Settings | success/error | version/preview/rollback 부족 |
| Export | backup 공유 | share sheet | Settings | dismiss | 평문/범위 고지 부족 |
| Delete Confirmation | 파괴 행동 확인 | warning/actions | row/detail/settings | cancel/delete | 영구 삭제, 복구 없음 |
| Toast/Banner | 작업 피드백 | transient text | mutations | timeout | 실패와 성공 구분, VoiceOver 공지 |
| Full-screen Image | 확대 보기 | image, close, zoom | detail | close/back | zoom 후 pan·controls·a11y 보강 |
| Loading/Recovery | 저장소 초기화/복구 | 현재 명확한 전용 화면 미확인 | launch | ready/retry | degraded/recovery state가 없음 |
| Empty | 첫 사용/검색 없음 | 현재 evidence 제한 | no data/no result | capture/filter reset | 행동 중심 안내 필요 |

## 3. 비주얼 디자인 평가

### 강점

- `[확인됨]` 따뜻한 아이보리 배경과 노란 accent가 기억 가능한 브랜드 톤을 만든다.
- `[확인됨]` 최신 evidence의 list-first Inbox는 초기 카드 중심 UI보다 정보 밀도와 스캔 효율이 개선됐다.
- `[확인됨]` 다크 Settings/Folders에서 표면·구분선·강조 색이 비교적 일관된다.
- `[확인됨]` 폴더·설정 행을 공통 컴포넌트로 통합하려는 흔적이 있어 시각 정렬이 안정적이다.
- `[확인됨]` bottom tab의 5개 핵심 영역은 제품 구조를 빠르게 이해하게 한다.

### 약점

- `[확인됨]` 타이포그래피가 semantic text style보다 고정 `Font.custom(..., size:)` 중심이다.
- `[확인됨]` 5열×2행 선택기는 12pt 안팎 텍스트를 축소하며 `minimumScaleFactor`에 의존한다. 이는 “맞춰 넣기”이지 적응형 설계가 아니다.
- `[확인됨]` 여러 행·preview·editor가 고정 높이를 사용해 큰 글자와 긴 콘텐츠를 레이아웃이 아닌 잘림/축소로 해결한다.
- `[검증 필요]` tertiary gray, muted yellow, dark surface 조합의 실제 대비 측정 결과가 없다.
- `[추정]` 중앙 Add가 핵심 CTA처럼 강조되지만 실제로는 demo를 생성하므로 시각 계층이 잘못된 기능을 과도하게 약속한다.
- `[추정]` 작은 ellipsis, close, chip은 시각 크기뿐 아니라 hit target도 부족할 수 있다.

## 4. 디자인 시스템 감사

### 현재 있는 것

- 컬러·spacing·corner·typography에 해당하는 token 구조
- Pretendard Regular/SemiBold/Bold 번들
- 라이트/다크 theme
- 공통 destination row/divider, chip, button, card 계열
- 일관된 yellow accent와 warm neutral surface

### 부족한 것

| 토큰/규칙 | 현재 위험 | 권장 정의 |
|---|---|---|
| Semantic typography | fixed pixel size | `.title`, `.headline`, `.body`, `.caption`, `.button`을 Dynamic Type relative style로 정의 |
| Minimum hit area | 일부 40pt | 모든 interactive primitive 44×44 이상 |
| Content width | phone 기준 고정 | compact/regular width, iPad max readable width, split-view rules |
| State colors | success/error/warning/disabled 근거 부족 | light/dark/high-contrast pair와 텍스트 대비 수치 문서화 |
| Motion | transition 규칙 불명확 | duration/easing, Reduce Motion 대체, haptic policy |
| Focus/accessibility | custom component 규칙 부족 | label/value/hint/trait/focus order contract |
| Empty/error/loading | 화면별 임시 구현 가능성 | 공통 `StateView` + primary/secondary action |
| Iconography | 시스템/custom 사용 규칙 불명확 | SF Symbols 우선, 크기·weight·mirroring·label 규칙 |
| Destructive action | 영구 삭제 중심 | danger hierarchy + Undo/Trash standard |

### 제안하는 최소 semantic token

```swift
enum AppTextStyle {
    case screenTitle, sectionTitle, rowTitle, body, metadata, chip, button
}

extension Font {
    static func app(_ style: AppTextStyle) -> Font {
        switch style {
        case .screenTitle: return .custom("Pretendard-Bold", size: 28, relativeTo: .largeTitle)
        case .sectionTitle: return .custom("Pretendard-SemiBold", size: 17, relativeTo: .headline)
        case .rowTitle: return .custom("Pretendard-SemiBold", size: 15, relativeTo: .body)
        case .body: return .custom("Pretendard-Regular", size: 15, relativeTo: .body)
        case .metadata: return .custom("Pretendard-Regular", size: 13, relativeTo: .caption)
        case .chip: return .custom("Pretendard-SemiBold", size: 13, relativeTo: .callout)
        case .button: return .custom("Pretendard-SemiBold", size: 16, relativeTo: .headline)
        }
    }
}
```

고정 frame 대신 `minHeight`, `fixedSize(horizontal:false, vertical:true)`, `ViewThatFits`, `DynamicTypeSize`별 layout variant를 사용한다.

## 5. 정보 구조

### 현재 구조

- Inbox
- Folders
- Add
- Search
- Settings

이 구조 자체는 단순하지만, Inbox 상단에 **타입 + 고정 태그 + 미정리**가 함께 놓여 있고, Folders와 Tags가 별도 관리되며, Bookmark는 직접 목적지가 약하다.

### 권장 구조

```text
Library
├── Inbox (all active)
├── Unsorted
├── Favorites
├── Recent
├── Images / Links / Text
├── Folders
└── Trash

Capture
├── Manual Add
└── Share Extension Guide

Search
└── Query + type/folder/tag/date filters

Settings
├── Capture behavior
├── Privacy & Lock
├── Storage & Retention
├── Backup & Restore
├── Appearance & Language
└── Help & Privacy
```

bottom tab는 Inbox / Folders(or Library) / Add / Search / Settings로 유지할 수 있다. 단, Inbox 상단 10개 고정 chip을 smart-filter horizontal row 또는 filter button/sheet로 단순화한다.

## 6. 핵심 UX 문제

### 6.1 핵심 CTA와 실제 기능 불일치

중앙 Add는 사용자가 새 콘텐츠를 넣는 가장 강한 affordance다. 실제 구현이 하드코딩 샘플을 생성하면 제품 전체 신뢰가 깨진다.

- 해결 A: URL, Text, Photo, Memo 4개 quick add
- 해결 B: Add 탭을 “Share Guide”로 바꾸고 수동 입력을 넣지 않음
- 권장: A. Share Sheet가 주 경로여도 앱 내부의 탈출구는 있어야 한다.

### 6.2 첫 성공까지의 발견성

사용자는 앱 설치만으로 Share Extension이 자동 노출·상단 고정되는 방식을 알지 못한다.

**온보딩 제안**

1. “어디서든 공유 → Clip Inbox” 한 문장
2. 애니메이션이 아닌 실제 3컷 정적 가이드
3. Quick/Review 선택
4. “연습용 링크 저장” 또는 수동 URL 입력
5. 성공 후 Inbox에서 항목 하이라이트

건너뛰기와 설정에서 다시 보기 기능을 제공한다.

### 6.3 저장 신뢰

성공 토스트는 파일 commit 후에만 나와야 한다. 저장이 실패하면 기술 오류보다 사용자 행동을 제시한다.

- “저장하지 못했습니다. 기기 저장 공간을 확인한 뒤 다시 시도하세요.”
- “복구 가능한 임시 항목 1개가 있습니다.”
- “백업에서 23개 항목을 복구했습니다. 손상 파일은 내보낼 수 있습니다.”

### 6.4 삭제 복구

- row swipe 또는 menu Delete → 즉시 soft-delete
- 6초 Undo banner
- Trash에서 복원/영구 삭제
- 이미지 파일은 retention 종료 후 삭제
- Delete All은 내보내기 제안, typed confirmation, transaction

### 6.5 분류 부담

캡처 순간에는 폴더·태그를 강제하지 않는다. Quick save의 기본은 Inbox이고, Review는 사용자가 원할 때만 확장한다. 나중 정리 화면에서 최근 폴더, 추천 태그, swipe action을 제공한다.

## 7. 접근성 감사

### 7.1 Dynamic Type

- `[확인됨]` fixed custom font와 `minimumScaleFactor`가 많다.
- `[확인됨]` row/preview/editor 고정 높이가 있다.
- 결과: 큰 글자에서는 정보가 축소되거나 잘리고, target 사이 간격이 부족할 수 있다.

**출시 기준:** iOS의 가장 큰 accessibility size에서도 저장·검색·삭제 복구·설정을 완료할 수 있어야 한다. 한 화면에 모든 것을 우겨 넣는 목표는 버리고 vertical scroll/reflow를 허용한다.

### 7.2 VoiceOver

- custom Share Extension UI와 custom chips는 label/value/selected trait/announcement를 명시해야 한다.
- 저장 성공, 오류, 태그 선택, 폴더 이동, 잠금 상태는 시각 토스트만으로 전달하지 않는다.
- 이미지 label은 “이미지”만이 아니라 클립 제목·출처·상태를 조합한다.
- ellipsis menu는 “더 보기” 대신 “{클립 제목} 작업”으로 context를 제공한다.

### 7.3 터치와 운동 접근성

- `[확인됨]` design token의 chip target 40은 44pt 권장 기준에 못 미친다.
- 모든 작은 icon에는 padding을 포함한 44pt `contentShape`를 보장한다.
- custom edge swipe가 AssistiveTouch/ScrollView와 충돌하지 않는지 확인한다.
- Reduce Motion이 켜지면 확대·전환을 fade/cross-dissolve로 대체한다.

### 7.4 색과 대비

- text contrast는 normal text 4.5:1, large text 3:1을 기본 목표로 한다.
- 색만으로 selected/error 상태를 표현하지 않는다. checkmark, border, label을 병행한다.
- Increase Contrast 환경에서 token override를 제공한다.

### 7.5 다국어와 방향성

- 한국어/영어/일본어가 구현됐으나, 고정 5열은 영어에서 취약하다.
- pseudo-localization 40% expansion을 CI snapshot에 넣는다.
- 하드코딩 한국어 accessibility label을 제거한다.
- 향후 RTL을 당장 지원하지 않더라도 leading/trailing과 SF Symbol mirroring을 깨지 않도록 한다.

## 8. UX 문제 우선순위

| 문제 | 사용자 영향 | 빈도 | 심각도 | 난이도 | 우선순위 | 제안 |
|---|---|---:|---:|---:|---:|---|
| Add가 demo 생성 | 매우 큼 | 높음 | 10 | M | P0 | 실제 capture form |
| 저장 실패 false-success | 매우 큼 | 낮음~중간 | 10 | L | P0 | transaction + durable feedback |
| 온보딩 없음 | 큼 | 첫 사용자 모두 | 9 | M | P1 | guided first capture |
| 영구 삭제 | 큼 | 중간 | 9 | M | P1 | Undo + Trash |
| Dynamic Type 취약 | 큼 | 접근성 사용자 | 9 | L | P1 | semantic typography/reflow |
| 잠금 preview/fail-open | 매우 큼 | 조건부 | 10 | M | P0/P1 | fail-closed + shield |
| 이미지 무제한 | 큼 | 이미지 사용자 | 9 | L | P0/P1 | cap/optimize/storage UI |
| 5열 필터 | 중간 | 높음 | 7 | M | P1 | adaptive chips/filter sheet |
| 검색 기능 제한 | 중간 | 반복 | 6 | L | P2 | scoped/tokenized search |
| Sort Later 단건 | 중간 | backlog 사용자 | 6 | L | P2 | batch/swipe triage |
| iPad 단일 컬럼 | 중간 | iPad 사용자 | 6 | L | P2 | NavigationSplitView |
| 이미지 viewer pan 부족 | 낮음~중간 | 이미지 사용자 | 5 | M | P2 | scroll-based zoom viewer |

## 9. UI/UX 최종 판정

**시각적 토대는 유지할 가치가 있다.** 새로운 디자인을 전면 재작업하기보다, 현재 브랜드와 리스트 UI를 보존하면서 다음을 바꾼다.

1. fixed-size 디자인을 semantic/adaptive system으로 전환
2. Add/Onboarding/Empty/Recovery 같은 “제품 의미 화면” 완성
3. 영구 행동을 Undo/Trash로 전환
4. 저장·잠금·export에 신뢰 메시지 추가
5. iPad·VoiceOver·큰 글자를 release gate로 승격

이 작업이 끝나면 현재 74점 수준의 시각 디자인이 실제 UX·접근성 품질과 일치하게 된다.


---

# Security, Privacy & Data Audit

## 1. 범위와 기준

- 로컬 저장, App Group, Share Extension, JSON import/export, 외부 링크, 앱 잠금, 로그, privacy manifest를 검토했다.
- OWASP MASVS의 Storage, Privacy, Platform, Code, Resilience 관점과 Apple 플랫폼 정책을 적용했다.
- `[검증 필요]` binary-level secret scan, network capture, file protection inspection, jailbroken-device behavior, signed archive privacy report는 checkout·실기기·배포 계정이 필요하다.

## 2. 보안/개인정보 요약

### 강점

- `[확인됨]` 계정·서버·광고·트래킹 SDK가 보이지 않는다.
- `[확인됨]` 기본 기능은 오프라인 로컬 동작이다.
- `[확인됨]` Share queue와 이미지에 atomic write 및 `.completeFileProtectionUnlessOpen`을 사용한다.
- `[확인됨]` App Group 이미지 파일명은 UUID와 허용 확장자로 제한해 경로 조작을 방어한다.
- `[확인됨]` 외부 URL은 http/https로 정규화한다.
- `[확인됨]` 입력 문자열 길이, 태그 수, suggestion 수 등에 일부 상한이 있다.
- `[확인됨]` main app과 extension에 privacy manifest 파일이 마련돼 있다.

### 핵심 위험

1. 앱 잠금이 인증 capability 오류에서 fail-open한다.
2. app switcher snapshot privacy shield가 없다.
3. 주 JSON 파일 보호 수준을 명시하지 않는다.
4. 데이터 손상을 샘플로 대체하고 저장 실패를 성공처럼 표시한다.
5. Share Extension 이미지에 용량·픽셀·시간 제한이 없다.
6. JSON export가 평문이고 보호 범위·누락 범위 고지가 약하다.
7. queue corruption과 orphan 자산이 조용히 쌓일 수 있다.
8. release archive 기준 privacy manifest와 “Data Not Collected” 답변을 검증하지 않았다.

## 3. 보호 자산

| 자산 | 민감도 | 위치 | 현재 보호 | 주요 위험 |
|---|---:|---|---|---|
| URL·텍스트·메모 | 높음 | Application Support JSON | 앱 sandbox, atomic write | 명시적 file protection 없음, corruption fallback |
| 이미지 원본 | 매우 높음 | App Group images | UUID filename, image validation, file protection | 무제한 보존, extension memory, app group 접근 |
| pending share payload | 높음 | App Group pending JSON | per-file atomic/protected | corrupt item 방치, queue quota 없음 |
| 폴더·태그 | 중간 | main snapshot/UserDefaults | sandbox | backup 범위 불일치 |
| 잠금 설정 | 높음 | Preferences/Shared config | sandbox/App Group | localized string, config save failure |
| 최근 검색 | 높음 | UserDefaults | sandbox | export/삭제 범위 인지 부족 |
| backup/export | 매우 높음 | temporary/file provider/cloud | 사용자 선택 위치 | 평문, 사본 잔류, 범위 불명확 |
| signing/App Group identifiers | 중간 | project.yml/entitlements | 공개 설정 | team ID 결합, release profile mismatch |

## 4. 위협 모델

| 자산 | 위협 행위자 | 공격/실패 경로 | 영향 | 현재 방어 | 권장 방어 |
|---|---|---|---|---|---|
| 모든 클립 | 기기 일시 접근자 | 잠금 capability 실패, 앱 전환기 preview | 민감 정보 노출 | LocalAuthentication UI | fail-closed, inactive shield, lock timeout |
| 주 JSON | 파일 손상/OS/사용자 | truncated file, disk full, future schema | 데이터 유실·샘플로 위장 | atomic write | rotating backup, checksum, migration, recovery UI |
| 공유 이미지 | 악의적/비정상 provider | 초대형 이미지·decompression bomb | extension OOM/DoS | ImageIO validation | byte/pixel cap, metadata-only inspect, downsample, timeout |
| queue | 손상 파일/중단 | decode failure, remove failure | 반복/누락·storage leak | per-item files | quarantine, idempotency, TTL, reconciliation |
| export | 다른 앱/클라우드/오공유 | 평문 JSON 공유 | 영구 외부 유출 | 사용자 명시 share | warning, encrypted archive, temp cleanup |
| 외부 링크 | 피싱 사이트 | direct-open saved URL | 추적/피싱 | http/https 제한 | domain emphasis, confirmation/suspicion heuristics |
| App Group | signing misconfig | 잘못된 entitlement/profile | 저장 실패·데이터 단절 | static identifiers | release archive entitlement validation |
| 설정 | 파일 write 실패 | app/extension config 불일치 | 사용자의 저장·잠금 기대와 다른 동작 | default fallback | versioned config, throws, status indicator |
| 로그 | 개발/지원 | URL·제목·파일명이 로그에 포함 | 2차 개인정보 노출 | 일부 DEBUG 제한 | privacy redaction, synthetic diagnostics |
| 공급망 | 의존성/자산 | 악성 SDK·권리 불명확 asset | 유출·법적 위험 | 외부 runtime deps 없음 | SBOM, asset notices, release diff review |

## 5. 저장 데이터와 암호화

### 5.1 주 스냅샷

`AppStore.persist()`는 Application Support의 `clip-inbox-data.json`에 atomic write한다. atomic write는 부분 파일 방지에 유효하지만 다음을 해결하지 않는다.

- 이전 정상 파일이 이미 논리적으로 잘못된 경우
- decode 가능한 잘못된 import
- schema incompatibility
- disk full/permission과 UI rollback
- 파일 보호 수준
- 기기 백업 포함 정책

**권장 단기 설계**

```text
clip-inbox/
├── current.snapshot
├── previous.snapshot
├── recovery/
│   └── corrupt-<timestamp>.snapshot
└── manifest.json  # schema, record count, checksum, createdAt
```

1. draft encode
2. draft decode/semantic validate
3. SHA-256/checksum·record count 기록
4. current→previous rotate
5. draft→current atomic replace
6. 성공 후 상태 publish

### 5.2 파일 보호

- App Group queue/images에는 `.completeFileProtectionUnlessOpen`이 명시돼 있다.
- 주 snapshot에는 동일한 옵션 또는 file attribute가 보이지 않는다.

`[개선 권장]` 위협 모델에 따라 `NSFileProtectionCompleteUntilFirstUserAuthentication` 또는 `Complete`를 선택하고, 잠금 상태 Share Extension과 충돌하지 않는지 실기기에서 확인한다. 파일 보호는 앱 자체 암호화와 동일하지 않다.

### 5.3 선택적 암호화 vault

1.0의 필수 조건은 아니지만 “보안 폴더”를 제공한다면:

- CryptoKit AES-GCM
- 키는 Keychain, 가능하면 biometryCurrentSet/access control
- metadata leakage 범위 명시
- recovery key/기기 변경 정책 명시
- 잠금 실패 시 데이터 삭제 같은 위험 기본값 금지

단순 앱 잠금을 “암호화”라고 마케팅하지 않는다.

## 6. 앱 잠금 감사

### 현재 동작 위험

- `.deviceOwnerAuthentication`은 Face ID/Touch ID뿐 아니라 device passcode fallback을 허용한다.
- 인증 policy를 평가할 수 없을 때 콘텐츠를 잠그지 않는 fail-open 경로가 있다.
- background에서 lock하지만 inactive 시점의 system snapshot을 덮는 privacy view가 없다.
- 데이터는 이미 메모리에 있고 저장소도 별도 암호화되지 않는다.

### 요구 동작

| 상황 | 권장 상태 |
|---|---|
| 사용자가 잠금 켜기 | 먼저 capability 확인, 성공해야 설정 commit |
| Face ID/Touch ID 실패/취소 | 잠금 유지 |
| passcode 없음 | 설정 거절 또는 별도 앱 PIN recovery, 절대 자동 unlock 금지 |
| scene `.inactive` | 즉시 privacy cover |
| scene `.background` | authenticated session 만료 |
| foreground | 인증 완료 전 store view 생성/노출 금지 |
| 반복 실패 | OS policy 준수, destructive reset 금지 |
| 마케팅 | “Face ID/Touch ID/기기 암호로 화면 접근 보호”로 정확히 표현 |

## 7. Share Extension 보안·안정성

### 입력 표면

- URL/webpage
- plain text
- image providers
- temporary file URL
- arbitrary provider implementation

### 현재 방어

- activation rule로 지원 타입 범위를 제한
- safe URL 정규화
- 이미지 데이터가 ImageIO로 식별되는지 검사
- 확장자 allowlist와 UUID file name
- queue write가 실패하면 신규 이미지 정리를 시도

### 추가 방어

1. provider당 8–12초 timeout
2. 총 payload byte limit, 예: 원본 50MB 상한과 사용자 설정
3. pixel count limit, decompression bomb 방어
4. `loadFileRepresentation`/security-scoped coordinated copy 우선
5. preview용 downsample과 원본 저장을 분리
6. metadata parsing은 main thread 밖에서 수행
7. extension memory signpost와 release device threshold
8. unsupported format은 host로 돌아갈 수 있는 명확한 오류
9. queue 최대 항목·총 bytes·TTL
10. corrupt queue quarantine와 사용자 진단

## 8. Import/Export 보안

### Import

현재 5MB 파일 크기 상한은 긍정적이지만 충분하지 않다.

- supported schema version 확인
- clip/folder/tag 최대 개수
- ID uniqueness, string normalization, date range
- URL scheme/length
- image manifest path traversal
- dry-run summary: 추가/덮어쓰기/충돌 수
- merge/replace 선택
- transaction/rollback
- unknown fields를 허용하더라도 required semantics는 엄격히 검증

### Export

- 평문임을 명시한다.
- 이미지 포함/제외, 최근 검색·설정 포함 범위를 명시한다.
- 임시 export 파일은 share completion/timeout 뒤 삭제한다.
- password-encrypted archive는 선택 사항으로 제공한다.
- 사용자가 선택한 cloud/file provider로 보내는 행위와 개발자가 데이터를 수집하는 행위를 구분해 정책에 설명한다.

## 9. 네트워크·외부 링크

현재 서버가 없고 외부 SDK도 보이지 않는 점은 큰 장점이다. 그러나 release에서 다음을 확인한다.

- 링크 preview/metadata 기능을 향후 추가한다면 직접 기기 요청으로 IP가 대상 사이트에 노출될 수 있음을 설명한다.
- `UIApplication.open`은 http/https만 허용하고, 표시 domain과 실제 URL을 일치시킨다.
- URL userinfo, punycode, redirect, tracking parameters를 UI에서 명확히 표시한다.
- local-only 약속 검증을 위해 release binary를 proxy로 관찰하고 사용자 동작 없는 outbound connection 0을 기준으로 둔다.

## 10. 로그·진단·모니터링

### 금지 데이터

- 클립 본문/메모
- 전체 URL/query string
- 이미지 bytes/파일 경로
- 검색어
- 폴더·태그 이름
- export 파일명

### 허용 가능한 진단

- 익명 이벤트가 아니라도 로컬 `OSLog`의 category, error code, payload type, byte bucket, duration bucket
- 사용자가 직접 export하는 redacted diagnostics
- MetricKit의 hang/memory/crash 지표

외부 crash SDK를 추가할 경우 기본 local-only/privacy claim과 App Store privacy answer를 다시 검토한다. SDK가 없다는 사실보다 **실제 release binary가 무엇을 보내는지**가 기준이다.

## 11. Privacy Manifest와 App Store Privacy

- `[확인됨]` main app과 extension에 privacy manifest가 존재한다.
- `[검증 필요]` final archive에서 Required Reason API 사용과 선언이 정확히 일치하는지 Xcode Privacy Report로 확인해야 한다.
- `[검증 필요]` “Data Not Collected” 답변은 개발자나 제3자가 데이터를 off-device로 전송·보존하지 않는 release binary에 한해 타당하다.
- 계정이 없으므로 account deletion UI는 현재 비적용이지만, 로컬 전체 삭제·export·backup·OS backup 동작은 정책에 명확히 쓴다.
- privacy policy 링크는 App Store metadata와 앱 내부 양쪽에 실제 HTTPS URL로 제공해야 한다.

## 12. 개인정보 최소화 원칙

| 원칙 | 현재 상태 | 보완 |
|---|---|---|
| 목적 제한 | 사용자가 공유한 콘텐츠 보관 | 자동 monitoring을 추가하지 않음 |
| 최소 수집 | 서버/계정 없음 | 원본 이미지 보존을 선택 가능하게 |
| 투명성 | docs 초안 | 실제 앱 내 privacy center/URL |
| 사용자 통제 | 삭제/export 존재 | Undo, Trash, retention, encrypted export |
| 보안 | sandbox/App Group protection | main file protection, fail-closed lock |
| 보존 제한 | 없음 | 자동 삭제/queue TTL/storage cap |
| 정확성 | mutation 가능 | durable commit과 conflict validation |
| 이동성 | JSON export | versioned complete archive |

## 13. 출시 차단 / 단기 / 장기

### 출시 차단

- 손상 스냅샷 fallback
- persist false-success
- 앱 잠금 fail-open
- 대형 이미지 extension OOM 경로
- privacy/support placeholder
- signed archive/privacy manifest 검증
- 정확한 App Privacy answer

### 출시 전 권장

- app switcher shield
- main snapshot file protection
- export 경고와 temp cleanup
- queue quota/quarantine/idempotency
- redacted diagnostics
- privacy center와 storage/retention

### 장기

- encrypted private folder
- optional iCloud sync threat model
- on-device sensitive-content detection
- SBOM/attestation

## 14. 최종 보안 판정

외부 서버가 없기 때문에 전형적인 API 인증·토큰·SQL injection 위험은 작다. 그러나 이 제품의 가장 중요한 보안 속성은 **개인 데이터가 로컬에서 정확하고 예측 가능하게 보존·차단·삭제되는 것**이다. 현재는 잠금과 영속화의 fail-open/false-success 때문에 공개 출시 전 수정이 필요하다.


---

# Performance, Reliability & Test Audit

## 결론

현재 테스트는 상태 변경과 일부 설정·현지화·이미지 보존을 확인하는 단위 테스트 한 파일에 집중돼 있다. 가장 큰 공백은 **손상·쓰기 실패·대용량 이미지·App Group 배포 서명·앱 잠금 실패·접근성·Release archive**다. 테스트 수를 늘리는 것보다 P0 사용자 약속을 계약으로 고정하는 것이 우선이다.

## 현재 테스트 상태

| 범주 | 현재 상태 | 평가 |
|---|---|---|
| 단위 테스트 | `ios/ClipInboxTests/AppStoreTests.swift` 한 파일, 저장소 기준 약 14개 테스트 메서드 | 기본 mutation·설정 회귀에는 유효하나 실패 경로가 거의 없음 |
| 통합 테스트 | AppStore와 실제 임시 파일을 사용하는 일부 테스트 | App Group queue·migration·asset transaction 범위 부족 |
| UI/E2E | 자동 UI 테스트 target을 확인하지 못함 | 핵심 Add/Share/Lock 흐름을 보호하지 못함 |
| Share Extension | 저장소의 수동 simulator 증거는 있음 | 대형 이미지·host 차이·timeout·signed build는 미검증 |
| 접근성 | 자동/수동 증거 부족 | 출시 전 별도 gate 필요 |
| 성능 | benchmark·budget 없음 | 현재 전체 JSON 구조의 안전 한계를 모름 |
| CI | `.github/workflows`를 확인하지 못함 | PR 품질 게이트 부재 |

## 성능 병목 후보

| 영역 | 현재 구현 | 사용자 영향 | 측정 방법 | 권장 개선 | 우선순위 |
|---|---|---|---|---|---|
| 영속화 | 매 mutation마다 전체 pretty JSON atomic write | 데이터 증가 시 저장 지연·쓰기 실패 | 100/1k/5k/10k clip save p50/p95 | StorageActor + DB/journal + coalescing | P1 |
| 검색 | 배열 전체 substring scan | 5k+에서 typing lag | signpost query latency | normalized index/SQLite FTS | P2 |
| 썸네일 | 원본 파일 기반 UIImage decode 가능성 | scroll OOM/jank | XCTMemoryMetric, Instruments | ImageIO target-size downsample | P1 |
| Share Extension | 원본 Data/UIImage 전체 적재 | 대형 사진에서 extension 종료 | 12/24/48MP, ProRAW matrix | file copy, byte/pixel cap, preview downsample | P0 |
| 이미지 cache | 비용 제한 증거 없음 | 장시간 사용 메모리 증가 | cache hit/memory warning | totalCostLimit·purge | P1 |
| App Group queue | unbounded files | 저장 공간 누적·import 지연 | 10/100/1k pending items | quota·TTL·quarantine | P1 |

## 권장 성능 예산

- Cold launch to interactive: 보통 기기 p95 1.5초 이하, 5,000 clip fixture 2.5초 이하.
- 검색: 5,000개에서 입력 후 첫 결과 p95 100ms 이하.
- Inbox scroll: 대표 기기에서 55fps 이상, decoded image memory가 화면 수에 비례해 제한됨.
- 단일 공유: URL/text p95 1초 내 durable enqueue; confirmation 대기 제외.
- 이미지 공유: 25MB/48MP 입력에서도 crash 없이 제한·최적화·오류 중 하나로 결정적 종료.
- 주 저장 실패율: release candidate fault injection에서 false-success 0건.

## 필수 테스트 매트릭스

| 기능 | 단위 | 통합 | UI/E2E | 실기기/배포 | 현재 공백 |
|---|---|---|---|---|---|
| snapshot load/save | 필수 | 필수 | 선택 | 파일 보호 | corruption·rollback |
| import/export | 필수 | 필수 | 필수 | 공유 대상 | version·object budget·평문 경고 |
| Share URL/text/image | provider fakes | App Group | host flow | Safari/Photos | timeout·대형 이미지·signing |
| 앱 잠금 | state machine | lifecycle | UI | Face ID/passcode | fail-open·snapshot |
| 검색/필터 | 필수 | DB/index | UI | 성능 | 5k+·Unicode |
| 삭제/복원 | 필수 | asset transaction | UI | 낮은 디스크 | Undo·trash·rollback |
| 현지화/접근성 | formatter | — | snapshot/audit | VoiceOver | AX5·긴 번역·contrast |
| release | — | archive script | smoke | signed install | privacy report·appex embed |

## 상세 테스트 케이스

| ID | 테스트 이름 | 목적 | 사전 조건 | 입력 | 수행 절차 | 예상 결과 | 실패 영향 | 자동화 |
|---|---|---|---|---|---|---|---|---|
| T-001 | 정상 첫 실행 | 저장소가 없을 때 빈 상태가 생성되는지 | 앱 데이터 없음 | 앱 실행 | 저장 파일 없음 상태로 실행 | 샘플이 아닌 안내형 빈 상태; 정상 저장소 생성 | High | 자동화 |
| T-002 | 손상 JSON 복구 | truncated snapshot이 데이터 유실로 위장되지 않는지 | 정상 current와 .bak 준비 | current를 절반으로 자름 | 앱 재실행 | 손상 파일 격리, .bak 복구 안내, 샘플로 대체하지 않음 | Critical | 자동화 |
| T-003 | 미지원 미래 버전 | version=999 import 차단 | 미래 버전 fixture | Import 실행 | 파일 선택 후 확인 | unsupported version 오류; 기존 데이터 불변 | Critical | 자동화 |
| T-004 | v1→현재 migration | 기존 데이터 보존 | v1 fixture | 앱 업그레이드/Import | migration 수행 | 클립 수·폴더·설정 보존, current version 저장 | Critical | 자동화 |
| T-005 | 저장 실패 rollback | mutation false-success 방지 | 쓰기 실패 fake repository | 즐겨찾기 토글 | 토글 후 저장 실패 유도 | UI 원상복구, 오류 배너, 성공 토스트 없음 | Critical | 자동화 |
| T-006 | disk full 삭제 | 삭제 중 영속화 실패 | ENOSPC fake | 클립 삭제 | disk full 유도 | 클립·이미지 모두 유지, 재시도 제시 | Critical | 자동화 |
| T-007 | delete all 실패 | 전체 삭제 원자성 | 여러 클립/이미지 | 모두 삭제 | persist 실패 유도 | 원 데이터 유지, UserDefaults도 롤백 | Critical | 자동화 |
| T-008 | queue 중복 import | 삭제 실패 후 idempotency | 동일 UUID queue item | 앱 두 번 실행 | 첫 import 후 remove 실패 | 클립은 한 번만 생성, cleanup 재시도 | High | 자동화 |
| T-009 | 손상 queue quarantine | 손상 공유 payload 가시성 | 잘못된 JSON 파일 | 앱 실행 | queue import | 파일 quarantine, 진단/복구 수치 증가, 무한 재시도 없음 | High | 자동화 |
| T-010 | queue 시간 정렬 | 연속 공유 순서 보존 | createdAt이 다른 3개 UUID | 3회 공유 | 앱 import | createdAt 순서대로 inbox 삽입 | Medium | 자동화 |
| T-011 | Safari URL quick save | 기본 핵심 흐름 | Quick 모드/앱그룹 정상 | https URL | Safari 공유→ClipInbox | confirmation 후 앱에 URL 1건 저장 | Critical | 실기기/E2E |
| T-012 | 선택 텍스트 review save | 텍스트 캡처 | Review 모드 | 긴 다국어 텍스트 | 공유→폴더/태그/메모 편집→저장 | 정규화된 텍스트·선택값 저장 | High | 실기기/E2E |
| T-013 | Photos HEIC 원본 | 포맷·크기 보존 | HEIC 사진 | 12MP HEIC | Photos 공유 | 지원 정책대로 원본 또는 변환 자산 저장, 메타 정확 | High | 실기기/E2E |
| T-014 | 대형 48MP 사진 | extension memory 안정성 | 저메모리 기기 | 매우 큰 ProRAW/HEIC | Photos 공유 | 명시적 제한/최적화 안내, extension crash 없음 | Critical | 실기기/성능 |
| T-015 | provider timeout | 멈춘 NSItemProvider 처리 | timeout fake provider | 응답 없음 | 공유 실행 | 정해진 시간 후 취소/재시도 UI, host 복귀 가능 | High | 자동화+E2E |
| T-016 | 이미지 저장 중 실패 | asset/queue transaction | 이미지 write 성공, payload write 실패 | 이미지 공유 | enqueue 실패 유도 | 새 이미지 제거, 오류 표시, 고아 없음 | High | 자동화 |
| T-017 | 앱그룹 권한 실패 | 배포 signing 오류 처리 | 잘못된 entitlement build | URL 공유 | Share Extension 실행 | 구체 오류와 취소, 가짜 성공 없음 | Critical | signed E2E |
| T-018 | 잠금 capability 없음 | fail-closed 확인 | 생체/패스코드 사용 불가 | 앱 잠금 켜기 | 설정·재실행 | 설정 차단 또는 잠금 유지; 콘텐츠 노출 없음 | Critical | 실기기 |
| T-019 | Face ID 취소 | 인증 취소 시 상태 | 잠금 켜짐 | 사용자 취소 | 앱 foreground | 잠금 화면 유지, 우회 경로 없음 | Critical | 실기기 |
| T-020 | background snapshot | 앱 전환기 비공개 | 민감 이미지 상세 열림 | 홈 제스처 | 앱 전환기 보기 | opaque shield만 보임 | High | 실기기/UI |
| T-021 | 잠금 중 deep link/share import | lifecycle 경쟁 | 앱 잠금 상태+pending queue | 공유 후 앱 열기 | 인증 전후 관찰 | 인증 전 데이터 노출 없음; 인증 후 한 번 import | High | E2E |
| T-022 | 실제 Add URL | 데모 제거 검증 | 빈 앱 | 정상 URL | Add→URL→저장 | 사용자 입력 URL/제목이 저장, 샘플 값 없음 | Critical | UI 자동화 |
| T-023 | Add 잘못된 URL | 입력 검증 | Add 폼 | javascript: URL | 저장 | 차단과 수정 안내; 기존 데이터 불변 | High | 자동화 |
| T-024 | 중복 URL | canonical duplicate 처리 | 기존 URL 있음 | utm만 다른 동일 URL | 저장 | 중복 안내와 merge/별도 저장 선택 | Medium | 자동화 |
| T-025 | 삭제 Undo | 오삭제 복구 | 클립 1개 | 삭제 후 Undo | 행 삭제→배너 Undo | 원 위치·태그·이미지 복원 | High | UI 자동화 |
| T-026 | 휴지통 만료 | 보존 정책 | 삭제 30일 전 fixture | 시간 진행 | trash cleanup | 만료 항목만 제거, 사용자 설정 준수 | High | 자동화 |
| T-027 | JSON export plaintext warning | 민감정보 고지 | 민감 메모 포함 | Export | 설정→내보내기 | 평문 위험·파일 범위 설명 후 명시적 확인 | Medium | UI 자동화 |
| T-028 | 암호화 export roundtrip | 선택적 안전 백업 | 클립/이미지/설정 | 암호 사용 | export→새 설치 import | 모든 항목 복원, 오암호 시 기존 데이터 불변 | High | 자동화 |
| T-029 | Import 5MB 경계 | 파일 크기 정책 | 4.99/5.01MB fixtures | Import | 두 파일 각각 선택 | 경계 이하 처리, 초과는 즉시 명확히 거절 | Medium | 자동화 |
| T-030 | Import 객체 폭탄 | 개수 제한 | 5MB 내 수만 개 object | Import | 파일 선택 | budget 초과 거절, UI hang 없음 | High | 성능 자동화 |
| T-031 | 검색 5,000개 | typing latency | 5k fixture | 한국어/영어/URL query | 연속 입력 | p95 결과 100ms 목표, frame hitch 없음 | Medium | 성능 |
| T-032 | 목록 1GB 이미지 라이브러리 | thumbnail memory | 대형 이미지 1GB | 빠른 스크롤 | Inbox 스크롤 | downsampled thumbnail, memory 안정, OOM 없음 | High | 성능/실기기 |
| T-033 | Dynamic Type AX5 | 큰 글자 재배치 | AX5 설정 | 모든 화면 | Inbox→Detail→Settings→Share | 잘림/축소/겹침 없이 scroll/reflow | High | UI snapshot+수동 |
| T-034 | VoiceOver 핵심 흐름 | 의미론·순서 | VoiceOver 켬 | 저장/폴더 이동/삭제 | 핵심 플로우 수행 | 라벨·상태·힌트·confirmation이 논리 순서로 읽힘 | High | 접근성 수동 |
| T-035 | 터치 영역 감사 | 44pt 기준 | 일반 설정 | chips/ellipsis/close | hit-test 측정 | 모든 컨트롤 최소 44x44 | High | 자동/수동 |
| T-036 | 영어 긴 번역 | 레이아웃 탄력성 | English | 긴 folder/tag 이름 | 모든 화면 탐색 | 중요 텍스트 잘림 없음; grid reflow | Medium | snapshot |
| T-037 | 일본어 입력/검색 | Unicode 정규화 | Japanese | 전각/반각/조합문자 | 저장 후 검색 | 정규화 결과 일관, 데이터 변형 없음 | Medium | 자동화 |
| T-038 | RTL pseudo-language | 향후 방향성 안전 | RTL pseudo locale | 모든 화면 | 탐색 | 아이콘·정렬·back 의미가 올바름 | Low | snapshot |
| T-039 | iPad split view | 반응형 레이아웃 | iPad | 1/3, 1/2, full widths | 회전·분할 | 정보 손실 없이 적응, 상세 탐색 효율 유지 | Medium | UI 자동/수동 |
| T-040 | 다크/고대비 | 색 대비 | Dark+Increase Contrast | 모든 상태 | 화면 탐색 | 텍스트/상태/선택 대비 기준 충족 | High | 자동 contrast+수동 |
| T-041 | 메모 1,000자 경계 | 길이 정책 | 상세 편집 | 999/1000/1001자 | 저장 | 정확한 제한·counter·데이터 손실 없는 안내 | Medium | 자동화 |
| T-042 | 폴더 rename 충돌 | 참조 일관성 | 2개 폴더/클립 | 기존 이름으로 rename | 저장 | 거절, 모든 clip 참조 불변 | High | 자동화 |
| T-043 | 폴더 삭제/병합 | 안전한 분류 정리 | 폴더 내 여러 clip | 폴더 삭제 | 대상 선택→확인 | 클립 이동·폴더 삭제가 한 transaction | High | 자동화 |
| T-044 | 앱 종료 중 persist | lifecycle durability | 편집 직후 종료 | memo 변경 | 즉시 app kill | 정의된 commit 시점 이전/이후 동작 일관, 손상 없음 | High | 실기기 |
| T-045 | 저장 공간 임계치 | 사전 경고 | 낮은 디스크 | 이미지 공유 | 용량 부족 유도 | 저장 전 예측·오류 후 고아 없음·정리 진입점 | Critical | 실기기 |
| T-046 | Privacy Manifest archive | Required Reason 검증 | Release archive | xcprivacy | archive→privacy report | 선언/실사용 일치, validation warning 0 | Critical | release gate |
| T-047 | Extension embedding | 배포 산출물 확인 | Release archive | 앱 archive | unzip/validate | appex 포함, bundle/app group/signing 일치 | Critical | release gate |
| T-048 | 네트워크 무통신 검증 | local-only 약속 | clean install | 일반 사용 전체 | proxy/network log | 사용자가 요청한 링크 열기 외 개발자 서버 전송 없음 | Critical | release privacy |


## CI 권장 파이프라인

1. **fast checks**: YAML/JSON/plist 검증, XcodeGen generate 후 diff 0, SwiftFormat/SwiftLint(채택 시), secret scan.
2. **unit/integration**: iOS simulator에서 unit tests, corrupt/migration/failing-storage fixtures.
3. **UI/accessibility**: 대표 iPhone/iPad, 3개 언어, light/dark, AX5 snapshot 및 `performAccessibilityAudit`.
4. **extension harness**: mock host/provider와 App Group container로 URL/text/image queue E2E.
5. **release candidate**: Release archive, embedded appex/entitlement/bundle ID 검사, privacy report, export validation.
6. **manual signed gate**: Safari·Photos·Face ID·낮은 저장 공간·앱 전환기·TestFlight 업데이트 검증 증거 첨부.

CI 로그에는 클립 본문·URL·이미지 이름을 남기지 않는다. 실패 fixture는 합성 데이터만 사용한다.


---

# Competitor & Market Analysis

- 조사 기준일: 2026-07-11
- 가격은 국가·통화·세금·프로모션에 따라 달라질 수 있다. 본 표는 확인 가능한 공식 페이지/스토어 또는 명시된 현재 공개 가격을 기준으로 하며, 실제 구매 화면에서 재확인해야 한다.
- ClipInbox는 전통적 clipboard history와 read-later/bookmark manager 사이에 위치한다. 직접 경쟁과 대체 행동을 분리해야 한다.

## 1. 시장 포지셔닝 맵

```text
자동 클립보드 기록  <---------------------------->  사용자가 명시적으로 저장
Paste / PastePal / Maccy                         ClipInbox / Anybox / GoodLinks

단순 재사용  <-------------------------------------------->  장기 지식 관리
Maccy / Pastery                 ClipInbox       Raindrop / Reader / mymind

로컬 전용  <--------------------------------------------->  계정·클라우드 중심
Maccy / Pastery / ClipInbox          GoodLinks     Raindrop / Reader / mymind
```

**권장 포지션:** “iPhone/iPad에서 어디서든 공유하고, 계정 없이 로컬에 모아 두는 가장 단순한 캡처 인박스.”

## 2. 경쟁 제품 비교

| 앱 | 분류 | 플랫폼 | 핵심 기능 | 강점 | 약점/ClipInbox 기회 | 가격(조사 시점) | 개인정보 방식 | ClipInbox가 참고할 점 |
|---|---|---|---|---|---|---|---|---|
| Paste | 직접/상위 clipboard | macOS, iPhone, iPad | 무제한 history, search, pinboards, sync, collaboration | 세련된 UI, 기기간 연속성, 강한 브랜드 | subscription 부담, 광범위 history가 privacy anxiety 유발 가능 | 연간 약 US$29.99, 월 환산 US$2.49; lifetime 옵션 표기 | 동기화형 | 검색 속도, visual timeline, pinboard; 단 자동 수집을 모방하지 않음 |
| PastePal | 직접/clipboard | Apple platforms | history, collections, iCloud sync, keyboard/share/action extensions, widgets, Siri | universal one-time, Apple 생태계 통합 | 기능이 많아 학습 부담; ClipInbox는 더 단순할 수 있음 | 약 US$14.99 one-time | 로컬 + 선택 iCloud | extension 생태계, collection, one-time pricing |
| Maccy | 직접 대체(Desktop) | macOS | lightweight clipboard history, keyboard search | 빠르고 open-source, keyboard-first | 모바일 Share-to-Inbox·이미지 정리에는 약함 | 무료/open-source, 후원/스토어 배포 변동 | 로컬 중심 | 즉시 검색, keyboard efficiency, 최소 UI |
| Pastery | 직접 대체(Desktop) | macOS | local timeline, text/images/links/colors/files, OCR, filters, transforms | local-only와 rich type 처리 | iOS capture inbox가 아님 | 공식 구매 화면 확인 필요 | 로컬 전용 강조 | 콘텐츠 타입별 smart action, OCR는 on-device로 참고 |
| Anybox | 인접/북마크 | iPhone, iPad, Mac | links, notes, images/files, nested tags/folders, smart lists, automation, Spotlight, share extension | 매우 넓은 Apple 통합, local/iCloud 선택, lifetime 제공 | 고급 기능이 많아 가벼운 inbox 사용자에는 과함 | 무료 50 links; Pro 약 US$1.99/mo, US$14.99/yr, US$39.99 lifetime | iCloud, no-data-collection 표방 | smart lists, Spotlight, URL schemes, import/export 완성도 |
| GoodLinks | 인접/read-later | iPhone, iPad, Mac | clean reader, offline article, tags/search, widgets/Shortcuts | no-account/private 메시지, one-time universal purchase | 링크/기사 중심이라 이미지·텍스트 임시 수집 범위 제한 | 약 US$9.99 one-time | iCloud sync, tracking 없음 표방 | 투명한 one-time 가치, reader는 장기 후보 |
| Raindrop.io | 인접/bookmark platform | Web, iOS, Android, desktop, extensions | unlimited bookmarks/collections, full-text, archive, duplicate/broken link, AI suggestions | cross-platform·성숙한 검색·import | 계정/클라우드, 제품이 무겁고 local-only 아님 | Free; Pro 지역별, 공개 자료에서 대략 US$28/yr 수준 | cloud account | duplicate finder, web archive, broad import는 장기 비교 기준 |
| Readwise Reader | 인접/read-it-later | Web, mobile | read-later, highlights, tags, notes, export, feeds/documents | 읽기·하이라이트·knowledge workflow 강함 | 높은 구독료와 복잡성; quick local inbox와 목적 다름 | 연간 결제 월 US$9.99, 월 결제 US$12.99 수준 | cloud account | capture 후 소비 workflow; ClipInbox는 읽기 앱이 되지 않도록 경계 |
| mymind | 인접/AI visual memory | Web, mobile, extensions | AI tagging, OCR/image search, smart spaces, reading mode, backup | 분류 없는 저장과 시각적 재발견 | 구독·AI/cloud 의존, 사용자 제어 약할 수 있음 | Bookmarker 약 US$4.99/mo부터 | cloud/AI | “저장 먼저, 자동 정리 나중” 가치; local AI일 때만 차용 |
| Apple Notes/Files/Photos + Share Sheet | OS 대체 | Apple platforms | 공유, 메모, 파일/사진 보관, iCloud | 이미 설치, 신뢰, 무료, 시스템 통합 | 콘텐츠가 여러 앱에 흩어지고 capture inbox 관점 없음 | OS 포함 | Apple 계정/기기 설정 | ClipInbox의 진짜 경쟁은 별도 앱 설치 비용; 첫 저장을 극단적으로 단순화 |
| Safari Reading List/Bookmarks | OS 대체 | Apple platforms | 링크 저장, offline reading | friction 낮음 | 이미지·텍스트·태그·임시 triage 부족 | OS 포함 | Apple 생태계 | 링크만 저장하려는 사용자에게 더 나은 이유를 명확히 해야 함 |

## 3. 직접 경쟁 vs 간접 경쟁

### 직접 경쟁

- Paste, PastePal: Apple 생태계에서 빠른 재사용과 clipboard history를 제공한다.
- Maccy, Pastery: local-first·빠른 검색·최소 UI의 기준점이다.

ClipInbox는 이들과 “모든 복사를 자동 기록”으로 경쟁하면 iOS 제약과 개인정보 신뢰에서 불리하다. 대신 **명시적으로 공유한 것만 보관**해 데이터 최소화와 의도성을 차별점으로 삼는다.

### 인접 경쟁

- Anybox, GoodLinks, Raindrop, Readwise Reader, mymind
- 이들은 장기 보관·검색·읽기·지식 관리가 강하다.
- ClipInbox는 캡처 순간과 짧은 backlog triage에서 더 빠르고 가벼워야 한다.

### OS 기본 기능

가장 강한 대체재는 유료 경쟁 앱이 아니라 Notes, Safari, Files, Photos에 각각 공유하는 현재 행동이다. 따라서 “한 곳에 모인다” 외에도 다음을 증명해야 한다.

- 분류하지 않고도 1초 내 저장
- 최근/미정리만 빠르게 다시 보기
- 중복·휴지통·검색으로 안전하게 관리
- 계정·업로드 없음

## 4. 시장 표준 기능

### 출시 전 기본값으로 간주해야 할 것

1. 빠른 Share Extension
2. 명확한 search
3. folders/tags 또는 collections
4. favorites/pins
5. import/export
6. dark mode
7. duplicate handling
8. delete recovery
9. storage/privacy explanation
10. 여러 기기 또는 최소한 안전한 백업 경로
11. onboarding/help
12. accessibility

현재 ClipInbox는 1–6의 상당 부분을 갖췄지만 7–12가 약하다.

### 차별화가 가능한 것

- local-only 기본값과 no-account
- 명시적으로 공유한 항목만 수집
- Quick vs Review save
- “Unsorted”를 중심으로 한 inbox triage
- 한국어·영어·일본어를 출시 초기부터 제공
- 원본 이미지/텍스트/URL을 하나의 단순 모델로 보관
- local diagnostic/export로 투명성 제공

### 개발 대비 효과가 낮은 것

- 초기 서버 AI summarization
- social collaboration/team spaces
- full web scraping/archive
- 광고·추천 feed
- 모든 플랫폼 동시 출시
- 전통 clipboard 자동 history를 iOS에서 억지로 재현

## 5. 경쟁 UI 패턴

| 패턴 | 경쟁 제품 경향 | ClipInbox 권고 |
|---|---|---|
| 첫 화면 | timeline 또는 library | Inbox list + Unsorted/Favorites smart views |
| 캡처 | share extension/browser extension/clipboard | Share Extension을 1급 기능으로, manual Add 보조 |
| 검색 | always-visible quick search, filters | Search tab 유지, Inbox 상단 과밀 filter 축소 |
| 분류 | pinboards/collections/tags/spaces | folder=location, tag=attribute, smart view=system으로 역할 분리 |
| 상세 | preview + actions + note | 고정 1 viewport 목표보다 accessible scroll 우선 |
| 이미지 | visual grid/preview/OCR | 기본은 list, image smart view에서 adaptive grid 후보 |
| 삭제 | trash/restore 또는 history retention | 30일 Trash + immediate Undo |
| 개인정보 | local/iCloud/no tracking messaging | “기본 local-only, 공유한 것만”을 모든 onboarding/metadata에 반복 |
| 결제 | subscription, one-time, freemium 혼재 | local-only 동안 one-time 또는 free+one-time Pro |
| 설정 | sync, retention, exclusions, shortcuts | capture behavior, storage, privacy, backup를 상단에 배치 |

## 6. 사용자 불만 기회

경쟁 카테고리에서 반복적으로 발생하는 제품 긴장은 다음과 같다.

- subscription fatigue
- clipboard를 전부 기록하는 privacy concern
- sync conflict/계정 의존
- 기능 과잉과 복잡한 folder/tag 체계
- 검색은 강하지만 삭제/보존 통제가 불명확
- iOS와 Mac 기능 차이
- Share Extension이 느리거나 실패 상태가 불명확

ClipInbox는 “더 많은 기능”이 아니라 아래 약속으로 이 문제를 해결할 수 있다.

> **내가 공유한 것만, 내 기기에, 즉시 저장되고, 언제든 내보내고 완전히 지울 수 있다.**

이 문장은 현재 false-success, 손상 fallback, 영구 삭제, 불완전 export 때문에 아직 코드로 완전히 보장되지 않는다. 제품 마케팅 전에 구현 계약을 먼저 맞춰야 한다.

## 7. 가격·수익화 비교 해석

- Paste는 반복 가치와 sync/collaboration으로 subscription을 정당화한다.
- PastePal·Anybox·GoodLinks는 Apple 생태계의 local/iCloud utility에 one-time/lifetime 옵션을 제공한다.
- Raindrop·Reader·mymind는 서버 검색·archive·AI·feed처럼 지속 비용이 있어 subscription이 자연스럽다.

**ClipInbox 권고:**

- 1.0: one-time purchase 또는 free core + one-time Pro
- 무료/core에서 데이터 안전, export, trash, accessibility를 제한하지 않음
- Pro: OCR, batch actions, Shortcuts/Spotlight, advanced search, large image policy
- subscription: 자체 sync/AI가 실제 반복 비용을 만들 때만 별도 플랜

## 8. 차별화 전략

### 메시지

- “Clipboard manager”보다 “Private capture inbox”
- “No account. No server. No tracking.”은 실제 binary 검증 후 사용
- “Share once, sort later.”

### 1.0에서 이겨야 하는 5개 순간

1. 설치 후 첫 URL을 30초 안에 저장
2. Share Sheet에서 Quick save가 결정적으로 성공/실패
3. 100개가 쌓여도 최근·미정리·검색으로 즉시 찾음
4. 실수 삭제를 되돌림
5. 사용자가 언제든 전체 백업·삭제 범위를 이해함

## 9. 소스 레지스터

- Paste 공식 사이트/가격: https://pasteapp.io/
- PastePal 공식 사이트/App Store 안내: https://indiegoodies.com/pastepal
- Maccy 공식 사이트: https://maccy.app/
- Pastery 공식 사이트: https://pastery.app/
- Anybox 공식 사이트/가격: https://anybox.app/
- GoodLinks 공식 사이트: https://goodlinks.app/
- Raindrop Pro: https://raindrop.io/pro/buy
- Readwise pricing: https://readwise.io/pricing
- mymind pricing: https://mymind.com/pricing
- Apple App Review Guidelines: https://developer.apple.com/app-store/review/guidelines/

가격·기능은 조사일 이후 변경될 수 있으므로 출시 직전 재확인한다.


---

# Feature & Product Roadmap

## 전략 원칙

1. 데이터 신뢰가 기능 수보다 우선이다.
2. 제품의 중심은 “클립보드 감시”가 아니라 **사용자가 공유한 것을 즉시 로컬 인박스에 보관**하는 경험이다.
3. 계정·서버 없는 기본값을 지킨다. 동기화·AI는 명확한 opt-in과 별도 가치로만 추가한다.
4. 분류를 강요하지 않는다. 먼저 저장하고, 나중에 빠르게 정리하는 흐름을 강화한다.
5. iOS에서 PMF를 확인하기 전 Android·웹·팀 협업으로 확장하지 않는다.

## 기능 평가

| 기능 | 사용자 가치(10) | 차별성(10) | 개발 난이도 | 보안/개인정보 위험 | 추천 시점 | 최종 판단 |
|---|---:|---:|---|---|---|---|
| 실제 수동 Add | 10 | 7 | M | Low | P0 즉시 | 즉시 구현 |
| 손상 복구·버전 migration | 10 | 5 | M | Low | P0 즉시 | 즉시 구현 |
| 휴지통·Undo | 9 | 5 | M | Low | 1차 출시 | 즉시 구현 |
| 중복 URL/텍스트 감지 | 8 | 6 | M | Low | 1차 출시 | 즉시 구현 |
| 저장 공간 대시보드·보존 정책 | 9 | 7 | M/L | Low | 1차 출시 | 즉시 구현 |
| Share Extension 온보딩 | 9 | 5 | M | Low | 1차 출시 | 즉시 구현 |
| 고급 검색 필터 | 8 | 5 | L | Low | 1.1 | MVP 이후 |
| 배치 정리·다중 선택 | 8 | 5 | L | Low | 1.1 | MVP 이후 |
| URL 메타데이터/미리보기 | 8 | 4 | L | Medium | 1.1 | MVP 이후 |
| 온디바이스 OCR | 7 | 7 | L | Medium | 1.2 | 유료 기능 후보 |
| Core Spotlight | 7 | 6 | M | Low | 1.2 | MVP 이후 |
| Shortcuts/App Intents | 7 | 6 | L | Low | 1.2 | 유료 기능 후보 |
| 홈/잠금 화면 위젯 | 6 | 4 | M | Medium | 1.2 | 유료 기능 후보 |
| 선택적 iCloud 동기화 | 9 | 6 | XL | High | 2.0 | 유료 기능 후보 |
| Mac companion | 8 | 7 | XL | Medium | 2.0+ | 장기 검토 |
| 로컬 의미 검색 | 7 | 8 | XL | Medium | 2.0+ | 장기 검토 |
| 서버 AI 자동 요약 | 5 | 4 | XL | High | 보류 | 구현 비추천 |
| 광고 기반 무료화 | 2 | 1 | M | High | 보류 | 구현 비추천 |
| 백그라운드 무단 클립보드 감시 | 3 | 2 | XL | High | 보류 | 구현 비추천 |


## Release 0.4 — Data-Safe Alpha

- snapshot 복구·backup rotation·schema migration
- 모든 mutation transaction/rollback
- Share Extension 이미지 limit/timeout/quarantine
- 잠금 fail-closed·app switcher shield
- 실제 Add 폼
- CI 기본 build/unit/migration checks

**Exit criteria:** fault injection에서 false-success 0건, 손상 fixture 전부 복구/명시 오류, 48MP 사진에서 extension crash 0건.

## Release 0.5 — Usable Private Beta

- 첫 실행/Share Extension 온보딩
- 휴지통·Undo
- Dynamic Type/VoiceOver/44pt 전면 개선
- storage dashboard·보존 정책
- queue diagnostics
- 실기기 Safari/Text/Photos/Face ID/iPad matrix

**Exit criteria:** AX5·3개 언어·light/dark blocker 0, signed TestFlight에서 핵심 흐름 통과.

## Release 1.0 — Public App Store

- 실소유 privacy/support URLs, monitored email
- App Store metadata/screenshots/privacy answers
- 정확한 로컬 전용·잠금 범위 설명
- duplicate detection, 안정된 search/filter
- signed archive/privacy report/appex validation
- crash-free 기준과 rollback plan

## Release 1.1–1.2 — Retention & Power User

- batch triage, smart lists, advanced search
- URL metadata·offline preview 정책
- Core Spotlight, App Intents, widgets
- 온디바이스 OCR와 smart actions

## Release 2.0 후보

- 선택적 CloudKit 동기화: 로컬 전용 기본값을 유지하고 conflict history·복구 로그를 제공한다.
- Mac companion: iOS 캡처와 데스크톱 재사용의 결합이 구독/유료 업그레이드의 가장 자연스러운 근거다.
- 로컬 의미 검색: 장치 성능·모델 크기·배터리 예산이 충족될 때만 제공한다.

## 수익화 권고

### 권장안 A — 일회성 구매

- 가장 단순하고 제품 철학과 일치한다.
- 앱 자체가 로컬 기능만 제공하는 동안 구독을 강제할 지속 비용 근거가 약하다.
- 출시 초기에는 지역별 일회성 가격 A/B가 아닌 단일 투명 가격을 권장한다.

### 권장안 B — 무료 Core + 일회성 Pro

- 무료: 무제한 또는 합리적 수의 텍스트/URL 저장, 검색, 폴더, export.
- Pro: 대용량 이미지, OCR, batch actions, Shortcuts, advanced filters, Mac companion.
- 데이터 복구·휴지통·접근성·암호화 같은 신뢰 기능은 유료 장벽 뒤에 두지 않는다.

### 구독이 정당화되는 조건

- 사용자가 선택한 CloudKit 이상의 운영형 동기화 서비스, 지속 서버 AI, 팀 기능처럼 실제 반복 비용이 발생할 때만 별도 플랜으로 검토한다.
- 광고·데이터 판매는 프라이버시 포지셔닝과 직접 충돌하므로 배제한다.

## 성장 전략

- “공유 시트에서 1초, 계정 없음, 서버 없음”을 첫 메시지로 사용한다.
- 인테리어·디자인 레퍼런스 수집, 읽을거리, 쇼핑 후보, 여행 링크 등 3–4개 구체 use case로 스토어 스크린샷을 구성한다.
- 초기 평가는 기능 수가 아니라 저장 성공률, 첫 공유 완료율, 7일 재검색률, 삭제 복구율로 측정한다.
- 개인정보 지표를 보내지 않는다면 사용자가 직접 진단 리포트를 선택적으로 export하는 운영 경로를 만든다.


---

# Release & Deployment Readiness Audit

## 1. 현재 판정

| 대상 | 준비도 | 판정 |
|---|---:|---|
| 로컬 개발/디자인 프로토타입 | 80% | 사용 가능 |
| Simulator 내부 QA | 65% | 저장소 자체 증거는 있으나 독립 재실행 필요 |
| 제한 TestFlight | 45% | P0 데이터·잠금·extension 문제 해결 전 부적합 |
| 외부 TestFlight | 35% | 실기기·정책 URL·CI·migration gate 필요 |
| App Store 공개 출시 | 30% | 현재 부적합 |
| Android/웹 배포 | 0–10% | 프로덕션 대상 아님 |

## 2. iOS 프로젝트 설정

### 확인된 값

| 설정 | 값 | 평가 |
|---|---|---|
| Project generator | XcodeGen, minimum 2.45.4 | 재현성 장점 |
| Xcode version declaration | 26.5 | CI image·실개발 환경과 일치 검증 필요 |
| Project format | xcode16_3 | 생성/열기 호환성 검증 |
| Swift | 5.10 | 안정적 |
| Deployment target | iOS 17.0 | 명확하나 구형 기기 제외 |
| Marketing version | 0.3.0 | pre-release 적절 |
| Build number | 1 | 배포마다 자동 증가 필요 |
| App bundle | `app.clipinbox.ClipInbox` | release ownership 확인 |
| Extension bundle | `app.clipinbox.ClipInbox.Share` | embed/sign 검증 |
| App Group | `group.app.clipinbox.ClipInbox` | distribution profile 포함 필요 |
| Device family | iPhone/iPad | UI matrix 필요 |
| Development Team | project.yml에 ID 하드코딩 | 환경 분리 필요 |
| Extension API only | YES | 적절 |

### 개선

- `Config/Base.xcconfig`, `Debug.xcconfig`, `Release.xcconfig`, `Local.xcconfig` 도입
- 개발팀·서명 스타일·정책 URL·feature flags를 소스와 분리
- build number를 CI run 또는 App Store Connect API 기준으로 증가
- Release에서 assert/debug sample/verbose log 제거
- bundle ID와 App Group을 smoke script로 비교
- XcodeGen 생성 후 git diff가 0인지 CI에서 확인

## 3. 서명·App Group·Share Extension

저장소 문서는 simulator에서 extension embed와 App Group import를 확인했다고 기록한다. 그러나 배포 서명은 다른 profile/entitlement 경로를 사용하므로 별도 gate가 필요하다.

### signed archive 검증

1. Distribution certificate/profile로 Release archive 생성
2. archive 내 `Products/Applications/Clip Inbox.app/PlugIns/ClipInboxShare.appex` 존재 확인
3. app/appex `codesign -d --entitlements :-` 비교
4. App Group identifier 양쪽 일치
5. bundle ID, application-identifier, team identifier 일치
6. `APPLICATION_EXTENSION_API_ONLY=YES` 위반 없음
7. `xcrun altool/notary`가 아니라 현재 Xcode Validate App/Transporter 경로로 preflight
8. TestFlight 설치 후 Safari/Photos/선택 텍스트 공유
9. 앱 업데이트 전후 pending queue와 주 snapshot migration 확인

`[검증 필요]` 실제 release Apple Developer team의 App ID/App Group/provisioning 상태는 저장소만으로 알 수 없다.

## 4. Privacy Manifest와 Required Reason API

- main app과 extension에 privacy manifest가 존재한다.
- UserDefaults 등 Required Reason API 선언은 실제 바이너리와 일치해야 한다.
- 최종 판정은 source file 존재가 아니라 **archive privacy report와 App Store upload validation**이다.
- SDK를 추가하지 않더라도 Xcode/Apple 정책이 변경될 수 있으므로 제출 직전 최신 요구를 다시 확인한다.

### Gate

- [ ] Release archive privacy report 생성
- [ ] main app/appex의 accessed API category와 reason code 일치
- [ ] 누락/중복 manifest warning 0
- [ ] App Privacy answers와 runtime network behavior 일치
- [ ] crash/analytics SDK가 없거나 정확히 공개됨

## 5. App Store Review 위험

| 위험 | 근거 | 심사 영향 | 해결 |
|---|---|---|---|
| 실제 Add가 demo 생성 | 핵심 CTA/기능 불일치 | 최소 기능성·오해 메타데이터 | 실제 capture 구현, 샘플 제거 |
| placeholder support/privacy | docs의 deferred 항목 | 제출 불가/거절 | 소유 HTTPS URL·monitoring email |
| “Face ID lock” 과장 | policy는 passcode fallback, fail-open 가능 | 기능/보안 설명 부정확 | 정확한 copy와 fail-closed |
| extension만 있고 도움 부족 | 사용자가 활성화 방법을 모름 | utility 부족·reviewer 재현 실패 | 앱 내 onboarding/help, review notes |
| screenshot와 현 UI 불일치 | UI가 여러 차례 변경됨 | 부정확한 metadata | release build에서 직접 캡처 |
| sample content | 실제 사용자 데이터처럼 보임 | 완성도·정확성 문제 | 선택형 demo 또는 명시 badge |
| 데이터 손실 경로 | 저장 failure/corruption | 품질·사용자 피해 | P0 data fixes |
| privacy answer 불일치 | local-only 주장 | policy violation | release network/SDK audit |
| 설명 없는 평문 export | 민감 데이터 앱 | privacy trust | warning/policy/암호 옵션 |
| iPad target이나 phone UI | iPad 지원 선언 | 품질 저하 | split-view/landscape QA 또는 family 범위 재검토 |

Apple은 앱 내부와 metadata에 개인정보 처리방침 링크, 정확한 설명·스크린샷, 완성된 URL, 실제 기기 테스트를 요구한다. extension을 제공하는 containing app은 사용자가 extension을 이해·관리할 수 있는 도움/설정 기능을 갖추는 것이 안전하다.

## 6. App Store 제출 자료

### 필수 메타데이터

- 앱 이름: 최종 상표/중복 확인
- subtitle: “Private Share-to-Inbox” 성격을 명확히
- description: URL/text/image, local-only, no account, backup 범위, lock 범위
- keywords: clipboard 오해를 피하면서 capture/inbox/bookmark/reference 중심
- category: Productivity 우선 검토
- age rating: 외부 웹 콘텐츠를 저장/열 수 있다는 점 반영
- support URL
- privacy policy URL
- marketing URL 선택
- copyright/rights holder
- app review contact
- review notes와 extension 재현 절차
- export compliance/암호화 답변
- App Privacy questionnaire
- 가격/지역

### 스크린샷 계획

1. “어디서든 공유해 한 곳에” — Share Sheet + Inbox
2. “분류하지 말고 먼저 저장” — Unsorted/Quick save
3. “폴더·태그·검색” — 실제 검색 결과
4. “이미지·링크·메모” — 다양한 실제 콘텐츠
5. “기본 로컬 저장” — privacy/settings
6. “삭제 복구와 백업” — Trash/export
7. iPad가 지원되면 sidebar/detail 실제 화면

데모 데이터는 상표·저작권·개인정보 문제가 없는 자체 제작 콘텐츠만 사용한다.

## 7. CI/CD 권장안

### Pull Request pipeline

```text
checkout
→ install pinned XcodeGen
→ xcodegen generate
→ fail if generated project diff
→ plist/json/xcprivacy validation
→ secret/license scan
→ Debug build (iPhone simulator)
→ unit + migration + failure-injection tests
→ UI/accessibility smoke
→ result bundle/artifact upload
```

### Main pipeline

- 위 PR gate
- Release simulator build
- 3개 언어 × light/dark snapshot
- performance smoke with 1k/5k fixtures
- changelog/version consistency

### Release candidate pipeline

- manual protected environment 승인
- signing certificate/profile/keychain 주입
- archive/export
- entitlements/appex/privacy report 검사
- TestFlight upload
- release notes 생성
- artifact hash/SBOM/archive retention
- Git tag는 외부 QA 승인 후 생성

### Branch protection

- main direct push 금지
- required review 1명 이상
- required checks
- secret scanning/dependabot 또는 동등한 자동 점검
- signed commits는 팀 정책에 따라 선택
- release tag 보호

## 8. 운영 모니터링

local-only 제품은 데이터 원문을 수집하지 않으면서 운영 가능해야 한다.

### 최소 구성

- MetricKit: crash/hang/memory 지표
- OSLog: category + redacted error code
- 선택적 crash reporter를 도입한다면 URL/메모/검색어/파일 경로 scrub
- 사용자가 직접 생성하는 진단 리포트: 버전, OS, queue counts, storage buckets, error codes만 포함
- 공개 support page: known issues, backup/recovery, Share Extension enable guide
- incident runbook: data corruption, signing/App Group, review rejection, privacy disclosure

### 권장 SLO

- crash-free sessions 99.8%+
- Share URL/text durable enqueue success 99.9%+
- supported image save deterministic completion 99.5%+
- data corruption recovery success 100% for previous-backup scenario
- false-success 0

원격 analytics가 없다면 SLO는 TestFlight opt-in diagnostics와 QA fault injection을 조합해 측정한다.

## 9. 문서·개발자 경험

### 현재 좋은 점

- source-of-truth와 XcodeGen workflow가 `AGENTS.md`에 명시됨
- task/decision/changelog/release 문서가 존재
- simulator 검증 명령과 evidence가 기록됨

### 부족한 문서

- 루트 README
- LICENSE
- SECURITY.md
- CONTRIBUTING.md
- `.github` issue/PR templates
- architecture/data schema/backup contract
- corruption recovery runbook
- release signing guide without personal path/device ID
- TestFlight/App Store rollback guide
- third-party asset notices

`AGENTS.md`의 예시 build 명령에는 특정 사용자의 로컬 path와 simulator UUID가 포함돼 있다. 일반 명령과 개인 override를 분리해야 한다.

## 10. Android·웹·데스크톱 배포

### Android

- 코드가 없으므로 현재 제출 대상이 아니다.
- iOS 1.0 전에 Android를 시작하지 않는다.
- 향후에는 Android의 clipboard/background 접근 정책을 별도로 설계하고, “조용한 수집”보다 share target 중심으로 제품 철학을 유지한다.

### 웹

- 현재 루트 웹은 정적 프로토타입이다.
- production web app으로 배포하려면 저장·보안·PWA·clipboard permission·sync·auth·privacy를 새로 설계해야 한다.
- 단순 GitHub Pages demo로 공개할 경우 샘플 데이터·모든 interaction이 실제 제품처럼 오해되지 않도록 “prototype” 표시가 필요하다.

### macOS

- 경쟁력 측면에서 Android보다 natural extension일 수 있다.
- iOS PMF 이후 Mac companion을 별도 target으로 검토하고, App Group/iCloud/backup 설계를 먼저 안정화한다.

## 11. 법적·정책·라이선스

- 루트 LICENSE 부재: 상업적·오픈소스 의도를 확정해야 한다.
- Pretendard와 이미지/아이콘 자산의 license notice·배포 권리를 기록한다.
- 개인정보 처리방침에 저장 위치, OS backup 가능성, export, 삭제, 연락처, 관할, policy 변경을 포함한다.
- 이용약관은 유료화·보증 제한·지원 범위를 명확히 하는 데 유용하다.
- “법률 검토 필요”가 개발 작업을 대체하지 않는다. 실제 URL, delete/export behavior, App Privacy answers를 코드와 일치시킨다.

## 12. Go/No-Go 기준

### No-Go

- P0 데이터 신뢰 이슈 1개 이상 열림
- 대형 이미지 extension crash
- 잠금 우회/fail-open
- 실제 Add 미구현
- privacy/support placeholder
- signed archive/appex validation 실패
- privacy manifest 또는 App Privacy 불일치

### Go to limited TestFlight

- P0 0개
- migration/failure-injection tests 통과
- signed physical device core flows 통과
- recovery/export 검증
- known P1을 release notes와 내부 risk register에 기록

### Go to App Store

- P0 0개, High P1 중 사용자 데이터·privacy·accessibility 관련 0개
- review assets/policy URLs 완성
- external TestFlight에서 blocker 0
- rollback archive와 support runbook 준비


---

# ClipInbox Master Issue List

- 기준일: 2026-07-11
- 우선순위: P0 출시 차단 / P1 출시 전 권장 / P2 출시 직후 / P3 중장기 / P4 선택
- 노력: S 수 시간 / M 1–3일 / L 4일–2주 / XL 2주+
- 상태는 정적 감사 결과이며, `검증 필요`는 macOS/Xcode·실기기·배포 계정 확인이 필요하다.

## 통계

- 총 101개 항목
- 심각도: Critical 12, High 40, Medium 42, Low 7
- 우선순위: P0 18, P1 51, P2 22, P4 1, P3 6, P0/P1 3
- 상태: 확인됨 78, 추정 9, 검증 필요 7, 기능 제안 7

## 통합 목록

| ID | 제목 | 유형 | 심각도 | 우선순위 | 관련 파일/영역 | 사용자 영향 | 수정 방향 | 작업량 | 상태 |
|---|---|---|---|---|---|---|---|---|---|
| DATA-001 | 손상된 주 스냅샷을 샘플 데이터로 대체 | Data/Reliability | Critical | P0 | ios/ClipInbox/Store/AppStore.swift:init | 손상·호환성 오류가 첫 실행처럼 보이고 이후 실제 파일을 덮어쓸 수 있음 | 파일 없음과 decode 실패를 분리; 손상 파일 격리; 마지막 정상 .bak 복구; 복구 UI 제공 | M | 확인됨 |
| DATA-002 | 다수 변경 작업이 persist 실패를 무시 | Data/Reliability | Critical | P0 | ios/ClipInbox/Store/AppStore.swift:mutate/delete/update/save | 성공 토스트 뒤 재실행 시 변경 유실, 메모리·디스크 불일치 | repository transaction을 도입하고 실패 시 rollback; 성공 UI는 durable commit 이후 표시 | L | 확인됨 |
| DATA-003 | 스냅샷 version 검증·마이그레이션 부재 | Data/Architecture | High | P0 | Models.swift:DataSnapshot, AppStore.swift:importJSON | 업데이트·미래 포맷 import 시 조용한 기본값 대체 또는 데이터 왜곡 | 지원 버전 allowlist, 단계별 Migrator, unsupportedVersion 오류, fixture 회귀 테스트 | M | 확인됨 |
| DATA-004 | localized 표시 문자열을 설정 값으로 영속화 | Data/I18N | Medium | P1 | Models.swift:Preferences, SharedClipConfiguration | 언어 변경·문구 수정 시 설정 해석이 깨지고 마이그레이션이 어려움 | Theme/Language/ShareMode/AppLock을 안정된 enum raw key로 저장하고 UI에서 번역 | M | 확인됨 |
| DATA-005 | 클립 시간을 Date가 아닌 상대 표시 문자열로 저장 | Data/UX | High | P1 | Models.swift:Clip.time, DefaultData | “방금 전”이 영구 고정되고 실제 정렬·날짜 필터·동기화가 불가능 | createdAt/updatedAt Date 저장, 표시 시 RelativeDateTimeFormatter 사용 | M | 확인됨 |
| DATA-006 | JSON 백업이 전체 사용자 상태를 포함하지 않음 | Data/UX | Medium | P1 | AppStore.swift + UserDefaults keys | 최근 검색·태그 카탈로그·링크 열기 설정 등이 복원되지 않아 “전체 백업” 기대와 불일치 | ExportEnvelope에 버전·preferences·catalog·optional assets manifest 포함 | M | 확인됨 |
| DATA-007 | Int 증가 ID와 import ID 범위 검증 부족 | Data | Medium | P2 | Models.swift:Clip.id, AppStore.swift nextID | 극단 값·중복·overflow에서 신규 저장 충돌 가능 | UUID 기본키로 이전; migration에서 기존 Int를 legacyID로 보존 | L | 추정 |
| DATA-008 | 모든 변경마다 전체 pretty JSON 재작성 | Data/Performance | High | P1 | AppStore.swift:persist | 클립·이미지 메타가 늘수록 UI 지연·쓰기 증폭·실패 면적 증가 | actor 기반 repository, SQLite/SwiftData 또는 append journal; 쓰기 coalescing | L | 확인됨 |
| DATA-009 | 휴지통·Undo 없이 영구 삭제 | Data/UX | High | P1 | AppStore.swift:deleteClip/deleteAllData | 오조작으로 복구 불가능; 개인 보관 앱의 신뢰 훼손 | soft delete + 30일 휴지통 + 즉시 Undo + 명시적 영구 삭제 | M | 확인됨 |
| DATA-010 | 중복·유사 항목 감지 부재 | Data/Product | Medium | P2 | Capture/import flow | 같은 URL·텍스트·이미지를 반복 저장해 검색 품질과 저장 공간 악화 | canonical URL/text hash/image perceptual hash; 저장 전 merge/duplicate prompt | L | 확인됨 |
| DATA-011 | 이미지 보존 정책·용량 제한·정리 기능 부재 | Data/Performance | High | P1 | SharedClipQueue.swift, SettingsView.swift | 원본 이미지가 무기한 누적돼 앱/기기 저장 공간을 잠식 | 단건/총량/보존기간 제한, storage dashboard, orphan sweeper, optimize originals 옵션 | L | 확인됨 |
| DATA-012 | 마지막 정상본·checksum·복구 저널 부재 | Data/Reliability | High | P0 | AppStore.swift:persist | 원자적 쓰기만으로 논리 손상·잘못된 import·OS 오류 복구 불가 | write temp→validate→rotate current/bak; checksum/record count; 복구 선택 UI | M | 확인됨 |
| DATA-013 | Application Support 디렉터리 생성 오류 무시 | Data/Reliability | Medium | P1 | AppStore.swift:defaultFileURL | 경로 준비 실패 후 저장이 계속 실패해도 원인을 알 수 없음 | throwing store bootstrap과 fatal/recoverable state 분리; 사용자 안내·로그 | S | 확인됨 |
| DATA-014 | JSON import의 개수·중첩·총 이미지 자산 제한 부족 | Data/Security | Medium | P1 | AppStore.swift:importJSON | 5MB 안에 매우 많은 객체를 넣어 CPU/메모리 과부하 또는 UX 정지 가능 | clip/folder/tag count budget, decode deadline, duplicate validation, preview/dry run | M | 확인됨 |
| DATA-015 | 폴더 삭제/병합 정책이 불명확 | Data/UX | Medium | P2 | AppStore.swift, Folder views | 사용자가 잘못 만든 폴더를 정리하거나 포함 클립을 안전하게 이동하기 어려움 | 삭제 전 이동 대상 선택, 병합, 기본 폴더 보호 규칙 구현 | M | 검증 필요 |
| REL-001 | Share Extension이 원본 이미지를 통째로 메모리에 적재 | Reliability/Performance | Critical | P0 | ios/ClipShareExtension/ShareViewController.swift:loadImageAsset | 대형 사진·스크린샷에서 extension memory pressure로 종료·저장 실패 | file representation 우선, coordinated copy, byte/pixel cap, incremental metadata read, downsample preview | L | 확인됨 |
| REL-002 | NSItemProvider load에 timeout·cancellation 없음 | Reliability | High | P1 | ShareViewController.swift load continuations | 공급자가 응답하지 않으면 확장이 시스템 종료까지 멈출 수 있음 | withThrowingTaskGroup timeout, cancellation handler, 명확한 retry UI | M | 확인됨 |
| REL-003 | 손상된 queue JSON을 조용히 건너뛰고 방치 | Reliability/Data | High | P1 | SharedClipQueue.swift:pendingItems | 저장되지 않은 항목이 영구 고아가 되고 사용자는 알 수 없음 | decode 실패 파일 quarantine, retry count, diagnostics/복구 화면 | M | 확인됨 |
| REL-004 | 공유 큐 정렬이 createdAt이 아닌 UUID 파일명 | Reliability/UX | Medium | P2 | SharedClipQueue.swift:pendingItems | 여러 공유 항목 import 순서가 실제 캡처 순서와 달라짐 | payload.createdAt 기준 안정 정렬; 동일 시간은 UUID tie-break | S | 확인됨 |
| REL-005 | 공유 큐 항목/용량/수명 상한 없음 | Reliability/Storage | High | P1 | SharedClipQueue.swift | 앱을 오래 열지 않거나 실패가 반복되면 App Group이 무한 증가 | queue max count/bytes/TTL, oldest-first cleanup, 사용자 경고 | M | 확인됨 |
| REL-006 | import 후 queue 삭제 실패를 무시 | Reliability | Medium | P2 | AppStore.swift:importSharedClips | 동일 항목이 다음 실행에 다시 import되거나 고아 파일이 남음 | idempotency key와 committed marker; remove 실패 기록·재시도 | M | 확인됨 |
| REL-007 | 빠른 저장 성공 뒤 고정 2초 대기 | UX/Performance | Low | P2 | ShareViewController.swift quick success | 빠른 캡처 약속과 달리 호스트 복귀가 느림 | 0.4–0.8초 접근 가능한 confirmation 또는 즉시 complete + haptic | S | 확인됨 |
| REL-008 | try?로 파일·provider 오류를 광범위하게 삼킴 | Reliability/Maintainability | High | P1 | AppStore.swift, SharedClipQueue.swift, ShareViewController.swift | 원인·빈도·복구 경로를 잃고 false-success 발생 | typed errors, OSLog privacy annotations, 사용자 오류 상태, failure analytics opt-in | M | 확인됨 |
| REL-009 | 크래시/성능 진단 기준 없음 | Operations | Medium | P2 | Repository-wide | 출시 후 extension 종료·데이터 실패를 재현하기 어려움 | 개인정보 최소화된 crash reporter 선택 또는 MetricKit/OSLog 수집 절차 | M | 확인됨 |
| REL-010 | 지원 이메일·개인정보/지원 URL이 placeholder | Release | Critical | P0 | docs/app-store/*, docs/TASKS.md | App Store 메타데이터·앱 내 정책 링크 요건 미충족 | 소유 HTTPS 페이지·모니터링 메일 배포 후 앱/metadata에서 실제 링크 확인 | S | 확인됨 |
| REL-011 | 개발팀 ID가 project.yml에 하드코딩 | Release/Configuration | Medium | P1 | ios/project.yml | fork/CI/release 팀에서 signing 재현성이 낮고 개인 설정이 소스에 결합 | xcconfig/local override, CI secret/keychain, CODE_SIGN_STYLE 분리 | S | 확인됨 |
| REL-012 | Debug/Staging/Release 환경·기능 플래그 분리 부족 | Release/Architecture | Medium | P1 | ios/project.yml | 테스트 데이터·로그·정책 URL을 안전하게 분리하기 어려움 | xcconfig 3종, bundle suffix, compile flags, environment struct | M | 확인됨 |
| REL-013 | 릴리스·태그·TestFlight 증거 없음 | Release | High | P1 | GitHub repository | 재현 가능한 배포 이력·rollback 기준이 없음 | semantic version tags, signed release notes, TestFlight gate, archive retention | M | 확인됨 |
| REL-014 | 배포 전 실기기·signed archive 작업이 미완료 | Release | Critical | P0 | docs/TASKS.md/release checklist | App Group·Face ID·privacy manifest·extension embed가 배포 서명에서 깨질 수 있음 | release team으로 archive/export/install 후 physical matrix 통과 | L | 확인됨 |
| REL-015 | App Store Connect 자산·privacy answers 미완료 | Release | Critical | P0 | docs/TASKS.md, docs/app-store | 제출 자체가 불가능하거나 메타데이터 부정확으로 거절 | 실제 스크린샷·설명·심사 노트·privacy answers·export compliance 완료 | M | 확인됨 |
| REL-016 | Android/웹 제품 구현 없음 | Strategy | Low | P4 | Repository-wide | 크로스플랫폼 사용자에는 가치 제한; 단 현재 iOS 집중 전략에는 정상 | iOS PMF 확인 전 추가 플랫폼 금지; 후속 Mac/Android 수요 검증 | XL | 확인됨 |
| REL-017 | iOS 17 최소 지원으로 시장 범위 제한 | Strategy | Low | P3 | ios/project.yml | 구형 기기 사용자는 설치 불가 | 기능 의존성 분석 후 iOS 16 하향 비용 대비 도달률 검토 | M | 확인됨 |
| SEC-001 | 생체인증 불가 시 앱 잠금 fail-open | Security/Privacy | Critical | P0 | ClipInbox app lock lifecycle | 사용자가 잠겼다고 믿는 민감 클립이 인증 없이 노출 | 잠금 설정 시 capability 확인; 불가/오류는 잠금 유지; recovery 정책 명시 | M | 확인됨 |
| SEC-002 | 앱 전환기 privacy shield/redaction 없음 | Security/Privacy | High | P1 | ClipInboxApp/AppLockView lifecycle | 백그라운드 스냅샷에 최근 클립·이미지가 노출될 수 있음 | scenePhase inactive부터 opaque privacy cover, screenshot-sensitive setting | S | 확인됨 |
| SEC-003 | 앱 잠금이 저장 데이터 암호화처럼 오해될 수 있음 | Security/UX | Medium | P1 | Settings copy/marketing | 백업·파일 접근 공격에 대한 과도한 안전 기대 | “화면 접근 잠금”으로 표현; NSFileProtectionComplete 및 선택적 encrypted vault 검토 | S | 추정 |
| SEC-004 | 주 Application Support JSON의 명시적 file protection 없음 | Security/Privacy | High | P1 | AppStore.swift:persist | 기기 잠금 중 파일 보호 수준이 의도와 다를 수 있음 | 파일 생성 후 .protectionKey=.completeUntilFirstUserAuthentication 또는 요구 수준 결정·테스트 | M | 확인됨 |
| SEC-005 | 공유 설정 저장 실패를 보고하지 않음 | Security/Reliability | Medium | P1 | SharedClipQueue.swift:saveConfiguration | 앱 설정과 Share Extension 동작이 달라져 잠금/테마/저장 방식 기대가 깨짐 | saveConfiguration throws; UI rollback 또는 재시도; config version/checksum | S | 확인됨 |
| SEC-006 | 평문 JSON 내보내기 위험 안내 부족 | Security/Privacy | Medium | P1 | Import/Export UI | 공유 대상·파일 앱·클라우드에 민감 콘텐츠가 평문으로 남음 | export 전 경고, 암호화 ZIP/암호 옵션, share completion 후 temp cleanup | M | 확인됨 |
| SEC-007 | 직접 링크 열기가 기본이며 피싱/추적 URL 경고가 약함 | Security/UX | Medium | P2 | LinkOpenMode/default preferences | 저장된 악성·추적 링크를 실수로 열 수 있음 | 도메인 표시 강화, suspicious scheme/domain check, 사용자 선택 보존 | S | 확인됨 |
| SEC-008 | Privacy Manifest/Required Reason API 최종 archive 검증 미완료 | Security/Release | High | P0 | PrivacyInfo.xcprivacy + archive | manifest 누락·서드파티 집계 오류 시 제출 실패 | Xcode archive privacy report, validate app, App Store upload preflight 자동화 | M | 검증 필요 |
| SEC-009 | 민감정보 보존/자동 삭제 정책 없음 | Security/Product | Medium | P2 | Settings/Capture flow | OTP·계정정보·개인 사진을 장기 저장할 수 있음 | 패턴 감지 opt-in, 앱별/타입별 제외, 1일/7일 자동 삭제, private folder | L | 기능 제안 |
| SEC-010 | SECURITY.md 및 취약점 신고 채널 없음 | Security/Documentation | Low | P2 | Repository root | 공개 저장소에서 안전한 신고·지원 범위가 불명확 | SECURITY.md, supported versions, private reporting 안내 | S | 확인됨 |
| UX-001 | 중앙 추가 CTA가 하드코딩 샘플 클립을 생성 | UX/Functionality | Critical | P0 | AppStore.swift:saveNewClip + Add UI | 핵심 기능이 가짜 데이터 생성이며 사용자 신뢰·App Review 최소 기능성 위험 | URL/텍스트/이미지/메모 입력 폼 구현 또는 탭을 Share Guide로 명확히 변경 | M | 확인됨 |
| UX-002 | 첫 실행 Share Extension 온보딩 부재 | UX/Product | High | P1 | Onboarding flow absent | 사용자가 앱의 핵심 캡처 방법과 Favorites 설정을 발견하기 어려움 | 3단계 온보딩, 실제 공유 연습, quick/review 설명, skip/revisit | M | 확인됨 |
| UX-003 | 샘플 데이터와 사용자 데이터의 구분이 없음 | UX/Data | High | P1 | DefaultData + Inbox | 첫 실행·손상 복구 상황에서 샘플을 실제 저장물로 오해 | 명시적 demo badge/seed choice; production 기본은 진짜 empty state | S | 확인됨 |
| UX-004 | 빈 상태가 핵심 행동을 안내하지 않음 | UX | High | P1 | Inbox empty state | 새 사용자가 무엇을 공유해야 하는지 모르고 이탈 | Share Sheet 추가 방법, 수동 추가 CTA, 샘플 1개 선택적 제공 | S | 추정 |
| UX-005 | 삭제 직후 Undo와 휴지통 없음 | UX/Data | High | P1 | Clip actions | 모바일 오터치가 즉시 영구 손실로 이어짐 | snackbar Undo + Trash tab/filter + retention | M | 확인됨 |
| UX-006 | 빠른 저장/검토 저장 모드의 차이 발견성 부족 | UX | Medium | P1 | Settings + Share Extension | 사용자가 어디서 메모·폴더를 입력할 수 있는지 이해하기 어려움 | 설정 preview, 첫 공유 시 mode coachmark, extension 내 switch link | S | 추정 |
| UX-007 | 즐겨찾기의 목적·진입점이 약함 | UX/Product | Medium | P2 | Bookmark mutation/filters | 중요 항목을 고정했지만 다시 찾는 직접 경로가 부족 | 상단 Saved/Pinned smart view, row affordance, 검색 scope | S | 확인됨 |
| UX-008 | 검색이 단순 substring 중심 | UX/Product | Medium | P2 | AppStore.swift search | 오타·어간·도메인·날짜·타입 조합 검색이 어려움 | tokenized normalized index, filters, search suggestions, Spotlight 연동 | L | 확인됨 |
| UX-009 | Sort Later가 한 항목씩만 처리 | UX/Product | Medium | P2 | Sort Later workflow | 대량 인박스 정리에 반복 탭이 많고 피로함 | swipe triage, batch select, smart suggestions, keyboard shortcuts(iPad/Mac) | L | 확인됨 |
| UX-010 | 전체 화면 이미지 확대 후 pan/회전 경험 미완성 | UX | Medium | P2 | Image viewer | 확대된 이미지의 원하는 영역을 탐색하기 어려움 | UIScrollView zoom wrapper 또는 Magnify+Drag+double-tap focus, reset controls | M | 확인됨 |
| UX-011 | 저장 공간 사용량·정리 시뮬레이션 없음 | UX/Storage | High | P1 | SettingsView.swift | 원본 이미지가 얼마나 공간을 쓰는지 알 수 없음 | 총량/항목별 표시, 큰 파일 정렬, cleanup preview, export-before-delete | M | 확인됨 |
| UX-012 | 제품 명칭이 자동 클립보드 수집으로 오해될 수 있음 | Product/Marketing | High | P1 | Name/ASO copy | 기대 불일치·개인정보 우려·낮은 리뷰 가능 | 서브타이틀과 온보딩에서 “공유해 저장하는 로컬 인박스”를 전면화 | S | 추정 |
| UX-013 | iPad에서 phone-like 단일 컬럼 가능성 | UX/Responsive | Medium | P2 | Root navigation/screens | 넓은 화면 활용이 낮고 상세 이동 반복 | NavigationSplitView, sidebar smart lists, multi-select | L | 검증 필요 |
| UX-014 | 명시적 로딩·복구·오류 상태가 부족 | UX/Reliability | High | P1 | Store bootstrap/import/export/share import | 문제 발생 시 침묵하거나 성공처럼 보여 사용자가 대응할 수 없음 | state machine: loading/ready/degraded/recovery/failed; actionable error copy | M | 확인됨 |
| UX-015 | 폴더·태그·상단 필터 개념이 중첩 | UX/Information Architecture | Medium | P2 | Inbox/Folders/Settings | 어디에 분류해야 하는지 학습 비용 증가 | Folder=위치, Tag=속성, Smart filter=뷰로 명확히 구분·명칭 통일 | M | 추정 |
| UI-001 | 고정 custom font size로 Dynamic Type 미지원 | Accessibility/UI | High | P0/P1 | Design tokens/Components.swift/screens | 큰 글자 사용자에게 잘림·축소·읽기 곤란 | UIFontMetrics 또는 Font.custom(..., relativeTo:), semantic text styles, XXL snapshot tests | L | 확인됨 |
| UI-002 | 40pt chip 등 최소 터치 영역 부족 | Accessibility/UI | High | P1 | Design tokens/selection chips | 운동·시각 장애 및 일반 오터치 증가 | 모든 interactive hit frame 최소 44x44, contentShape, spacing 재조정 | S | 확인됨 |
| UI-003 | 2행×5열 고정 선택기가 번역·큰 글자에 비적응 | Accessibility/UI | High | P1 | Components.swift:TwoRowHorizontalSelection | 영어·일본어·AX 글자에서 축소·잘림·인지 저하 | adaptive LazyVGrid 또는 horizontal chips; 줄바꿈·scroll 지원 | M | 확인됨 |
| UI-004 | 행·미디어·에디터 높이가 고정 | Accessibility/UI | High | P1 | Clip rows/detail screen | Dynamic Type와 긴 메모에서 콘텐츠가 잘리거나 과도한 축소 | minHeight, ViewThatFits, scrollable sections, sizeCategory 조건 레이아웃 | M | 확인됨 |
| UI-005 | 색 대비 측정 증거 없음 | Accessibility/UI | Medium | P1 | Color tokens/light/dark themes | tertiary gray·yellow 조합이 WCAG 대비에 미달할 수 있음 | 모든 text/icon/background pair 자동 contrast audit, high-contrast variant | S | 검증 필요 |
| UI-006 | 커스텀 leading-edge back gesture | UI/Accessibility | Medium | P2 | Navigation helpers | 시스템 제스처·ScrollView·VoiceOver와 충돌 가능 | NavigationStack/native toolbar/back swipe 우선, 꼭 필요할 때만 constrained gesture | M | 확인됨 |
| UI-007 | 커스텀 키보드 dismiss recognizer 복잡성 | UI/Maintainability | Low | P3 | Keyboard dismissal helper | 제스처 우선순위·시트·접근성에 예기치 않은 부작용 | scrollDismissesKeyboard, FocusState, toolbar Done 등 네이티브 API로 단순화 | S | 확인됨 |
| UI-008 | 이미지 접근성 라벨 일부 하드코딩 한국어 | Accessibility/I18N | Medium | P1 | Image viewer/components | 영어·일본어 VoiceOver 사용자에게 잘못된 언어가 읽힘 | L10n key 및 clip title/type/context를 결합한 label/hint | S | 확인됨 |
| UI-009 | 커스텀 버튼·토글·상태의 접근성 의미론 불완전 | Accessibility | High | P1 | ShareViewController custom UI, SwiftUI components | VoiceOver 순서·selected state·저장 성공 공지가 불명확 | accessibilityLabel/Value/Traits, sortPriority, screenChanged/announcement | M | 추정 |
| UI-010 | 상태 변화가 토스트에 과의존 | UI/UX | Medium | P2 | AppStore toast/UI | VoiceOver가 놓치고 실패·undo 같은 행동이 지속되지 않음 | accessible banner/snackbar, inline error, persistent recovery center | M | 확인됨 |
| ARCH-001 | AppStore가 662줄의 God object | Architecture/Maintainability | High | P1 | ios/ClipInbox/Store/AppStore.swift | 상태·검증·저장·import·공유 큐·설정이 결합돼 회귀와 테스트 비용 증가 | Repository/UseCase/ImportExport/Search/Preferences 서비스로 단계 분리 | L | 확인됨 |
| ARCH-002 | UI 상태와 비즈니스 로직·파일 I/O 결합 | Architecture | High | P1 | AppStore + Views | UI thread 블로킹·rollback·headless 테스트가 어려움 | @MainActor view model은 presentation만; actor repository에서 async transactions | L | 확인됨 |
| ARCH-003 | 도메인 상태를 문자열로 표현 | Architecture/Type Safety | Medium | P1 | Preferences/Shared config/models | 오타·번역 변경·불가능 상태가 컴파일 시 방지되지 않음 | Codable enum + stable raw value + migration | M | 확인됨 |
| ARCH-004 | App Group·bundle/team 식별자 하드코딩 | Architecture/Configuration | Medium | P1 | SharedClipQueue.swift, project.yml | 환경·팀·테스트 컨테이너 전환이 어렵고 테스트 격리 불량 | BuildSettings generated config 또는 Info.plist key injection | S | 확인됨 |
| ARCH-005 | 저장소 추상화와 failure injection 지점 부족 | Architecture/Testability | High | P1 | AppStore.swift direct FileManager/Data | disk full·permission·corruption 테스트가 어려움 | ClipRepository/FileSystem/Clock/IDGenerator protocols와 in-memory/failing fakes | M | 확인됨 |
| ARCH-006 | 파일 I/O가 main execution path에서 동기 실행 | Architecture/Performance | High | P1 | AppStore.swift:persist/import | 대형 데이터에서 frame drop·watchdog 위험 | StorageActor, async methods, loading state, coalesced writes | M | 추정 |
| ARCH-007 | 웹 프로토타입과 제품 코드가 같은 루트에 있어 혼동 | Architecture/Documentation | Medium | P2 | src/, public/, ios/ | 신규 기여자가 잘못된 구현을 수정하거나 QA 대상을 혼동 | archive/prototype 하위 이동 또는 root README에 source-of-truth diagram | S | 확인됨 |
| ARCH-008 | 이미지 자산 생명주기와 clip transaction 분리 | Architecture/Data | High | P1 | SharedClipQueue + AppStore | clip commit/삭제와 이미지 이동·삭제가 부분 실패할 수 있음 | two-phase asset transaction, ref count, orphan reconciliation | L | 확인됨 |
| PERF-001 | 선형 in-memory 검색 | Performance | Medium | P2 | AppStore search/filter | 수천 항목에서 입력 지연, 메모리 상주 비용 증가 | SQLite FTS/normalized inverted index, debounce, incremental results | L | 확인됨 |
| PERF-002 | 썸네일에서 원본 이미지를 전체 디코딩할 가능성 | Performance/Memory | High | P1 | Image loading components | 고해상도 사진 목록 스크롤 시 memory spike·jank | CGImageSource thumbnail downsample, target pixel size, async decode/cache | M | 추정 |
| PERF-003 | 이미지 cache cost limit 불명확 | Performance/Memory | Medium | P1 | Image cache helper | OS 압박 전까지 decoded bitmap이 과도하게 남을 수 있음 | NSCache totalCostLimit/countLimit, cost=pixel bytes, memory warning purge | S | 검증 필요 |
| PERF-004 | prettyPrinted JSON으로 저장 크기·쓰기 비용 증가 | Performance | Low | P2 | AppStore.swift:persist | 모바일 내부 저장에는 가독성 이득 없이 I/O 증가 | 내부 스냅샷은 compact; export만 prettyPrinted | S | 확인됨 |
| PERF-005 | 성능 예산·대규모 데이터 기준 없음 | Performance/QA | Medium | P1 | docs/tests | “몇 개까지 빠른가”를 출시 전에 판단할 근거가 없음 | cold launch/search/scroll/share memory budgets와 signpost/MetricKit 측정 | M | 확인됨 |
| TEST-001 | GitHub Actions/CI 워크플로 부재 | Testing/Release | High | P0/P1 | .github/workflows 없음 | 빌드·테스트·manifest·project drift 회귀가 PR에 합쳐질 수 있음 | macOS runner build+test+lint+privacy+artifact workflow; branch protection | M | 확인됨 |
| TEST-002 | 저장 실패·disk full·permission 회귀 테스트 부재 | Testing/Reliability | Critical | P0 | ClipInboxTests/AppStoreTests.swift | 가장 위험한 false-success가 자동 검출되지 않음 | failing repository/file system으로 모든 mutation rollback contract 테스트 | M | 확인됨 |
| TEST-003 | 손상 스냅샷·migration·unsupported version 테스트 부재 | Testing/Data | Critical | P0 | ClipInboxTests | 업데이트 시 데이터 손실 회귀를 차단하지 못함 | golden fixtures, corrupt/truncated/checksum/future-version matrix | M | 확인됨 |
| TEST-004 | Share Extension 실제 E2E·대형 이미지 자동 테스트 부재 | Testing/Reliability | High | P0/P1 | ClipShareExtension | provider·App Group·host별 차이를 단위 테스트로 잡지 못함 | XCUITest host harness + manual release matrix + memory benchmarks | L | 확인됨 |
| TEST-005 | UI/접근성 snapshot·VoiceOver 테스트 부재 | Testing/Accessibility | High | P1 | UI tests absent | Dynamic Type·번역·다크 모드 회귀가 시각 QA에 의존 | XCUITest accessibility audit, snapshot matrix, localization pseudo-language | L | 확인됨 |
| TEST-006 | 성능·메모리·대량 데이터 테스트 부재 | Testing/Performance | Medium | P1 | Tests | 전체 JSON/이미지 설계의 확장 한계를 모름 | XCTest measure, XCTMemoryMetric, signposts, 100/1k/5k/10k fixtures | M | 확인됨 |
| TEST-007 | 물리 기기 release matrix 미완료 | Testing/Release | Critical | P0 | docs/TASKS.md | Face ID·App Group·Photos provider·file protection 차이를 미검증 | 최소 2개 OS/2개 기기/iPad에서 signed release build 체크리스트 | L | 확인됨 |
| TEST-008 | archive/Privacy Report/extension embedding 자동 게이트 부재 | Testing/Release | High | P0 | Release pipeline | Debug simulator 성공과 배포 바이너리 성공이 분리됨 | CI archive 또는 release candidate archive 검증 스크립트 | M | 확인됨 |
| DOC-001 | 루트 README 부재 | Documentation/DX | Medium | P1 | Repository root | 제품·빌드·source-of-truth·privacy·스크린샷을 외부가 파악하기 어려움 | README with product, setup, architecture, tests, release, status, limitations | S | 확인됨 |
| DOC-002 | 저장소 LICENSE 부재 | Legal/Documentation | High | P1 | Repository root | 공개 코드 재사용·기여·상업 사용 권리가 불명확 | 권리자 의도에 맞는 LICENSE 추가; 폰트·이미지 third-party notices 분리 | S | 확인됨 |
| DOC-003 | CONTRIBUTING/CODE_OF_CONDUCT/PR template 부재 | Documentation/DX | Low | P3 | Repository root/.github | 협업 규칙·검증 방법이 사람 기억에 의존 | 기여 가이드, issue/PR templates, commit/release conventions | S | 확인됨 |
| DOC-004 | 운영·복구 runbook 부재 | Documentation/Operations | Medium | P1 | docs/ | 데이터 손상·App Group·스토어 거절 상황 대응이 느림 | corruption recovery, signing, queue cleanup, rollback, privacy incident runbooks | M | 확인됨 |
| LEGAL-001 | 개인정보 처리방침 초안의 실소유 연락처·게시 URL 미완료 | Legal/Release | Critical | P0 | docs/app-store privacy draft | 제출 요건과 사용자 문의·삭제/내보내기 권리 안내 미충족 | 관할·연락처·보존·export·백업·문의 절차를 검토 후 HTTPS 게시 | M | 확인됨 |
| LEGAL-002 | 폰트·이미지·프로토타입 자산 라이선스 인벤토리 부족 | Legal | Medium | P1 | Fonts/public/Reference | 스토어 배포 권리·고지 의무가 불분명할 수 있음 | THIRD_PARTY_NOTICES, asset source/proof, build-time license report | M | 검증 필요 |
| LEGAL-003 | “데이터 미수집” 답변의 release SDK 기준 검증 필요 | Legal/Privacy | High | P0 | App Store privacy answers | 향후 crash/analytics SDK 추가 시 선언과 실제가 어긋날 수 있음 | release binary network/SDK audit; 수집 없음 유지 또는 정확한 disclosure | M | 검증 필요 |
| FEATURE-001 | 실제 수동 캡처 폼 | Feature | High | P0 | Add tab | 공유 시트를 쓰기 어려운 상황에서도 핵심 기능 완결 | URL paste, text, memo, PhotosPicker, duplicate preview | M | 기능 제안 |
| FEATURE-002 | 휴지통·Undo·복원 | Feature | High | P1 | Data/UI | 개인 데이터 신뢰와 오조작 복구 | soft-delete model, trash smart list, retention | M | 기능 제안 |
| FEATURE-003 | 중복 감지 및 병합 | Feature | Medium | P2 | Capture/Search | 노이즈·저장 공간 절감 | URL canonicalization, text SHA-256, image pHash | L | 기능 제안 |
| FEATURE-004 | 온디바이스 OCR·스마트 액션 | Feature | Medium | P3 | Image/detail | 이미지 안 텍스트 재검색과 전화/주소/코드 행동 제공 | Vision framework opt-in index; 원본 외부 전송 없음 | L | 기능 제안 |
| FEATURE-005 | Shortcuts·Spotlight·Widget | Feature | Medium | P3 | Platform integration | 빠른 재검색·저장·자동화로 파워유저 가치 상승 | App Intents, Core Spotlight, widgets; privacy scope 명시 | XL | 기능 제안 |
| FEATURE-006 | 선택적 iCloud 동기화 | Feature | Medium | P3 | Data architecture | 기기 변경·다중 Apple 기기 연속성 | local-only default, CloudKit opt-in, conflict log, E2E expectations 명시 | XL | 기능 제안 |


## Top 10 실행 순서

1. `DATA-001`, `DATA-012`, `TEST-003`: 손상 감지·격리·백업 복구와 fixture 테스트를 한 작업 묶음으로 처리한다.
2. `DATA-002`, `TEST-002`, `ARCH-005`: 모든 mutation을 성공/실패 계약이 있는 repository transaction으로 바꾼다.
3. `REL-001`, `REL-002`, `TEST-004`: Share Extension 이미지 입력의 바이트·픽셀·시간 제한과 실기기 메모리 테스트를 추가한다.
4. `SEC-001`, `SEC-002`: 잠금 fail-closed와 app switcher shield를 적용한다.
5. `UX-001`, `FEATURE-001`: 데모 Add를 실제 캡처 폼으로 교체한다.
6. `DATA-003`: schema migrator와 unsupported-version UX를 도입한다.
7. `UI-001`~`UI-004`, `TEST-005`: Dynamic Type·터치 영역·적응형 레이아웃을 테스트와 함께 수정한다.
8. `TEST-001`, `TEST-008`: PR CI와 release archive gate를 만든다.
9. `REL-010`, `REL-014`, `REL-015`, `LEGAL-001`, `LEGAL-003`: 실소유 정책 페이지·서명·스토어 자료를 완료한다.
10. `DATA-009`, `FEATURE-002`, `UX-011`: 휴지통과 저장 공간 관리로 사용자 신뢰를 완성한다.

## 완료 정의

각 이슈는 코드가 merge되었다는 이유만으로 완료되지 않는다. 관련 자동 테스트, 실패 UI, 문서, 개인정보/접근성 검증, 배포 빌드 검증 중 해당되는 항목이 모두 충족돼야 한다. P0의 경우 실제 Release configuration 또는 signed archive에서 재현 가능한 증거를 남긴다.


---

# ClipInbox Implementation Plan

## 1. 실행 원칙

- 기능 추가 전에 데이터 신뢰 경계를 고친다.
- P0는 개별 patch가 아니라 테스트·오류 UI·문서까지 하나의 작업 단위로 닫는다.
- 기존 SwiftUI 디자인과 Share Extension을 보존하고 점진적으로 분리한다.
- 매주 끝에 실행 가능한 build를 유지한다.
- 한 번에 저장소를 SwiftData로 전환하지 않는다. 먼저 transaction/recovery interface를 만든 뒤 필요하면 backend를 교체한다.

## 2. 작업 의존성

```text
ARCH-005 Repository abstraction
 ├─ DATA-001/012 Recovery
 ├─ DATA-002 Transaction rollback
 ├─ DATA-003 Migration
 ├─ TEST-002/003 Failure fixtures
 └─ ARCH-006 StorageActor

REL-001 Image pipeline
 ├─ REL-002 Timeout/cancel
 ├─ REL-005 Queue quota
 ├─ ARCH-008 Asset transaction
 └─ TEST-004 Extension E2E

SEC-001 Lock state machine
 ├─ SEC-002 Privacy shield
 └─ TEST physical-device lock matrix

UI semantic typography
 ├─ adaptive filter/grid
 ├─ screen reflow
 └─ accessibility snapshot/VoiceOver gate

Release URLs/signing
 ├─ privacy policy final
 ├─ App Privacy answers
 ├─ signed archive validation
 └─ TestFlight/App Store submission
```

## 3. Week 1 — 데이터 안전 기반

### 목표

손상·저장 실패가 사용자에게 조용히 보이지 않도록 만들고, 이후 기능이 같은 계약을 사용하게 한다.

### 작업

#### 1. Repository와 오류 모델

- `ClipRepository` protocol
- `FileClipRepository` initial implementation
- `StoreError`: notFound, corrupt, unsupportedVersion, noSpace, permission, encoding, validation, assetFailure
- `Clock`, `IDGenerator`, `FileSystem` 최소 주입점
- in-memory/failing fake repository

**완료 기준**

- AppStore가 직접 `Data.write`를 호출하지 않는다.
- 모든 저장 작업이 typed `Result`/throwing async API를 사용한다.

#### 2. Snapshot bootstrap/recovery

- 파일 없음과 decode failure 분리
- draft validation
- current/previous rotation
- corrupt quarantine
- schema version allowlist
- recovery state UI skeleton

**완료 기준**

- truncated current + valid previous에서 자동/선택 복구
- previous도 손상된 경우 기존 파일 보존, 샘플로 덮어쓰지 않음
- 손상 fixture tests 통과

#### 3. Transaction mutation

- bookmark, move, memo, update, tags, create folder, preference, delete, delete-all을 동일 transaction contract로 이전
- commit 성공 후에만 toast
- 실패 시 UI rollback과 actionable banner

**완료 기준**

- disk-full fake에서 모든 mutation의 메모리·디스크 상태가 동일
- false-success test 0건

#### 4. production sample 제거

- 첫 실행은 empty state
- demo 데이터는 Preview/test fixture 또는 명시적 “샘플 둘러보기” opt-in으로 이동

### Week 1 산출물

- PR 1: repository/error/fakes
- PR 2: recovery/migration skeleton
- PR 3: transaction mutations
- PR 4: empty state/sample separation
- 업데이트된 data architecture 문서와 migration fixture

## 4. Week 2 — Share Extension·잠금·실제 Add

### 목표

가장 빈번한 캡처 입력과 privacy barrier를 production contract로 만든다.

### 작업

#### 1. 이미지 입력 파이프라인

- `loadFileRepresentation` 우선
- 파일 URL coordinated copy
- header 기반 bytes/pixels/type inspection
- configurable byte/pixel cap
- preview downsample
- original/optimized storage 선택 정책
- unsupported/too-large error UI

#### 2. Provider deadline/cancellation

- URL/text/image provider 작업에 deadline
- user cancel과 host cancel을 구분
- task cancellation handler
- fixed 2-second wait 축소/제거

#### 3. Queue durability

- `createdAt` 정렬
- idempotency UUID
- corrupt quarantine
- max count/bytes/TTL
- cleanup/reconciliation result
- config save throws/version/checksum

#### 4. App Lock state machine

- capability 확인 전 setting commit 금지
- auth error/cancel에서 fail-closed
- `scenePhase == .inactive`에서 privacy cover
- foreground unlock race test
- copy를 Face ID 전용처럼 과장하지 않음

#### 5. Manual Add

- URL, text/memo, PhotosPicker image
- title/source optional
- duplicate preview hook
- 동일 repository transaction 사용
- demo `saveNewClip` 제거

### Week 2 산출물

- 대형 이미지/timeout provider tests
- signed-build 전 단계 extension harness
- lock lifecycle tests
- 실제 Add UI test

## 5. Weeks 3–4 — UX·접근성·복구 기능

### 목표

외부 사용자가 설명 없이도 저장하고, 실수를 복구하고, 큰 글자/VoiceOver로 핵심 흐름을 완료하게 한다.

### 작업 묶음 A — 온보딩과 상태 화면

- first-run Share-to-Inbox 설명
- Share Extension Favorites guide
- Quick/Review mode preview
- 첫 capture exercise
- empty/no-results/loading/degraded/recovery common states
- Settings에 “공유 확장 사용법 다시 보기”

### 작업 묶음 B — 휴지통과 Undo

- `DeletionState`/`deletedAt`
- Undo banner
- Trash smart list
- restore/permanent delete/empty trash
- image file retention and cleanup
- delete-all export suggestion + typed confirmation

### 작업 묶음 C — 접근성 시스템

- semantic relative typography
- 44pt hit area
- 5-column grid를 adaptive chips/filter sheet로 교체
- fixed height 제거/reflow
- VoiceOver labels/values/traits/announcements
- Reduce Motion
- contrast audit
- 3개 언어 + AX5 snapshot matrix

### 작업 묶음 D — Storage/Privacy Center

- clip/image/queue bytes
- largest items
- retention setting
- original vs optimized image policy
- export/delete/backup scope 설명
- redacted diagnostics export

### Weeks 3–4 산출물

- 접근성 audit blocker 0
- 휴지통 roundtrip tests
- storage cleanup preview
- onboarding completion analytics 없이도 로컬 QA할 수 있는 test hooks

## 6. Month 2 — 공개 출시 품질

### 6.1 검색과 정리

- normalized token search
- folder/tag/type/date filters
- favorites/recent/images smart views
- duplicate URL/text detection
- batch select/move/tag/delete
- Sort Later swipe triage

### 6.2 저장소 규모 판단

아래 benchmark 후 backend를 결정한다.

| Fixture | 측정 | 통과 기준 |
|---:|---|---|
| 100 clips | launch/save/search | 체감 지연 없음 |
| 1,000 | save p95/search p95 | save <150ms, search <100ms 목표 |
| 5,000 | launch/list/search | launch <2.5s, typing smooth |
| 10,000 | stress | memory 안정, UX 정책 결정 |
| 1GB images | scroll/storage | downsample, no OOM |

- snapshot이 기준을 충족하면 1.0까지 유지 가능
- 실패하면 `SQLiteClipRepository`로 교체
- export schema는 backend와 독립 유지

### 6.3 CI/Release automation

- macOS CI build/test
- migration/failure/accessibility suites
- XcodeGen drift
- secret/license/privacy manifest checks
- protected release archive job
- entitlements/appex/privacy report validator
- TestFlight upload/release notes

### 6.4 App Store 준비

- 소유 HTTPS privacy/support 페이지
- support email 운영
- App Privacy answers
- 실제 release screenshot
- review notes와 Share Extension guide
- physical iPhone/iPad matrix
- TestFlight external feedback/known issues

## 7. 2–4개월 후 제품 확장

### 우선순위 후보

1. Core Spotlight
2. App Intents/Shortcuts
3. on-device OCR
4. URL metadata/cache policy
5. Mac companion feasibility
6. optional CloudKit sync

AI 요약·의미 검색은 데이터 안전과 기본 검색 품질이 완성된 뒤 실험한다. 기본값은 on-device이며 server AI는 개별 항목 단위 opt-in과 명확한 전송 preview가 필요하다.

## 8. 병렬 처리 가능 작업

| Track | 독립 가능 범위 | 의존성 |
|---|---|---|
| Data | repository/recovery/migration | 최우선, 대부분의 기능 선행 |
| Extension | image pipeline/provider timeout | repository와 queue contract 합의 필요 |
| Lock/Privacy | state machine/shield | UI root lifecycle 접근 필요 |
| Design/A11y | typography/adaptive components | transaction과 병렬 가능 |
| Product/Docs | privacy/support pages, onboarding copy | 실제 동작 확정 후 final |
| CI | fast checks/unit workflow | project가 안정되면 즉시 시작 가능 |
| Store assets | screenshot plan/ASO | release UI freeze 후 final capture |

1인 개발이라면 Data → Extension/Lock → Add → UX/A11y → Release 순서를 지킨다. 여러 명이면 Data contract를 먼저 합의한 뒤 Extension, UX, Release track을 병렬화한다.

## 9. 티켓 템플릿

```markdown
### [ID] 제목
- 사용자 문제:
- 현재 증거/관련 파일:
- 범위:
- 비범위:
- 실패 계약:
- 개인정보/접근성 영향:
- 구현 메모:
- 자동 테스트:
- 실기기/수동 테스트:
- migration/rollback:
- 완료 증거:
```

## 10. Definition of Done

모든 기능/수정은 다음 중 해당 항목을 충족해야 한다.

- 코드 리뷰 완료
- 성공과 실패 테스트
- 기존 사용자 데이터 migration 또는 “없음” 명시
- 오류 UI와 접근 가능한 announcement
- 3개 언어 문구
- light/dark/AX5 화면 검증
- 개인정보 영향 검토
- 관련 README/runbook/changelog
- release configuration 검증

P0는 unit test만으로 닫지 않는다. signed build 또는 실제 파일 system fault를 포함한 증거를 남긴다.

## 11. 리스크와 완화

| 리스크 | 가능성 | 영향 | 완화 |
|---|---:|---:|---|
| 데이터 계층 리팩터링이 UI 회귀 유발 | 중 | 높음 | characterization tests, 작은 PR, feature branch migration |
| 이미지 최적화가 원본 보존 약속과 충돌 | 중 | 높음 | 정책 선택·명시, 원본/optimized 별도 metadata |
| 접근성 변경으로 현재 pixel design 변화 | 높음 | 중 | semantic hierarchy를 보존하고 fixed geometry만 제거 |
| SQLite 이전 과투자 | 중 | 중 | benchmark-based decision gate |
| App Review 정책/manifest 변경 | 중 | 높음 | 제출 직전 공식 문서 재확인, archive preflight |
| 혼자 개발해 release 운영 누락 | 높음 | 높음 | checklist evidence와 CI 자동화 |

## 12. 성공 지표

- false-success: 0
- recoverable corruption에서 사용자 데이터 복구율: 100%
- 첫 설치→첫 capture 성공률: QA cohort 90%+
- core capture completion: 99.9% target
- AX5/VoiceOver core-flow blocker: 0
- signed release matrix blocker: 0
- 외부 TestFlight 데이터 손실 report: 0
- 7일 내 saved clip 재검색/열기 성공: 정성 테스트에서 90%+


---

# ClipInbox Final Release Checklist

체크 방법: 항목에 코드 PR, CI run, 스크린샷, signed-build 동영상, App Store Connect 화면 중 하나 이상의 증거 링크를 연결한다. P0 관련 항목은 담당자의 구두 확인만으로 닫지 않는다.

## 코드·데이터

- [ ] 손상 스냅샷과 첫 실행을 구분한다
- [ ] current/.bak/quarantine 복구가 자동 테스트된다
- [ ] 모든 mutation이 durable commit 실패 시 rollback된다
- [ ] snapshot version migration과 future-version 거절이 테스트된다
- [ ] 샘플 데이터는 production empty state와 분리된다
- [ ] 실제 Add URL/text/image/memo가 동작한다
- [ ] 휴지통/Undo 또는 동등한 복구가 있다
- [ ] 이미지/queue orphan reconciliation이 있다

## 테스트

- [ ] PR마다 XcodeGen generate drift가 0인지 확인한다
- [ ] Debug/Release simulator build가 통과한다
- [ ] 단위·통합·UI 테스트가 CI에서 통과한다
- [ ] corrupt/disk-full/migration fixtures가 통과한다
- [ ] Share URL/text/image E2E가 통과한다
- [ ] 48MP/대용량 이미지 메모리 테스트가 통과한다
- [ ] 5,000개 검색·스크롤 성능 예산을 통과한다
- [ ] TestFlight update/migration 테스트를 통과한다

## 보안·개인정보

- [ ] 앱 잠금이 capability 오류·취소에서 fail-closed다
- [ ] inactive/background에서 app switcher shield가 즉시 표시된다
- [ ] 주 JSON과 App Group 파일 보호 수준을 실기기에서 확인한다
- [ ] export 평문/암호화 범위를 사용자에게 고지한다
- [ ] 실제 release binary의 네트워크 송신을 점검한다
- [ ] Privacy Manifest Required Reason API 보고서가 오류 없이 생성된다
- [ ] 민감 로그가 없고 OSLog privacy가 적용된다
- [ ] 데이터 삭제·백업·복구·보존 정책이 정책문과 일치한다

## UI·UX·접근성

- [ ] 첫 실행에 Share Extension 사용법과 Favorites 안내가 있다
- [ ] Quick/Review 모드 차이를 이해할 수 있다
- [ ] Dynamic Type AX5에서 핵심 화면 잘림이 없다
- [ ] 모든 핵심 터치 대상이 최소 44x44다
- [ ] VoiceOver로 저장·정리·검색·삭제 복구가 가능하다
- [ ] 한국어·영어·일본어 긴 문자열을 검증했다
- [ ] light/dark/increase contrast 대비를 측정했다
- [ ] iPad portrait/landscape/split view를 검증했다
- [ ] 모든 loading/empty/error/recovery 상태가 행동을 안내한다

## iOS·확장

- [ ] App/Share bundle ID와 App Group entitlement가 release profile과 일치한다
- [ ] Share Extension activation rules가 URL/text/image 요구 범위와 일치한다
- [ ] Safari, Photos, 선택 텍스트 공유를 signed build에서 확인한다
- [ ] provider timeout/cancellation과 host return을 확인한다
- [ ] extension이 containing app을 자동 실행한다고 오해시키지 않는다
- [ ] 앱과 extension의 설정 파일 version/checksum이 일치한다
- [ ] iPhone/iPad 지원 방향과 실제 UI가 일치한다
- [ ] 최소 iOS 17 지원 전략을 스토어 정보와 일치시킨다

## 배포·App Store

- [ ] 실소유 HTTPS privacy URL이 앱 내부와 App Store Connect에 있다
- [ ] 실소유 HTTPS support URL과 모니터링 이메일이 있다
- [ ] placeholder 문구·URL·샘플 화면이 모두 제거됐다
- [ ] Distribution certificate/profile로 signed archive를 생성했다
- [ ] archive에 ClipInboxShare.appex가 올바르게 embed/sign됐다
- [ ] Validate App가 경고/오류 없이 통과한다
- [ ] App Privacy 답변이 release binary와 일치한다
- [ ] 스크린샷이 실제 현재 UI와 기능만 보여준다
- [ ] 심사 노트에 Share Extension 활성화·테스트 방법을 쓴다
- [ ] export compliance·연령 등급·카테고리·가격을 확정한다
- [ ] TestFlight 외부 테스트 피드백과 crash-free gate를 통과한다
- [ ] rollback 가능한 이전 archive와 release notes를 보관한다

## 운영·문서·법무

- [ ] 루트 README, LICENSE, SECURITY.md가 있다
- [ ] THIRD_PARTY_NOTICES에 폰트·이미지 자산 근거가 있다
- [ ] 빌드·테스트·배포·복구 runbook이 있다
- [ ] 데이터 손상·privacy incident 대응 담당과 절차가 있다
- [ ] 지원 문의에서 민감 원문을 요구하지 않는 진단 절차가 있다
- [ ] 버전·changelog·migration notes가 릴리스와 일치한다
- [ ] 앱 이름·상표·도메인 사용 가능성을 확인했다
- [ ] 개인정보 처리방침을 필요한 관할 기준으로 검토했다


## Go/No-Go 서명

- [ ] Engineering: P0 0개, P1 수용 가능한 잔여 목록 승인
- [ ] QA: signed release matrix와 migration 통과
- [ ] Product/Design: 현재 메타데이터와 실제 기능 일치
- [ ] Privacy/Legal: 정책·App Privacy·연락처 승인
- [ ] Release owner: archive hash, version/build, rollback artifact 기록

**No-Go 자동 조건:** 데이터 손상 또는 false-success 재현, extension crash, 잠금 우회, placeholder URL, signed archive/appex 검증 실패, Privacy Manifest 오류, 실제 Add 미구현.


---

# Recommended Target Architecture

## 1. 목표

현재 앱을 전면 재작성하지 않고 다음 속성을 만든다.

1. 저장 성공과 UI 성공이 동일한 의미를 가진다.
2. 손상·미지원 버전·부분 실패를 복구할 수 있다.
3. Share Extension과 앱의 자산 생명주기가 idempotent하다.
4. UI는 파일 시스템·App Group 세부 구현을 모른다.
5. 저장 backend를 snapshot에서 SQLite/SwiftData로 바꿔도 화면을 다시 쓰지 않는다.
6. 테스트가 disk full, timeout, corruption, clock, ID를 결정적으로 재현한다.
7. local-only·privacy 원칙을 모듈 경계에 반영한다.

## 2. 권장 계층

```text
┌─────────────────────────────────────────────────────┐
│ Presentation                                        │
│ SwiftUI Screens / Share UIKit / ViewModels          │
└───────────────────┬─────────────────────────────────┘
                    │ user intents / view state
┌───────────────────▼─────────────────────────────────┐
│ Application                                         │
│ CaptureClip, UpdateClip, Delete/Restore, Search,    │
│ Import/Export, RecoverStore, ManagePreferences      │
└───────────────────┬─────────────────────────────────┘
                    │ domain protocols
┌───────────────────▼─────────────────────────────────┐
│ Domain                                              │
│ Clip, Folder, Tag, CapturePayload, DeletionState,   │
│ Stable enums, validation rules, errors              │
└───────────────────┬─────────────────────────────────┘
                    │ repository interfaces
┌───────────────────▼─────────────────────────────────┐
│ Infrastructure                                      │
│ File/SQLite Repository, Snapshot Codec/Migrator,    │
│ Shared Queue, Image Store, Preferences, OSLog       │
└───────────────────┬─────────────────────────────────┘
                    │
┌───────────────────▼─────────────────────────────────┐
│ Platform                                            │
│ FileManager, App Group, LocalAuthentication,        │
│ NSItemProvider, PhotosPicker, UIApplication         │
└─────────────────────────────────────────────────────┘
```

## 3. 모듈/타깃 제안

초기에는 Xcode target을 과도하게 늘리지 않고 폴더·Swift package 경계로 시작한다.

```text
ios/
├── App/
│   ├── ClipInboxApp.swift
│   ├── AppCoordinator.swift
│   └── AppEnvironment.swift
├── Domain/
│   ├── Models/
│   │   ├── Clip.swift
│   │   ├── Folder.swift
│   │   ├── Tag.swift
│   │   └── Preferences.swift
│   ├── Errors/
│   └── Validation/
├── Application/
│   ├── UseCases/
│   │   ├── CaptureClip.swift
│   │   ├── UpdateClip.swift
│   │   ├── DeleteClip.swift
│   │   ├── RestoreClip.swift
│   │   ├── ImportArchive.swift
│   │   └── RecoverLibrary.swift
│   └── Ports/
│       ├── ClipRepository.swift
│       ├── ImageStore.swift
│       ├── CaptureQueue.swift
│       ├── PreferencesStore.swift
│       └── Diagnostics.swift
├── Infrastructure/
│   ├── Persistence/
│   │   ├── FileClipRepository.swift
│   │   ├── SQLiteClipRepository.swift       # 필요 시 후속
│   │   ├── SnapshotCodec.swift
│   │   ├── SnapshotMigrator.swift
│   │   └── SnapshotRecovery.swift
│   ├── Assets/
│   │   ├── AppGroupImageStore.swift
│   │   └── ThumbnailPipeline.swift
│   ├── Sharing/
│   │   └── FileCaptureQueue.swift
│   ├── Settings/
│   └── Logging/
├── Features/
│   ├── Inbox/
│   ├── Detail/
│   ├── Capture/
│   ├── Search/
│   ├── Library/
│   ├── Trash/
│   ├── Settings/
│   ├── Onboarding/
│   └── Recovery/
├── DesignSystem/
│   ├── Tokens/
│   ├── Components/
│   └── Accessibility/
├── SharedContract/                     # 앱+extension에서 빌드
│   ├── CapturePayload.swift
│   ├── CaptureConfiguration.swift
│   └── QueueEnvelope.swift
├── ClipShareExtension/
│   ├── ShareCoordinator.swift
│   ├── ProviderLoader.swift
│   ├── ImageIngestor.swift
│   └── ShareViewController.swift
└── Tests/
    ├── Unit/
    ├── Integration/
    ├── UI/
    ├── Fixtures/
    └── Performance/
```

## 4. 핵심 protocol

```swift
protocol ClipRepository: Sendable {
    func bootstrap() async throws -> BootstrapResult
    func readLibrary() async throws -> LibrarySnapshot
    func transaction<T: Sendable>(
        _ operation: @Sendable (inout LibraryDraft) throws -> T
    ) async throws -> TransactionResult<T>
}

protocol CaptureQueue: Sendable {
    func enqueue(_ envelope: CaptureEnvelope) async throws
    func pending() async throws -> [QueuedCapture]
    func acknowledge(_ id: UUID) async throws
    func quarantine(_ id: UUID, reason: QueueFailure) async throws
    func reconcile() async throws -> QueueHealth
}

protocol ImageStore: Sendable {
    func stage(_ source: ImageSource, policy: ImagePolicy) async throws -> StagedImage
    func commit(_ staged: StagedImage, ownerID: Clip.ID) async throws -> ImageAsset
    func rollback(_ staged: StagedImage) async
    func delete(_ asset: ImageAsset) async throws
    func thumbnail(for asset: ImageAsset, targetPixels: CGSize) async throws -> CGImage
}
```

### 계약 원칙

- `transaction` 밖에서 in-memory 모델을 먼저 변경하지 않는다.
- 성공은 current state가 durable하고 다시 decode/validate 가능한 상태를 뜻한다.
- image/queue/clip은 idempotency key를 공유한다.
- 오류는 사용자 행동으로 매핑 가능한 typed category를 가진다.
- UI는 Bool `persist()`를 호출하지 않는다.

## 5. 데이터 모델

### Clip

```swift
struct Clip: Identifiable, Codable, Sendable, Equatable {
    typealias ID = UUID

    let id: ID
    var kind: ClipKind
    var createdAt: Date
    var updatedAt: Date
    var source: SourceMetadata
    var content: ClipContent
    var folderID: Folder.ID?
    var tagIDs: Set<Tag.ID>
    var isFavorite: Bool
    var sortingState: SortingState
    var deletion: DeletionState
    var assetIDs: [ImageAsset.ID]
}
```

### Stable enum

```swift
enum ThemePreference: String, Codable {
    case system, light, dark
}

enum ShareSaveMode: String, Codable {
    case quick, review
}
```

번역 문자열은 `L10n`에서 만들며 raw storage에 한국어 “켬/끔”을 저장하지 않는다.

### Date

- `createdAt`, `updatedAt`, optional `capturedAt`, `deletedAt`
- JSON에서는 ISO 8601 with fractional seconds 또는 epoch; 한 방식으로 고정
- 상대 시간은 렌더링 시 계산

### IDs와 참조

- Clip/Folder/Tag/Image는 UUID
- 삭제된 folder/tag 참조 migration 규칙
- import 시 external ID namespace 또는 remap table
- 중복 canonical key는 별도 index

## 6. Snapshot 포맷

내부 snapshot을 당분간 유지한다면 다음 envelope를 쓴다.

```json
{
  "format": "clipinbox-library",
  "schemaVersion": 3,
  "createdAt": "2026-07-11T00:00:00.000Z",
  "appVersion": "0.4.0",
  "recordCount": 123,
  "payloadChecksum": "sha256:...",
  "payload": {
    "clips": [],
    "folders": [],
    "tags": [],
    "preferences": {}
  }
}
```

### Load state machine

```text
no current
 └─ firstRun(empty library)

valid current
 └─ ready

invalid current + valid previous
 └─ recovered(previous), current quarantined

invalid current + invalid previous
 └─ recoveryRequired (절대 sample로 overwrite하지 않음)

future schema
 └─ updateRequired / unsupportedVersion
```

### Commit algorithm

1. actor에서 current state copy를 draft로 생성
2. operation과 domain validation
3. encode compact
4. decode roundtrip + semantic check
5. temp fsync/atomic write
6. current→previous rotate
7. temp→current replace
8. asset transaction commit
9. state publish
10. previous retention policy 적용

운영체제 API가 명시적 fsync를 추상화하는 수준과 atomic replace semantics는 실제 구현에서 검증한다.

## 7. SQLite/SwiftData 이전 판단

### snapshot 유지가 가능한 조건

- 라이브러리 상한이 명확함(예: 2,000 clips)
- save p95가 성능 예산 내
- 검색 index를 별도 유지 가능
- migration/recovery가 충분히 테스트됨

### DB가 필요한 조건

- “무제한” 보관 마케팅
- 5,000+ clip
- full-text/복합 필터/날짜 정렬
- batch mutation
- sync conflict/versioning
- 부분 로드와 background indexing

### 선택

- Apple-only, 단순 CRUD: SwiftData
- migration/FTS/transaction 세밀 제어: SQLite/GRDB 계열
- 외부 dependency를 피하고 싶다면 SQLite C API wrapper 또는 Core Data도 가능

본 보고서는 특정 라이브러리를 즉시 도입하라고 강제하지 않는다. 먼저 `ClipRepository`를 만들면 backend 선택이 가역적이다.

## 8. Share Extension 설계

```text
NSItemProvider
  └─ ProviderLoader(deadline, cancellation)
      ├─ URL/Text normalizer
      └─ ImageIngestor
          ├─ file representation preferred
          ├─ metadata/byte/pixel validation
          ├─ preview downsample
          └─ staged original/optimized copy
                ↓
         QueueEnvelope + staged asset reference
                ↓ atomic commit
         App Group queue
```

### 제한 정책 예시

- text: 100KB 또는 product-specific cap
- URL: 8KB
- single image: 50MB encoded, 100MP decoded pixel cap 등 실측 기반
- queue: 500 items 또는 2GB 중 먼저 도달
- pending TTL: 30일, 삭제 전 사용자/앱에 diagnostics

숫자는 제품 정책 예시이며 실제 기기 benchmark 후 확정한다.

## 9. Image pipeline

### 저장

- 원본 파일 확장자만 신뢰하지 않고 type sniffing
- staged temporary file
- image metadata validate
- optional optimized copy
- content hash와 pixel dimensions 저장
- clip commit 후 owner reference

### 표시

- 목록은 target-size thumbnail만 decode
- detail도 screen pixel size에 맞춰 downsample
- full-screen에서 필요 시 더 큰 decode
- `NSCache.totalCostLimit`, memory warning purge
- corrupt/missing asset placeholder + repair action

### 삭제

- soft-deleted clip 동안 asset 유지
- trash purge transaction에서 ref count 0인 자산 삭제
- periodic orphan reconciliation

## 10. 검색

### 단기

- Unicode normalization, lowercasing/diacritic folding
- title/source/url/memo/tag token index
- query debounce와 background actor
- folder/type/favorite/date scope

### DB 이후

- FTS table
- canonical URL host index
- exact tag/folder foreign keys
- duplicate hash index
- incremental indexing

검색어와 결과를 외부 서버로 보내지 않는다.

## 11. App Lock/Privacy architecture

```text
LockController state:
disabled
locked(reason)
authenticating
unlocked(sessionExpiry)
errorRecoverable
```

- scene inactive → privacy cover는 lock state와 무관하게 즉시 표시 가능
- background → session expire policy
- capability unavailable → locked/error, never unlocked by default
- repository encryption을 도입하면 lock controller와 key access policy를 분리
- UI는 잠금 전 민감 feature view를 instantiate하지 않거나 redaction layer를 보장

## 12. Presentation state

```swift
enum LibraryViewState {
    case loading
    case ready(LibraryPresentation)
    case empty
    case recovered(RecoveryNotice)
    case degraded(RecoverableProblem)
    case failed(FatalProblem)
}
```

Toast 하나로 모든 상태를 처리하지 않는다. 성공은 accessibility announcement, Undo는 action banner, 복구는 persistent state screen, validation은 inline error로 분리한다.

## 13. 의존성 주입

```swift
struct AppEnvironment {
    let repository: any ClipRepository
    let queue: any CaptureQueue
    let images: any ImageStore
    let preferences: any PreferencesStore
    let lock: LockController
    let clock: any Clock
    let ids: any IDGenerator
    let diagnostics: any Diagnostics
}
```

- production/simulator/preview/test environment
- sample data는 preview environment에만
- release URL/App Group은 generated config
- 테스트는 temporary directory와 deterministic clock/IDs 사용

## 14. 관측성과 개인정보

- OSLog category: bootstrap, transaction, queue, image, import, lock
- 메시지에는 error code, byte bucket, count, duration만
- URL/title/text/tag/folder/path는 `.private` 또는 기록하지 않음
- signpost로 launch/search/save/share duration
- 사용자가 export할 diagnostics는 redacted summary

## 15. 단계적 이전

### Migration 0 — Characterization

현재 성공 흐름을 테스트로 고정한다. 단, false-success 같은 버그를 expected behavior로 고정하지 않는다.

### Migration 1 — Interface wrapping

현재 JSON/queue 구현을 protocol 뒤에 감싼다. UI 동작은 유지한다.

### Migration 2 — Typed model

localized strings→enum, `time`→Date, Int ID→UUID를 schema migrator로 이전한다.

### Migration 3 — Transaction/recovery

모든 mutation과 image lifecycle을 원자적 계약으로 전환한다.

### Migration 4 — UI state/a11y

async state, error/recovery, semantic typography를 적용한다.

### Migration 5 — Backend decision

benchmark 후 snapshot 유지 또는 SQLite repository 추가. 둘 다 같은 use cases를 사용한다.

## 16. 비목표

- Clean Architecture 명칭을 맞추기 위한 과도한 파일 분할
- 모든 protocol을 public framework로 만들기
- 1.0 전에 sync conflict engine 구현
- 단순 설정까지 복잡한 use case 객체로 감싸기
- 현재 잘 작동하는 SwiftUI 화면을 UIKit/타 프레임워크로 재작성

## 17. 목표 아키텍처 완료 기준

- View가 `FileManager`, App Group URL, JSON encoder를 직접 알지 않음
- 모든 mutation failure injection 가능
- 손상/미지원 schema가 sample data로 대체되지 않음
- queue/image/clip commit가 idempotent하고 orphan reconciliation 가능
- AppStore/ViewModel 300줄 이하 또는 책임 기준으로 명확히 분리
- 5k fixture에서 성능 예산 측정 가능
- release archive와 동일 configuration을 CI/QA에서 재현 가능


---

# Screen-by-Screen Improvement Specification

## 1. 공통 화면 원칙

- Safe Area와 native `NavigationStack`/`NavigationSplitView`를 우선한다.
- text는 semantic Dynamic Type style, interactive target은 최소 44×44pt.
- 모든 화면은 loading / empty / content / recoverable error / fatal recovery 상태를 정의한다.
- 성공 toast, Undo banner, inline validation, recovery screen을 목적에 맞게 분리한다.
- 한국어·영어·일본어 40% 확장과 AX5에서 reflow한다.
- 데이터 변경 성공은 durable commit 뒤에만 표시한다.

## 2. 화면 요약표

| 화면 | 현재 문제 | 사용자 영향 | 개선 레이아웃 | 동작 변경 | 상태 처리 | 접근성 | 우선순위 |
|---|---|---|---|---|---|---|---|
| Launch/Bootstrap | 손상과 첫 실행 미구분 | 데이터 유실 은폐 | neutral loading→empty/recovery 분기 | repository bootstrap 결과 기반 | recovery/fatal 전용 | 화면 전환 announcement | P0 |
| Onboarding | 없음 | 핵심 Share 기능 미발견 | 3단계 guide + practice | Favorites/Quick/Review 안내 | skip/revisit | 정적 이미지 대체 텍스트 | P1 |
| Inbox | 5열 고정 filter, sample 구분 없음 | 스캔·큰 글자 어려움 | title + smart views + list | filter sheet, pull refresh queue | empty/degraded/queue notice | dynamic rows/row actions | P1 |
| Add | demo 생성 | 핵심 CTA가 가짜 | type picker + adaptive form | 실제 URL/text/photo/memo 저장 | validation/duplicate/save fail | labelled fields, focus | P0 |
| Clip Row | fixed height/small actions | 잘림·오터치 | min-height adaptive row | swipe favorite/move/trash | missing asset badge | contextual labels/44pt | P1 |
| Detail | one-viewport 고정 | 큰 글자·긴 메모 문제 | scroll sections + sticky actions | edit transaction, link domain confirm | missing asset/save error | heading/rotor/order | P1 |
| Search | substring only | 재검색 약함 | query + scope chips + filters | tokenized results/recent clear | no result suggestions | result count announcement | P2 |
| Folders/Library | 폴더만 강조 | IA 중복 | smart views + folders + trash | create/rename/merge/delete | empty/conflict | reorder/labels | P2 |
| Folder Detail | batch 없음 | 정리 피로 | list + select mode | multi-move/tag/trash | commit result summary | selection value | P2 |
| Sort Later | 한 건씩 | backlog 처리 느림 | card/list triage + quick destinations | swipe/keyboard/batch | no unsorted complete state | action hints | P2 |
| Settings | storage/privacy 정보 부족 | 신뢰·관리 약함 | Capture/Privacy/Storage/Backup/Appearance/Help | async setting commit | unsynced config warning | grouped controls | P1 |
| App Lock | fail-open | 민감정보 노출 | opaque shield + unlock | fail-closed state machine | capability/retry/recovery | focus unlock/error | P0 |
| Share Quick | 2초 고정·오류 불명확 | 느림/가짜 성공 위험 | compact progress/success/error card | durable enqueue 후 complete | timeout/too-large/app-group | announcement, cancel | P0 |
| Share Review | custom control·긴 내용 | host별 사용성 | adaptive scroll form | mode change/save retry | provider/validation errors | native controls/labels | P1 |
| Full Image | zoom 후 pan 부족 | 세부 보기 어려움 | scroll zoom canvas + toolbar | pan/double tap/reset/share | missing/corrupt image | zoom value/action labels | P2 |
| Trash | 없음 | 오삭제 복구 불가 | deleted list + retention | restore/permanent/empty | partial failure | destructive clarity | P1 |
| Recovery Center | 없음 | 손상/queue 문제 대응 불가 | backup/corrupt/queue status | restore/export/reset options | persistent evidence | clear reading order | P0/P1 |
| Storage | 없음 | 원본 누적 인지 불가 | usage chart/list/cleanup preview | optimize/delete by policy | scan progress/failure | values not color-only | P1 |
| Import/Export | 범위·평문·version 부족 | 데이터 손실/유출 | archive summary + options | dry run, merge/replace, encrypted export | unsupported/corrupt/rollback | progress and errors | P0/P1 |

## 3. Launch / Bootstrap / Recovery

### 목표

앱이 저장소 상태를 판단하기 전 Inbox를 보이지 않는다.

### 상태

```text
[Loading]
Clip Inbox logo
“보관함을 확인하는 중…”

[Recovered]
“마지막 정상 백업에서 복구했습니다”
23개 항목 · 2026-07-10 22:14
[복구 내용 보기] [계속]

[Recovery Required]
“보관함을 열 수 없습니다”
원본 파일은 보존했습니다.
[이전 백업 복원] [손상 파일 내보내기] [지원 도움말]
위험 영역: [빈 보관함으로 시작]
```

### 요구

- Empty와 corrupt를 절대 같은 branch로 처리하지 않는다.
- “초기화”는 마지막 선택이며, typed confirmation과 원본 export를 제공한다.
- VoiceOver는 recovered/recovery status를 첫 focus로 읽는다.

## 4. Onboarding

### 3단계

1. **공유해서 저장** — Safari, Photos, 다른 앱의 Share button에서 Clip Inbox 선택
2. **바로 저장하거나 검토** — Quick/Review 모드 설명
3. **나중에 정리** — Unsorted, folder, tag, search

### 마지막 CTA

- Primary: `첫 클립 저장하기`
- Secondary: `직접 URL 추가`
- Tertiary: `나중에`

Share Extension의 순서를 앱이 강제로 바꿀 수 있다고 표현하지 않는다. 사용자가 Share Sheet 편집에서 Favorites로 관리한다는 사실을 안내한다.

## 5. Inbox

### 권장 와이어프레임

```text
┌──────────────────────────────┐
│ Clip Inbox             [···] │
│ 24 clips · Local on device   │
│                              │
│ [Unsorted 4] [Favorites] [▾] │
│                              │
│ Today                        │
│ [thumb] Title that can wrap  │
│         source · 2h          │
│         tag  tag         [···]│
│ ──────────────────────────── │
│ [icon ] Text clip title      │
│         first body line      │
│                              │
│ Inbox Folders  + Search Set  │
└──────────────────────────────┘
```

### 변경

- 상단 10개 고정 cell을 `Unsorted`, `Favorites`, `Filter`로 줄인다.
- 나머지 타입·폴더·태그는 filter sheet에서 multi-select.
- sample content는 production에서 기본 생성하지 않는다.
- pending queue가 있으면 “공유 항목 3개 가져오는 중” inline status.
- storage/recovery 문제가 있으면 persistent banner, 단순 toast 금지.

### Row

- thumbnail 52–64pt, 텍스트는 2줄까지 자연스럽게 확장
- metadata는 source + formatted relative date
- tag는 최대 2개 + `+N`, AX size에서는 별도 줄
- whole row opens detail; ellipsis 44pt contextual action
- swipe: Favorite / Move / Trash, destructive action은 Undo

## 6. Manual Add

### 권장 진입

Add 탭 클릭 → 작은 type chooser가 아니라 바로 form에 type segmented/chips를 제공한다.

```text
Add Clip
[Link] [Text] [Photo] [Memo]

URL *
https://…
[Paste]

Title (optional)
…
Folder                         >
Tags                           >
Note
…

[Save Clip]
```

### 동작

- clipboard paste는 사용자가 버튼을 눌렀을 때만 수행한다.
- URL 입력은 scheme normalization과 domain preview.
- Photo는 PhotosPicker; byte/pixel 정책을 저장 전 표시.
- duplicate 발견 시:
  - 이미 저장됨: date/folder 표시
  - `기존 항목 열기`, `메모 합치기`, `별도로 저장`
- save 버튼은 validation 중/commit 중 상태를 명확히 표시하고 중복 탭을 막는다.

## 7. Clip Detail

### 권장 구조

```text
Navigation title / Back
[Adaptive preview]
Title
source.domain · captured date
[Open Link]

Organization
Folder                         >
Tags             [tag] [tag] [+]
Favorite                       toggle

Note
[Multiline editor, grows]

Actions
[Share] [Move] [Export]
[Move to Trash]
```

### 개선

- 한 viewport에 모두 넣기 위해 media/editor를 고정 축소하지 않는다.
- URL open 전 confirm mode에서는 실제 domain, punycode warning, full host를 표시한다.
- missing/corrupt image는 placeholder와 `원본 찾기/진단`을 제공한다.
- 편집은 자동 저장이든 명시 Save든 한 방식을 선택하고 commit 상태를 일관되게 보여준다.
- header/section에 accessibility heading trait를 적용한다.

## 8. Search

### 구조

```text
Search
[ query                          × ]
Scope: [All] [Link] [Image] [Text] [Favorite]
[Folder ▾] [Tags ▾] [Date ▾]

Recent searches                 [Clear]
Results · 18
...
```

### 검색 계약

- Unicode normalization
- title/source/domain/url/memo/tag
- exact phrase와 token AND/OR 정책 문서화
- empty query에는 recent/favorites/recently opened 중 하나를 표시
- no result에는 filter reset, spelling suggestion, manual Add 제공
- 검색어는 외부 서버로 보내지 않는다.

## 9. Library / Folders

Folders tab을 “Library”로 확장하는 안을 권장한다.

```text
Library
Smart
  Inbox                        24
  Unsorted                      4
  Favorites                     6
  Images                       10
  Trash                         2
Folders
  Work                          7
  Inspiration                   9
  Travel                        3
[New Folder]
```

### Folder actions

- rename
- merge into…
- delete with destination choice
- default tag edit
- item count와 size 선택 표시

폴더 삭제 시 포함 clip을 함께 영구 삭제하지 않는다.

## 10. Sort Later

### 목표

분류를 “업무”가 아니라 짧은 triage로 만든다.

```text
Sort Later · 4 remaining
[preview]
Title/source

Recent destinations
[Work] [Ideas] [Travel] [More]
Tags
[reference] [read] [+]

[Skip]            [Save & Next]
```

- swipe right = recent folder, left = skip처럼 숨은 제스처만 의존하지 않는다.
- 명시 버튼과 keyboard shortcut(iPad/Mac)을 병행한다.
- batch mode는 1.1에서 추가.
- 완료 상태: “모두 정리했습니다” + Inbox CTA.

## 11. Settings

### 정보 구조

```text
Capture
  Share save mode
  Default folder
  Image quality / original policy
  Share Extension guide

Privacy & Lock
  App lock
  Lock timing
  Hide app switcher preview
  Privacy policy

Storage
  482 MB used
  Images 450 MB · Queue 12 MB
  Retention / Cleanup

Backup & Restore
  Export archive
  Import archive
  Recovery center

Appearance
  Theme / Language

Help
  Support / Version / Licenses

Danger Zone
  Delete all data
```

### 설정 저장

앱과 extension 사이 config write가 실패하면 setting을 성공처럼 바꾸지 않는다. `확장 설정을 동기화하지 못했습니다 [다시 시도]`를 보여준다.

## 12. App Lock

```text
[opaque branded background]
lock icon
Clip Inbox is Locked
“Face ID, Touch ID 또는 기기 암호로 열기”
[Unlock]
error/retry text
```

- sensitive background screenshot 금지
- capability unavailable를 자동 unlock으로 처리하지 않음
- support/recovery는 콘텐츠를 노출하지 않는 범위에서만 제공
- auth 시작은 사용자의 명시적 CTA 또는 screen appear 자동 시작 중 일관된 정책

## 13. Share Extension — Quick

### 상태

```text
Saving…
[progress]

Saved to Inbox ✓
[Change to review next time]

Couldn’t Save
Reason in user language
[Try Again] [Cancel]
```

- enqueue commit 전 성공 표시 금지
- 2초 고정 대기 대신 짧은 accessible confirmation 또는 즉시 host return
- VoiceOver announcement 후 completion이 announcement를 잘라내지 않는지 검증
- too-large image는 선택적 optimize 또는 cancel

## 14. Share Extension — Review

```text
Clip Inbox                     [Cancel]
[small preview]
Title / content summary
Folder                         >
Tags                           >
Note
...
[Save]
```

- small screen/keyboard에서 form 전체 scroll
- native controls와 clear focus order
- provider load와 UI edit를 분리해 loading skeleton 표시
- save 실패 후 입력을 유지
- mode setting 링크는 main app으로 자동 전환하지 말고, host limitation을 설명

## 15. Full-screen Image

- `UIScrollView` 기반 zoom/pan 또는 동등한 안정적 구현
- single tap toolbar hide/show
- double tap 1×/fit/2× 순환
- reset, share/export, metadata 선택
- close target 44pt
- image title과 zoom percentage를 accessibility value로 제공
- Reduce Motion에서 zoom transition 단순화

## 16. Trash

```text
Trash
“Items are permanently deleted after 30 days”
[Select]

clip row · 12 days left
[Restore] [Delete Now]

[Empty Trash]
```

- retention 기간은 설정 가능
- image asset는 retention 동안 유지
- Empty Trash는 개수/용량과 되돌릴 수 없음을 명시
- 일부 asset delete 실패 시 clip metadata를 조용히 잃지 않고 cleanup pending 상태 유지

## 17. Recovery Center

```text
Recovery Center
Library
  Current snapshot       Healthy
  Previous backup        Jul 10 · 23 clips
  Quarantined file       1         [Export]

Share Queue
  Pending                2
  Failed                 1         [Review]
  Orphan images          3 · 18 MB [Clean Up]

[Run Check]
```

일반 사용자에게 기술 파일명을 과도하게 노출하지 않되, 지원 시 redacted diagnostics를 내보낼 수 있게 한다.

## 18. Storage

- total app data
- clips metadata
- original images
- optimized thumbnails/cache
- pending queue
- trash
- orphan/recoverable files

cleanup은 즉시 실행 전에 예상 절감 용량과 영향을 preview한다. cache는 안전하게 지울 수 있음을 구분하고, 원본·trash 삭제는 명시적 확인을 요구한다.

## 19. Import/Export

### Export

```text
Create Backup
23 clips · 8 images · 420 MB
[x] Include original images
[x] Include settings/tags
[ ] Encrypt with password
“This file may contain private content.”
[Create Backup]
```

### Import dry run

```text
Backup from Jul 10
Schema 3 · 23 clips · 8 images
Duplicates 4 · New 19
[Merge] [Replace Existing]
[Import]
```

- unsupported version은 update 안내
- import 중 앱 종료 후에도 기존 library가 온전해야 함
- 실패 시 staged files 정리

## 20. 화면별 QA matrix

모든 핵심 화면에서 다음 조합을 최소 검증한다.

- iPhone compact / iPad regular / split width
- light / dark / increase contrast
- Korean / English / Japanese / pseudo-long
- default / XXXL / AX5 Dynamic Type
- VoiceOver on
- empty / one item / many items / error
- online/offline은 외부 link preview 기능에만 영향
- lock on/off

## 21. 최종 UI 명세 판정

현재 브랜드와 기본 내비게이션은 유지한다. 가장 큰 UI 개선은 색·그림자를 다시 디자인하는 일이 아니라, **Add·Onboarding·Recovery·Trash·Storage라는 누락 화면을 만들고 모든 기존 화면을 적응형·접근 가능하게 바꾸는 것**이다.


---

# ClipInbox Final Verdict

## 1. 최종 판정

**현재 상태로 공개 App Store 출시는 부적합하다.**

정확한 등급은 **“주요 수정 후 출시 가능”**이다. 네이티브 앱과 Share Extension, 로컬 저장, 폴더·태그·검색, 다국어·다크 모드라는 제품 골격은 이미 있다. 문제는 구현량이 부족해서가 아니라, 개인 데이터 보관 앱의 핵심 계약인 **“저장됐다고 표시되면 실제로 안전하게 저장돼 있고, 손상·삭제·잠금 실패를 사용자가 복구하거나 이해할 수 있어야 한다”**가 아직 보장되지 않는다는 점이다.

종합 점수: **58/100**

## 2. 질문별 최종 답변

### 2.1 현재 상태로 출시 가능한가

아니다.

- 내부 개발/디자인 검증용으로는 충분하다.
- P0 수정 후 제한 TestFlight는 가능하다.
- 공개 출시에는 P0와 데이터·privacy·accessibility 관련 High P1, 정책 URL·signed archive gate가 모두 필요하다.

### 2.2 출시를 막는 문제는 무엇인가

1. 주 데이터 손상을 샘플 데이터로 조용히 대체
2. 다수 mutation이 저장 실패를 무시하고 성공 표시
3. 실제 Add가 아닌 하드코딩 demo 생성
4. Share Extension 대형 이미지 memory/용량 무제한
5. 앱 잠금 fail-open
6. schema version/migration/recovery 부재
7. CI·failure tests·extension E2E·archive validation 부재
8. privacy/support URL과 App Store 자료 미완료
9. signed physical-device App Group/Face ID 검증 미완료
10. 접근성·삭제 복구·storage controls 부족

### 2.3 가장 먼저 수정할 10개 항목

| 순서 | ID | 작업 | 완료 증거 |
|---:|---|---|---|
| 1 | DATA-001/DATA-012 | 손상 감지, previous backup, quarantine, recovery UI | corrupt/truncated fixture 전부 통과 |
| 2 | DATA-002/TEST-002 | 모든 mutation transaction/rollback | disk-full fake에서 false-success 0 |
| 3 | DATA-003/TEST-003 | schema migrator, future version 차단 | v1/v2/current/future fixture matrix |
| 4 | REL-001/REL-002 | 이미지 file ingest, byte/pixel cap, timeout/cancel | 48MP 실기기에서 crash 0 |
| 5 | SEC-001/SEC-002 | lock fail-closed, inactive privacy shield | Face ID cancel/unavailable/switcher tests |
| 6 | UX-001/FEATURE-001 | 실제 URL/text/photo/memo Add | demo 값 0, UI test 통과 |
| 7 | REL-003/005/006 | queue quarantine/quota/idempotency | corrupt/remove-fail/1k queue tests |
| 8 | UI-001~004 | Dynamic Type, 44pt, adaptive filter/reflow | AX5/3언어 snapshot blocker 0 |
| 9 | TEST-001/008 | CI와 Release archive gate | protected main checks + archive report |
| 10 | REL-010/014/015 | 실제 정책 URL, signing, App Store assets | signed TestFlight + metadata checklist |

### 2.4 최소 출시까지 필요한 작업

- 위 Top 10
- 첫 실행 onboarding/empty state
- 휴지통·Undo 또는 최소한의 안전 삭제 복구
- 평문 export 경고·versioned import/rollback
- storage usage·이미지 보존 정책
- VoiceOver core flow
- iPad support를 유지한다면 regular/split layout QA
- privacy policy, support, App Privacy, release notes
- external TestFlight와 rollback archive

### 2.5 완성도 높은 경쟁 제품 수준까지 필요한 작업

- smart views와 advanced filters
- duplicate detection
- batch triage
- fast indexed search
- Core Spotlight/App Intents/Shortcuts
- 온디바이스 OCR
- storage/retention transparency
- 선택적 iCloud sync 또는 Mac companion
- mature import ecosystem
- polished help/recovery/diagnostics

Paste나 Raindrop의 모든 기능을 따라갈 필요는 없다. ClipInbox는 local/no-account/explicit-share의 단순함을 잃지 않으면서 **신뢰·검색·복구·Apple 플랫폼 통합**만 경쟁 수준으로 올리는 것이 맞다.

### 2.6 이 프로젝트의 가장 큰 가능성은 무엇인가

**자동 clipboard history와 무거운 knowledge manager 사이의 공백**이다.

- 사용자가 의도적으로 공유한 것만 저장
- 계정/서버 없이 시작
- 이미지·텍스트·URL을 한 인박스에 모음
- 분류는 나중에
- Apple 생태계에서 native하고 빠른 경험

이 포지션은 개인정보에 민감하고 subscription을 싫어하며, Notes/Files/Photos에 자료가 흩어지는 사용자를 겨냥할 수 있다.

### 2.7 가장 큰 실패 위험은 무엇인가

기능 부족이 아니라 **신뢰 붕괴**다.

- 저장 성공이라고 했지만 재실행하면 사라짐
- 손상됐는데 샘플 데이터가 보임
- 앱 잠금을 켰는데 특정 상태에서 열림
- 대형 사진을 공유하면 확장이 종료됨
- 삭제 후 복구할 수 없음

개인 보관 앱에서 한 번의 데이터 손실은 낮은 별점보다 장기 retention 자체를 무너뜨린다.

### 2.8 계속 개발할 가치가 있는가

있다.

- 프로토타입 수준을 넘어 native app/extension/data flow가 있다.
- 로컬 우선 범위가 명확하다.
- UI 기반이 좋고 localization도 시작돼 있다.
- 외부 runtime dependencies와 서버가 없어 수정 면적이 통제 가능하다.

다만 다음 개발 사이클은 AI·sync·새 플랫폼이 아니라 데이터 안전과 release engineering에 집중해야 한다.

### 2.9 어떤 제품 방향이 가장 적합한가

**Privacy-first Share-to-Inbox for Apple devices**

- 1.0: iPhone/iPad local-only, no account, one-time/free+Pro
- 1.x: OCR, batch, Spotlight, Shortcuts
- 2.0 후보: optional iCloud sync, Mac companion
- 비추천: 광고, 기본 서버 업로드, 자동 clipboard 감시, 초기 team collaboration

### 2.10 최종 권고안

현재 UI와 기능을 폐기하지 말고 6–10주 규모의 “Data-Safe 1.0” 프로그램으로 전환한다.

1. repository/recovery/transaction
2. extension image/queue
3. lock/privacy
4. manual Add/onboarding/trash/storage
5. accessibility/search polish
6. CI/signed TestFlight/App Store

## 3. 종합 점수

| 영역 | 점수 |
|---|---:|
| 제품 컨셉 | 82 |
| 기능 완성도 | 64 |
| 코드 품질 | 56 |
| 아키텍처 | 52 |
| UI | 74 |
| UX | 64 |
| 접근성 | 45 |
| 성능 | 55 |
| 안정성 | 48 |
| 보안 | 56 |
| 개인정보 보호 | 67 |
| 테스트 | 42 |
| 배포 준비도 | 41 |
| 문서화 | 70 |
| 경쟁력 | 56 |
| **종합** | **58** |

## 4. 출시 판정 기준

### 현재

- **현재 출시 부적합**

### 제한 TestFlight 가능 조건

- P0 data/extension/lock/Add 0개
- signed device 핵심 flow 통과
- corrupt/disk-full/migration tests
- 실제 privacy/support 연락 경로

### 공개 App Store 가능 조건

- P0 0개
- data/privacy/accessibility High P1 0개
- onboarding/trash/storage/recovery
- CI + release archive/privacy report
- external TestFlight blocker 0
- 정확한 metadata/screenshots/policy

## 5. Top 10 문제

1. **DATA-001** — 손상 스냅샷의 sample fallback
2. **DATA-002** — persist 실패 무시와 false-success
3. **UX-001** — demo Add
4. **REL-001** — Share Extension 이미지 memory/storage 무제한
5. **SEC-001** — app lock fail-open
6. **DATA-003** — schema migration/version gate 없음
7. **TEST-001/002/003** — CI·failure/migration tests 없음
8. **REL-010/014/015** — 정책 URL·signed release·store assets 미완료
9. **UI-001/002/003/004** — Dynamic Type·touch·adaptive layout 부족
10. **DATA-009/UX-011** — 삭제 복구·storage controls 없음

## 6. Top 10 비용 대비 개선

1. 파일 없음과 decode failure를 분리
2. 성공 toast를 `persist == true` 이후로 제한하고 rollback
3. sample data를 Preview로 이동
4. app switcher privacy cover
5. pending queue를 `createdAt`으로 정렬
6. corrupt queue quarantine
7. chip hit target 44pt
8. 하드코딩 accessibility label localization
9. internal JSON에서 pretty print 제거
10. root README/LICENSE/SECURITY와 실제 support/privacy URL

위 항목 중 1–4는 코드량 대비 위험 감소가 특히 크다. 다만 `persist == true`만 확인하는 임시 patch에 머물지 말고 transaction 구조로 이어가야 한다.

## 7. 오늘 바로 시작할 작업

1. `AppStore.init`을 `firstRun / loaded / corrupt / unsupported` 결과로 분리하는 characterization test 작성
2. 쓰기 실패 fake를 만들고 `deleteClip`, `updateMemo`, `saveNewClip`, `deleteAllData`의 false-success를 재현
3. `ClipRepository`와 `SnapshotRecovery` interface 생성
4. 하드코딩 demo Add를 feature flag 뒤로 숨기고 production UI에서 비활성화
5. app lock capability unavailable test와 privacy shield 구현
6. Share image의 byte/pixel logging-free measurement를 추가하고 임시 hard cap 적용
7. actual support/privacy domain·email 소유 결정
8. GitHub Actions macOS build/unit skeleton 생성
9. Dynamic Type AX5에서 Inbox/Detail/Settings screenshot baseline 생성
10. 모든 P0를 GitHub issue로 옮기고 본 보고서 ID를 유지

## 8. 불확실성과 검증 필요

- Xcode build/test 결과는 독립 재실행하지 못했다.
- 저장소 QA evidence의 simulator 결과는 작성자 기록으로만 인정했다.
- folder deletion, image cache cost limit, 일부 VoiceOver semantic은 전체 checkout/실행에서 재확인해야 한다.
- 실제 App Store Connect, Apple Developer profile, privacy report, physical-device behavior는 접근할 수 없었다.
- 경쟁 제품 가격과 Apple 정책은 변경될 수 있어 제출 직전 공식 페이지를 다시 확인해야 한다.

이 제한은 P0 판단을 약화하지 않는다. 핵심 데이터/잠금/이미지 위험은 공개된 소스의 제어 흐름에서 직접 확인되는 구조적 문제다.

## 9. 최종 한 문장

**ClipInbox는 제품 방향과 시각 기반이 좋은 초기 iOS 앱이지만, “저장·잠금·복구”의 신뢰 계약을 먼저 완성해야만 프라이버시 중심 제품이라는 장점이 실제 경쟁력으로 바뀐다.**


---

# Source & Evidence Register

## 1. 감사 시점과 신뢰 등급

- 기준일: 2026-07-11
- 저장소: `https://github.com/eiranotes/ClipInbox`, public `main`
- A등급: 공개 소스 코드·project setting에서 직접 확인
- B등급: 저장소 내부 문서·작성자 QA evidence에서 확인했으나 독립 실행하지 못함
- C등급: 정적 제어 흐름·UI evidence를 바탕으로 한 합리적 추정
- D등급: macOS/Xcode·실기기·signed archive·App Store Connect 검증 필요

## 2. 저장소 핵심 근거

| 근거 | 등급 | 사용한 판단 |
|---|---|---|
| `AGENTS.md` | A | `ios/`가 production source of truth, 루트 web은 historical prototype |
| `ios/project.yml` | A | iOS 17, Swift 5.10, version 0.3.0, app/share/test targets, bundle IDs, App Group/signing 설정 |
| `ios/ClipInbox/Store/AppStore.swift` | A | snapshot load/save, mutation, import/export, queue import, demo Add, false-success |
| `ios/ClipInbox/Models/Models.swift` | A | `DataSnapshot.version`, localized preferences, Int ID, String time, DefaultData |
| `ios/ClipInbox/Shared/SharedClipQueue.swift` | A | per-item queue, file protection, UUID image validation, silent corrupt skip, ordering/quota |
| `ios/ClipShareExtension/ShareViewController.swift` | A | provider loading, full Data/UIImage paths, Quick/Review, no timeout |
| `ios/ClipInboxTests/AppStoreTests.swift` | A | 현재 unit-test 범위와 failure/migration/E2E 공백 |
| `docs/TASKS.md` | B | date model, Face ID physical test, release signing, support/privacy URL, App Store tasks가 deferred |
| `docs/app-store/*` | B | ASO copy, privacy draft, screenshot/release checklist, placeholder contacts |
| `.superloopy/evidence/ios/*` | B | simulator build, extension embedding, App Group, Safari/Photos flow의 저장소 작성자 증거 |
| UI evidence screenshots | B/C | list-first Inbox, dark settings/folders, lock, Share Extension, image viewer 시각 감사 |
| GitHub repository root | A | 9 commits, no release, no root README/LICENSE visible, no description/topics |

## 3. 독립 검증하지 못한 항목

- XcodeGen project generation
- Xcode build/XCTest
- simulator interaction
- physical iPhone/iPad behavior
- Face ID/Touch ID/passcode combinations
- Release Distribution signing and App Group profile
- Instruments memory/CPU/battery
- App Store archive/privacy report/validation
- App Store Connect metadata and privacy answers
- file-system protection attributes on installed build
- actual outbound network behavior

저장소 내부에서 “passed”라고 기록된 항목은 본 보고서에서 B등급으로 구분했으며, 최종 출시 gate에서는 다시 실행해야 한다.

## 4. Apple 공식 자료

조사일 이후 내용이 바뀔 수 있으므로 제출 직전에 다시 확인한다.

- App Review Guidelines: https://developer.apple.com/app-store/review/guidelines/
- App privacy details overview: https://developer.apple.com/app-store/app-privacy-details/
- Privacy manifest files: https://developer.apple.com/documentation/bundleresources/privacy_manifest_files
- Required Reason APIs: https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api
- App extensions: https://developer.apple.com/app-extensions/
- Human Interface Guidelines: https://developer.apple.com/design/human-interface-guidelines/
- Accessibility: https://developer.apple.com/accessibility/
- Supporting Dynamic Type: https://developer.apple.com/documentation/uikit/scaling_fonts_automatically
- LocalAuthentication: https://developer.apple.com/documentation/localauthentication
- File protection: https://developer.apple.com/documentation/foundation/fileprotectiontype

## 5. 경쟁 제품 공식 자료

- Paste: https://pasteapp.io/
- PastePal: https://indiegoodies.com/pastepal
- Maccy: https://maccy.app/
- Pastery: https://pastery.app/
- Anybox: https://anybox.app/
- GoodLinks: https://goodlinks.app/
- Raindrop Pro: https://raindrop.io/pro/buy
- Readwise pricing: https://readwise.io/pricing
- mymind pricing: https://mymind.com/pricing

가격·기능·플랫폼은 지역/시점에 따라 변할 수 있다. 보고서의 가격은 2026-07-11 조사 스냅샷이며 구매 의사결정 전에 공식 결제 화면에서 재확인한다.

## 6. 분석 표식

- `[확인됨]`: A등급 코드/설정 또는 명시 문서로 직접 확인
- `[추정]`: C등급 정적 분석, 실행 검증 필요 가능
- `[검증 필요]`: D등급 환경/계정/실기기 요구
- `[중대 위험]`: 데이터 유실·노출·앱 실행/심사 실패에 직접 연결
- `[개선 권장]`: 출시 차단은 아니나 품질·유지보수 개선
- `[기능 제안]`: 현재 구현 사실이 아닌 후속 제품 제안

## 7. 재현 권장 명령

macOS/Xcode가 있는 clean runner에서 저장소 지침을 일반화해 수행한다.

```bash
cd ios
xcodegen generate --spec project.yml
xcodebuild \
  -project ClipInbox.xcodeproj \
  -scheme ClipInbox \
  -configuration Debug \
  -destination 'platform=iOS Simulator,name=iPhone 17 Pro' \
  -derivedDataPath .build/DerivedData \
  COMPILER_INDEX_STORE_ENABLE=NO \
  build test
```

실제 simulator 이름은 설치된 runtime에 맞춰 선택한다. Release candidate에서는 `archive`, entitlements inspection, privacy report, TestFlight signed install을 별도 수행한다.

