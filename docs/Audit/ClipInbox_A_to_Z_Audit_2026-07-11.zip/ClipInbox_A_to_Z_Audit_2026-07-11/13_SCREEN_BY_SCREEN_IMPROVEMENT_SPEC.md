# Screen-by-Screen Improvement Specification

## 1. 공통 화면 원칙

- Safe Area와 native `NavigationStack`/`NavigationSplitView`를 우선한다.
- text는 semantic Dynamic Type style, interactive target은 최소 44×44pt.
- 모든 화면은 loading / empty / content / recoverable error / fatal recovery 상태를 정의한다.
- 성공 toast, Undo banner, inline validation, recovery screen을 목적에 맞게 분리한다.
- 한국어·영어·일본어 40% 확장과 AX5에서 reflow한다.
- 데이터 변경 성공은 durable commit 뒤에만 표시한다.

## 2. 화면 요약표

| 화면 | 현재 문제 | 사용자 영향 | 개선 레이아웃 | 동작 변경 | 상태 처리 | 접근성 | 우선순위 |
|---|---|---|---|---|---|---|---|
| Launch/Bootstrap | 손상과 첫 실행 미구분 | 데이터 유실 은폐 | neutral loading→empty/recovery 분기 | repository bootstrap 결과 기반 | recovery/fatal 전용 | 화면 전환 announcement | P0 |
| Onboarding | 없음 | 핵심 Share 기능 미발견 | 3단계 guide + practice | Favorites/Quick/Review 안내 | skip/revisit | 정적 이미지 대체 텍스트 | P1 |
| Inbox | 5열 고정 filter, sample 구분 없음 | 스캔·큰 글자 어려움 | title + smart views + list | filter sheet, pull refresh queue | empty/degraded/queue notice | dynamic rows/row actions | P1 |
| Add | demo 생성 | 핵심 CTA가 가짜 | type picker + adaptive form | 실제 URL/text/photo/memo 저장 | validation/duplicate/save fail | labelled fields, focus | P0 |
| Clip Row | fixed height/small actions | 잘림·오터치 | min-height adaptive row | swipe favorite/move/trash | missing asset badge | contextual labels/44pt | P1 |
| Detail | one-viewport 고정 | 큰 글자·긴 메모 문제 | scroll sections + sticky actions | edit transaction, link domain confirm | missing asset/save error | heading/rotor/order | P1 |
| Search | substring only | 재검색 약함 | query + scope chips + filters | tokenized results/recent clear | no result suggestions | result count announcement | P2 |
| Folders/Library | 폴더만 강조 | IA 중복 | smart views + folders + trash | create/rename/merge/delete | empty/conflict | reorder/labels | P2 |
| Folder Detail | batch 없음 | 정리 피로 | list + select mode | multi-move/tag/trash | commit result summary | selection value | P2 |
| Sort Later | 한 건씩 | backlog 처리 느림 | card/list triage + quick destinations | swipe/keyboard/batch | no unsorted complete state | action hints | P2 |
| Settings | storage/privacy 정보 부족 | 신뢰·관리 약함 | Capture/Privacy/Storage/Backup/Appearance/Help | async setting commit | unsynced config warning | grouped controls | P1 |
| App Lock | fail-open | 민감정보 노출 | opaque shield + unlock | fail-closed state machine | capability/retry/recovery | focus unlock/error | P0 |
| Share Quick | 2초 고정·오류 불명확 | 느림/가짜 성공 위험 | compact progress/success/error card | durable enqueue 후 complete | timeout/too-large/app-group | announcement, cancel | P0 |
| Share Review | custom control·긴 내용 | host별 사용성 | adaptive scroll form | mode change/save retry | provider/validation errors | native controls/labels | P1 |
| Full Image | zoom 후 pan 부족 | 세부 보기 어려움 | scroll zoom canvas + toolbar | pan/double tap/reset/share | missing/corrupt image | zoom value/action labels | P2 |
| Trash | 없음 | 오삭제 복구 불가 | deleted list + retention | restore/permanent/empty | partial failure | destructive clarity | P1 |
| Recovery Center | 없음 | 손상/queue 문제 대응 불가 | backup/corrupt/queue status | restore/export/reset options | persistent evidence | clear reading order | P0/P1 |
| Storage | 없음 | 원본 누적 인지 불가 | usage chart/list/cleanup preview | optimize/delete by policy | scan progress/failure | values not color-only | P1 |
| Import/Export | 범위·평문·version 부족 | 데이터 손실/유출 | archive summary + options | dry run, merge/replace, encrypted export | unsupported/corrupt/rollback | progress and errors | P0/P1 |

## 3. Launch / Bootstrap / Recovery

### 목표

앱이 저장소 상태를 판단하기 전 Inbox를 보이지 않는다.

### 상태

```text
[Loading]
Clip Inbox logo
“보관함을 확인하는 중…”

[Recovered]
“마지막 정상 백업에서 복구했습니다”
23개 항목 · 2026-07-10 22:14
[복구 내용 보기] [계속]

[Recovery Required]
“보관함을 열 수 없습니다”
원본 파일은 보존했습니다.
[이전 백업 복원] [손상 파일 내보내기] [지원 도움말]
위험 영역: [빈 보관함으로 시작]
```

### 요구

- Empty와 corrupt를 절대 같은 branch로 처리하지 않는다.
- “초기화”는 마지막 선택이며, typed confirmation과 원본 export를 제공한다.
- VoiceOver는 recovered/recovery status를 첫 focus로 읽는다.

## 4. Onboarding

### 3단계

1. **공유해서 저장** — Safari, Photos, 다른 앱의 Share button에서 Clip Inbox 선택
2. **바로 저장하거나 검토** — Quick/Review 모드 설명
3. **나중에 정리** — Unsorted, folder, tag, search

### 마지막 CTA

- Primary: `첫 클립 저장하기`
- Secondary: `직접 URL 추가`
- Tertiary: `나중에`

Share Extension의 순서를 앱이 강제로 바꿀 수 있다고 표현하지 않는다. 사용자가 Share Sheet 편집에서 Favorites로 관리한다는 사실을 안내한다.

## 5. Inbox

### 권장 와이어프레임

```text
┌──────────────────────────────┐
│ Clip Inbox             [···] │
│ 24 clips · Local on device   │
│                              │
│ [Unsorted 4] [Favorites] [▾] │
│                              │
│ Today                        │
│ [thumb] Title that can wrap  │
│         source · 2h          │
│         tag  tag         [···]│
│ ──────────────────────────── │
│ [icon ] Text clip title      │
│         first body line      │
│                              │
│ Inbox Folders  + Search Set  │
└──────────────────────────────┘
```

### 변경

- 상단 10개 고정 cell을 `Unsorted`, `Favorites`, `Filter`로 줄인다.
- 나머지 타입·폴더·태그는 filter sheet에서 multi-select.
- sample content는 production에서 기본 생성하지 않는다.
- pending queue가 있으면 “공유 항목 3개 가져오는 중” inline status.
- storage/recovery 문제가 있으면 persistent banner, 단순 toast 금지.

### Row

- thumbnail 52–64pt, 텍스트는 2줄까지 자연스럽게 확장
- metadata는 source + formatted relative date
- tag는 최대 2개 + `+N`, AX size에서는 별도 줄
- whole row opens detail; ellipsis 44pt contextual action
- swipe: Favorite / Move / Trash, destructive action은 Undo

## 6. Manual Add

### 권장 진입

Add 탭 클릭 → 작은 type chooser가 아니라 바로 form에 type segmented/chips를 제공한다.

```text
Add Clip
[Link] [Text] [Photo] [Memo]

URL *
https://…
[Paste]

Title (optional)
…
Folder                         >
Tags                           >
Note
…

[Save Clip]
```

### 동작

- clipboard paste는 사용자가 버튼을 눌렀을 때만 수행한다.
- URL 입력은 scheme normalization과 domain preview.
- Photo는 PhotosPicker; byte/pixel 정책을 저장 전 표시.
- duplicate 발견 시:
  - 이미 저장됨: date/folder 표시
  - `기존 항목 열기`, `메모 합치기`, `별도로 저장`
- save 버튼은 validation 중/commit 중 상태를 명확히 표시하고 중복 탭을 막는다.

## 7. Clip Detail

### 권장 구조

```text
Navigation title / Back
[Adaptive preview]
Title
source.domain · captured date
[Open Link]

Organization
Folder                         >
Tags             [tag] [tag] [+]
Favorite                       toggle

Note
[Multiline editor, grows]

Actions
[Share] [Move] [Export]
[Move to Trash]
```

### 개선

- 한 viewport에 모두 넣기 위해 media/editor를 고정 축소하지 않는다.
- URL open 전 confirm mode에서는 실제 domain, punycode warning, full host를 표시한다.
- missing/corrupt image는 placeholder와 `원본 찾기/진단`을 제공한다.
- 편집은 자동 저장이든 명시 Save든 한 방식을 선택하고 commit 상태를 일관되게 보여준다.
- header/section에 accessibility heading trait를 적용한다.

## 8. Search

### 구조

```text
Search
[ query                          × ]
Scope: [All] [Link] [Image] [Text] [Favorite]
[Folder ▾] [Tags ▾] [Date ▾]

Recent searches                 [Clear]
Results · 18
...
```

### 검색 계약

- Unicode normalization
- title/source/domain/url/memo/tag
- exact phrase와 token AND/OR 정책 문서화
- empty query에는 recent/favorites/recently opened 중 하나를 표시
- no result에는 filter reset, spelling suggestion, manual Add 제공
- 검색어는 외부 서버로 보내지 않는다.

## 9. Library / Folders

Folders tab을 “Library”로 확장하는 안을 권장한다.

```text
Library
Smart
  Inbox                        24
  Unsorted                      4
  Favorites                     6
  Images                       10
  Trash                         2
Folders
  Work                          7
  Inspiration                   9
  Travel                        3
[New Folder]
```

### Folder actions

- rename
- merge into…
- delete with destination choice
- default tag edit
- item count와 size 선택 표시

폴더 삭제 시 포함 clip을 함께 영구 삭제하지 않는다.

## 10. Sort Later

### 목표

분류를 “업무”가 아니라 짧은 triage로 만든다.

```text
Sort Later · 4 remaining
[preview]
Title/source

Recent destinations
[Work] [Ideas] [Travel] [More]
Tags
[reference] [read] [+]

[Skip]            [Save & Next]
```

- swipe right = recent folder, left = skip처럼 숨은 제스처만 의존하지 않는다.
- 명시 버튼과 keyboard shortcut(iPad/Mac)을 병행한다.
- batch mode는 1.1에서 추가.
- 완료 상태: “모두 정리했습니다” + Inbox CTA.

## 11. Settings

### 정보 구조

```text
Capture
  Share save mode
  Default folder
  Image quality / original policy
  Share Extension guide

Privacy & Lock
  App lock
  Lock timing
  Hide app switcher preview
  Privacy policy

Storage
  482 MB used
  Images 450 MB · Queue 12 MB
  Retention / Cleanup

Backup & Restore
  Export archive
  Import archive
  Recovery center

Appearance
  Theme / Language

Help
  Support / Version / Licenses

Danger Zone
  Delete all data
```

### 설정 저장

앱과 extension 사이 config write가 실패하면 setting을 성공처럼 바꾸지 않는다. `확장 설정을 동기화하지 못했습니다 [다시 시도]`를 보여준다.

## 12. App Lock

```text
[opaque branded background]
lock icon
Clip Inbox is Locked
“Face ID, Touch ID 또는 기기 암호로 열기”
[Unlock]
error/retry text
```

- sensitive background screenshot 금지
- capability unavailable를 자동 unlock으로 처리하지 않음
- support/recovery는 콘텐츠를 노출하지 않는 범위에서만 제공
- auth 시작은 사용자의 명시적 CTA 또는 screen appear 자동 시작 중 일관된 정책

## 13. Share Extension — Quick

### 상태

```text
Saving…
[progress]

Saved to Inbox ✓
[Change to review next time]

Couldn’t Save
Reason in user language
[Try Again] [Cancel]
```

- enqueue commit 전 성공 표시 금지
- 2초 고정 대기 대신 짧은 accessible confirmation 또는 즉시 host return
- VoiceOver announcement 후 completion이 announcement를 잘라내지 않는지 검증
- too-large image는 선택적 optimize 또는 cancel

## 14. Share Extension — Review

```text
Clip Inbox                     [Cancel]
[small preview]
Title / content summary
Folder                         >
Tags                           >
Note
...
[Save]
```

- small screen/keyboard에서 form 전체 scroll
- native controls와 clear focus order
- provider load와 UI edit를 분리해 loading skeleton 표시
- save 실패 후 입력을 유지
- mode setting 링크는 main app으로 자동 전환하지 말고, host limitation을 설명

## 15. Full-screen Image

- `UIScrollView` 기반 zoom/pan 또는 동등한 안정적 구현
- single tap toolbar hide/show
- double tap 1×/fit/2× 순환
- reset, share/export, metadata 선택
- close target 44pt
- image title과 zoom percentage를 accessibility value로 제공
- Reduce Motion에서 zoom transition 단순화

## 16. Trash

```text
Trash
“Items are permanently deleted after 30 days”
[Select]

clip row · 12 days left
[Restore] [Delete Now]

[Empty Trash]
```

- retention 기간은 설정 가능
- image asset는 retention 동안 유지
- Empty Trash는 개수/용량과 되돌릴 수 없음을 명시
- 일부 asset delete 실패 시 clip metadata를 조용히 잃지 않고 cleanup pending 상태 유지

## 17. Recovery Center

```text
Recovery Center
Library
  Current snapshot       Healthy
  Previous backup        Jul 10 · 23 clips
  Quarantined file       1         [Export]

Share Queue
  Pending                2
  Failed                 1         [Review]
  Orphan images          3 · 18 MB [Clean Up]

[Run Check]
```

일반 사용자에게 기술 파일명을 과도하게 노출하지 않되, 지원 시 redacted diagnostics를 내보낼 수 있게 한다.

## 18. Storage

- total app data
- clips metadata
- original images
- optimized thumbnails/cache
- pending queue
- trash
- orphan/recoverable files

cleanup은 즉시 실행 전에 예상 절감 용량과 영향을 preview한다. cache는 안전하게 지울 수 있음을 구분하고, 원본·trash 삭제는 명시적 확인을 요구한다.

## 19. Import/Export

### Export

```text
Create Backup
23 clips · 8 images · 420 MB
[x] Include original images
[x] Include settings/tags
[ ] Encrypt with password
“This file may contain private content.”
[Create Backup]
```

### Import dry run

```text
Backup from Jul 10
Schema 3 · 23 clips · 8 images
Duplicates 4 · New 19
[Merge] [Replace Existing]
[Import]
```

- unsupported version은 update 안내
- import 중 앱 종료 후에도 기존 library가 온전해야 함
- 실패 시 staged files 정리

## 20. 화면별 QA matrix

모든 핵심 화면에서 다음 조합을 최소 검증한다.

- iPhone compact / iPad regular / split width
- light / dark / increase contrast
- Korean / English / Japanese / pseudo-long
- default / XXXL / AX5 Dynamic Type
- VoiceOver on
- empty / one item / many items / error
- online/offline은 외부 link preview 기능에만 영향
- lock on/off

## 21. 최종 UI 명세 판정

현재 브랜드와 기본 내비게이션은 유지한다. 가장 큰 UI 개선은 색·그림자를 다시 디자인하는 일이 아니라, **Add·Onboarding·Recovery·Trash·Storage라는 누락 화면을 만들고 모든 기존 화면을 적응형·접근 가능하게 바꾸는 것**이다.
