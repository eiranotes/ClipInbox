# Release & Deployment Readiness Audit

## 1. 현재 판정

| 대상 | 준비도 | 판정 |
|---|---:|---|
| 로컬 개발/디자인 프로토타입 | 80% | 사용 가능 |
| Simulator 내부 QA | 65% | 저장소 자체 증거는 있으나 독립 재실행 필요 |
| 제한 TestFlight | 45% | P0 데이터·잠금·extension 문제 해결 전 부적합 |
| 외부 TestFlight | 35% | 실기기·정책 URL·CI·migration gate 필요 |
| App Store 공개 출시 | 30% | 현재 부적합 |
| Android/웹 배포 | 0–10% | 프로덕션 대상 아님 |

## 2. iOS 프로젝트 설정

### 확인된 값

| 설정 | 값 | 평가 |
|---|---|---|
| Project generator | XcodeGen, minimum 2.45.4 | 재현성 장점 |
| Xcode version declaration | 26.5 | CI image·실개발 환경과 일치 검증 필요 |
| Project format | xcode16_3 | 생성/열기 호환성 검증 |
| Swift | 5.10 | 안정적 |
| Deployment target | iOS 17.0 | 명확하나 구형 기기 제외 |
| Marketing version | 0.3.0 | pre-release 적절 |
| Build number | 1 | 배포마다 자동 증가 필요 |
| App bundle | `app.clipinbox.ClipInbox` | release ownership 확인 |
| Extension bundle | `app.clipinbox.ClipInbox.Share` | embed/sign 검증 |
| App Group | `group.app.clipinbox.ClipInbox` | distribution profile 포함 필요 |
| Device family | iPhone/iPad | UI matrix 필요 |
| Development Team | project.yml에 ID 하드코딩 | 환경 분리 필요 |
| Extension API only | YES | 적절 |

### 개선

- `Config/Base.xcconfig`, `Debug.xcconfig`, `Release.xcconfig`, `Local.xcconfig` 도입
- 개발팀·서명 스타일·정책 URL·feature flags를 소스와 분리
- build number를 CI run 또는 App Store Connect API 기준으로 증가
- Release에서 assert/debug sample/verbose log 제거
- bundle ID와 App Group을 smoke script로 비교
- XcodeGen 생성 후 git diff가 0인지 CI에서 확인

## 3. 서명·App Group·Share Extension

저장소 문서는 simulator에서 extension embed와 App Group import를 확인했다고 기록한다. 그러나 배포 서명은 다른 profile/entitlement 경로를 사용하므로 별도 gate가 필요하다.

### signed archive 검증

1. Distribution certificate/profile로 Release archive 생성
2. archive 내 `Products/Applications/Clip Inbox.app/PlugIns/ClipInboxShare.appex` 존재 확인
3. app/appex `codesign -d --entitlements :-` 비교
4. App Group identifier 양쪽 일치
5. bundle ID, application-identifier, team identifier 일치
6. `APPLICATION_EXTENSION_API_ONLY=YES` 위반 없음
7. `xcrun altool/notary`가 아니라 현재 Xcode Validate App/Transporter 경로로 preflight
8. TestFlight 설치 후 Safari/Photos/선택 텍스트 공유
9. 앱 업데이트 전후 pending queue와 주 snapshot migration 확인

`[검증 필요]` 실제 release Apple Developer team의 App ID/App Group/provisioning 상태는 저장소만으로 알 수 없다.

## 4. Privacy Manifest와 Required Reason API

- main app과 extension에 privacy manifest가 존재한다.
- UserDefaults 등 Required Reason API 선언은 실제 바이너리와 일치해야 한다.
- 최종 판정은 source file 존재가 아니라 **archive privacy report와 App Store upload validation**이다.
- SDK를 추가하지 않더라도 Xcode/Apple 정책이 변경될 수 있으므로 제출 직전 최신 요구를 다시 확인한다.

### Gate

- [ ] Release archive privacy report 생성
- [ ] main app/appex의 accessed API category와 reason code 일치
- [ ] 누락/중복 manifest warning 0
- [ ] App Privacy answers와 runtime network behavior 일치
- [ ] crash/analytics SDK가 없거나 정확히 공개됨

## 5. App Store Review 위험

| 위험 | 근거 | 심사 영향 | 해결 |
|---|---|---|---|
| 실제 Add가 demo 생성 | 핵심 CTA/기능 불일치 | 최소 기능성·오해 메타데이터 | 실제 capture 구현, 샘플 제거 |
| placeholder support/privacy | docs의 deferred 항목 | 제출 불가/거절 | 소유 HTTPS URL·monitoring email |
| “Face ID lock” 과장 | policy는 passcode fallback, fail-open 가능 | 기능/보안 설명 부정확 | 정확한 copy와 fail-closed |
| extension만 있고 도움 부족 | 사용자가 활성화 방법을 모름 | utility 부족·reviewer 재현 실패 | 앱 내 onboarding/help, review notes |
| screenshot와 현 UI 불일치 | UI가 여러 차례 변경됨 | 부정확한 metadata | release build에서 직접 캡처 |
| sample content | 실제 사용자 데이터처럼 보임 | 완성도·정확성 문제 | 선택형 demo 또는 명시 badge |
| 데이터 손실 경로 | 저장 failure/corruption | 품질·사용자 피해 | P0 data fixes |
| privacy answer 불일치 | local-only 주장 | policy violation | release network/SDK audit |
| 설명 없는 평문 export | 민감 데이터 앱 | privacy trust | warning/policy/암호 옵션 |
| iPad target이나 phone UI | iPad 지원 선언 | 품질 저하 | split-view/landscape QA 또는 family 범위 재검토 |

Apple은 앱 내부와 metadata에 개인정보 처리방침 링크, 정확한 설명·스크린샷, 완성된 URL, 실제 기기 테스트를 요구한다. extension을 제공하는 containing app은 사용자가 extension을 이해·관리할 수 있는 도움/설정 기능을 갖추는 것이 안전하다.

## 6. App Store 제출 자료

### 필수 메타데이터

- 앱 이름: 최종 상표/중복 확인
- subtitle: “Private Share-to-Inbox” 성격을 명확히
- description: URL/text/image, local-only, no account, backup 범위, lock 범위
- keywords: clipboard 오해를 피하면서 capture/inbox/bookmark/reference 중심
- category: Productivity 우선 검토
- age rating: 외부 웹 콘텐츠를 저장/열 수 있다는 점 반영
- support URL
- privacy policy URL
- marketing URL 선택
- copyright/rights holder
- app review contact
- review notes와 extension 재현 절차
- export compliance/암호화 답변
- App Privacy questionnaire
- 가격/지역

### 스크린샷 계획

1. “어디서든 공유해 한 곳에” — Share Sheet + Inbox
2. “분류하지 말고 먼저 저장” — Unsorted/Quick save
3. “폴더·태그·검색” — 실제 검색 결과
4. “이미지·링크·메모” — 다양한 실제 콘텐츠
5. “기본 로컬 저장” — privacy/settings
6. “삭제 복구와 백업” — Trash/export
7. iPad가 지원되면 sidebar/detail 실제 화면

데모 데이터는 상표·저작권·개인정보 문제가 없는 자체 제작 콘텐츠만 사용한다.

## 7. CI/CD 권장안

### Pull Request pipeline

```text
checkout
→ install pinned XcodeGen
→ xcodegen generate
→ fail if generated project diff
→ plist/json/xcprivacy validation
→ secret/license scan
→ Debug build (iPhone simulator)
→ unit + migration + failure-injection tests
→ UI/accessibility smoke
→ result bundle/artifact upload
```

### Main pipeline

- 위 PR gate
- Release simulator build
- 3개 언어 × light/dark snapshot
- performance smoke with 1k/5k fixtures
- changelog/version consistency

### Release candidate pipeline

- manual protected environment 승인
- signing certificate/profile/keychain 주입
- archive/export
- entitlements/appex/privacy report 검사
- TestFlight upload
- release notes 생성
- artifact hash/SBOM/archive retention
- Git tag는 외부 QA 승인 후 생성

### Branch protection

- main direct push 금지
- required review 1명 이상
- required checks
- secret scanning/dependabot 또는 동등한 자동 점검
- signed commits는 팀 정책에 따라 선택
- release tag 보호

## 8. 운영 모니터링

local-only 제품은 데이터 원문을 수집하지 않으면서 운영 가능해야 한다.

### 최소 구성

- MetricKit: crash/hang/memory 지표
- OSLog: category + redacted error code
- 선택적 crash reporter를 도입한다면 URL/메모/검색어/파일 경로 scrub
- 사용자가 직접 생성하는 진단 리포트: 버전, OS, queue counts, storage buckets, error codes만 포함
- 공개 support page: known issues, backup/recovery, Share Extension enable guide
- incident runbook: data corruption, signing/App Group, review rejection, privacy disclosure

### 권장 SLO

- crash-free sessions 99.8%+
- Share URL/text durable enqueue success 99.9%+
- supported image save deterministic completion 99.5%+
- data corruption recovery success 100% for previous-backup scenario
- false-success 0

원격 analytics가 없다면 SLO는 TestFlight opt-in diagnostics와 QA fault injection을 조합해 측정한다.

## 9. 문서·개발자 경험

### 현재 좋은 점

- source-of-truth와 XcodeGen workflow가 `AGENTS.md`에 명시됨
- task/decision/changelog/release 문서가 존재
- simulator 검증 명령과 evidence가 기록됨

### 부족한 문서

- 루트 README
- LICENSE
- SECURITY.md
- CONTRIBUTING.md
- `.github` issue/PR templates
- architecture/data schema/backup contract
- corruption recovery runbook
- release signing guide without personal path/device ID
- TestFlight/App Store rollback guide
- third-party asset notices

`AGENTS.md`의 예시 build 명령에는 특정 사용자의 로컬 path와 simulator UUID가 포함돼 있다. 일반 명령과 개인 override를 분리해야 한다.

## 10. Android·웹·데스크톱 배포

### Android

- 코드가 없으므로 현재 제출 대상이 아니다.
- iOS 1.0 전에 Android를 시작하지 않는다.
- 향후에는 Android의 clipboard/background 접근 정책을 별도로 설계하고, “조용한 수집”보다 share target 중심으로 제품 철학을 유지한다.

### 웹

- 현재 루트 웹은 정적 프로토타입이다.
- production web app으로 배포하려면 저장·보안·PWA·clipboard permission·sync·auth·privacy를 새로 설계해야 한다.
- 단순 GitHub Pages demo로 공개할 경우 샘플 데이터·모든 interaction이 실제 제품처럼 오해되지 않도록 “prototype” 표시가 필요하다.

### macOS

- 경쟁력 측면에서 Android보다 natural extension일 수 있다.
- iOS PMF 이후 Mac companion을 별도 target으로 검토하고, App Group/iCloud/backup 설계를 먼저 안정화한다.

## 11. 법적·정책·라이선스

- 루트 LICENSE 부재: 상업적·오픈소스 의도를 확정해야 한다.
- Pretendard와 이미지/아이콘 자산의 license notice·배포 권리를 기록한다.
- 개인정보 처리방침에 저장 위치, OS backup 가능성, export, 삭제, 연락처, 관할, policy 변경을 포함한다.
- 이용약관은 유료화·보증 제한·지원 범위를 명확히 하는 데 유용하다.
- “법률 검토 필요”가 개발 작업을 대체하지 않는다. 실제 URL, delete/export behavior, App Privacy answers를 코드와 일치시킨다.

## 12. Go/No-Go 기준

### No-Go

- P0 데이터 신뢰 이슈 1개 이상 열림
- 대형 이미지 extension crash
- 잠금 우회/fail-open
- 실제 Add 미구현
- privacy/support placeholder
- signed archive/appex validation 실패
- privacy manifest 또는 App Privacy 불일치

### Go to limited TestFlight

- P0 0개
- migration/failure-injection tests 통과
- signed physical device core flows 통과
- recovery/export 검증
- known P1을 release notes와 내부 risk register에 기록

### Go to App Store

- P0 0개, High P1 중 사용자 데이터·privacy·accessibility 관련 0개
- review assets/policy URLs 완성
- external TestFlight에서 blocker 0
- rollback archive와 support runbook 준비
