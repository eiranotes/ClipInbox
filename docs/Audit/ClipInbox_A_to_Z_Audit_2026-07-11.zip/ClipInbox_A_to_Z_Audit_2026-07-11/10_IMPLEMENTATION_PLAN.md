# ClipInbox Implementation Plan

## 1. 실행 원칙

- 기능 추가 전에 데이터 신뢰 경계를 고친다.
- P0는 개별 patch가 아니라 테스트·오류 UI·문서까지 하나의 작업 단위로 닫는다.
- 기존 SwiftUI 디자인과 Share Extension을 보존하고 점진적으로 분리한다.
- 매주 끝에 실행 가능한 build를 유지한다.
- 한 번에 저장소를 SwiftData로 전환하지 않는다. 먼저 transaction/recovery interface를 만든 뒤 필요하면 backend를 교체한다.

## 2. 작업 의존성

```text
ARCH-005 Repository abstraction
 ├─ DATA-001/012 Recovery
 ├─ DATA-002 Transaction rollback
 ├─ DATA-003 Migration
 ├─ TEST-002/003 Failure fixtures
 └─ ARCH-006 StorageActor

REL-001 Image pipeline
 ├─ REL-002 Timeout/cancel
 ├─ REL-005 Queue quota
 ├─ ARCH-008 Asset transaction
 └─ TEST-004 Extension E2E

SEC-001 Lock state machine
 ├─ SEC-002 Privacy shield
 └─ TEST physical-device lock matrix

UI semantic typography
 ├─ adaptive filter/grid
 ├─ screen reflow
 └─ accessibility snapshot/VoiceOver gate

Release URLs/signing
 ├─ privacy policy final
 ├─ App Privacy answers
 ├─ signed archive validation
 └─ TestFlight/App Store submission
```

## 3. Week 1 — 데이터 안전 기반

### 목표

손상·저장 실패가 사용자에게 조용히 보이지 않도록 만들고, 이후 기능이 같은 계약을 사용하게 한다.

### 작업

#### 1. Repository와 오류 모델

- `ClipRepository` protocol
- `FileClipRepository` initial implementation
- `StoreError`: notFound, corrupt, unsupportedVersion, noSpace, permission, encoding, validation, assetFailure
- `Clock`, `IDGenerator`, `FileSystem` 최소 주입점
- in-memory/failing fake repository

**완료 기준**

- AppStore가 직접 `Data.write`를 호출하지 않는다.
- 모든 저장 작업이 typed `Result`/throwing async API를 사용한다.

#### 2. Snapshot bootstrap/recovery

- 파일 없음과 decode failure 분리
- draft validation
- current/previous rotation
- corrupt quarantine
- schema version allowlist
- recovery state UI skeleton

**완료 기준**

- truncated current + valid previous에서 자동/선택 복구
- previous도 손상된 경우 기존 파일 보존, 샘플로 덮어쓰지 않음
- 손상 fixture tests 통과

#### 3. Transaction mutation

- bookmark, move, memo, update, tags, create folder, preference, delete, delete-all을 동일 transaction contract로 이전
- commit 성공 후에만 toast
- 실패 시 UI rollback과 actionable banner

**완료 기준**

- disk-full fake에서 모든 mutation의 메모리·디스크 상태가 동일
- false-success test 0건

#### 4. production sample 제거

- 첫 실행은 empty state
- demo 데이터는 Preview/test fixture 또는 명시적 “샘플 둘러보기” opt-in으로 이동

### Week 1 산출물

- PR 1: repository/error/fakes
- PR 2: recovery/migration skeleton
- PR 3: transaction mutations
- PR 4: empty state/sample separation
- 업데이트된 data architecture 문서와 migration fixture

## 4. Week 2 — Share Extension·잠금·실제 Add

### 목표

가장 빈번한 캡처 입력과 privacy barrier를 production contract로 만든다.

### 작업

#### 1. 이미지 입력 파이프라인

- `loadFileRepresentation` 우선
- 파일 URL coordinated copy
- header 기반 bytes/pixels/type inspection
- configurable byte/pixel cap
- preview downsample
- original/optimized storage 선택 정책
- unsupported/too-large error UI

#### 2. Provider deadline/cancellation

- URL/text/image provider 작업에 deadline
- user cancel과 host cancel을 구분
- task cancellation handler
- fixed 2-second wait 축소/제거

#### 3. Queue durability

- `createdAt` 정렬
- idempotency UUID
- corrupt quarantine
- max count/bytes/TTL
- cleanup/reconciliation result
- config save throws/version/checksum

#### 4. App Lock state machine

- capability 확인 전 setting commit 금지
- auth error/cancel에서 fail-closed
- `scenePhase == .inactive`에서 privacy cover
- foreground unlock race test
- copy를 Face ID 전용처럼 과장하지 않음

#### 5. Manual Add

- URL, text/memo, PhotosPicker image
- title/source optional
- duplicate preview hook
- 동일 repository transaction 사용
- demo `saveNewClip` 제거

### Week 2 산출물

- 대형 이미지/timeout provider tests
- signed-build 전 단계 extension harness
- lock lifecycle tests
- 실제 Add UI test

## 5. Weeks 3–4 — UX·접근성·복구 기능

### 목표

외부 사용자가 설명 없이도 저장하고, 실수를 복구하고, 큰 글자/VoiceOver로 핵심 흐름을 완료하게 한다.

### 작업 묶음 A — 온보딩과 상태 화면

- first-run Share-to-Inbox 설명
- Share Extension Favorites guide
- Quick/Review mode preview
- 첫 capture exercise
- empty/no-results/loading/degraded/recovery common states
- Settings에 “공유 확장 사용법 다시 보기”

### 작업 묶음 B — 휴지통과 Undo

- `DeletionState`/`deletedAt`
- Undo banner
- Trash smart list
- restore/permanent delete/empty trash
- image file retention and cleanup
- delete-all export suggestion + typed confirmation

### 작업 묶음 C — 접근성 시스템

- semantic relative typography
- 44pt hit area
- 5-column grid를 adaptive chips/filter sheet로 교체
- fixed height 제거/reflow
- VoiceOver labels/values/traits/announcements
- Reduce Motion
- contrast audit
- 3개 언어 + AX5 snapshot matrix

### 작업 묶음 D — Storage/Privacy Center

- clip/image/queue bytes
- largest items
- retention setting
- original vs optimized image policy
- export/delete/backup scope 설명
- redacted diagnostics export

### Weeks 3–4 산출물

- 접근성 audit blocker 0
- 휴지통 roundtrip tests
- storage cleanup preview
- onboarding completion analytics 없이도 로컬 QA할 수 있는 test hooks

## 6. Month 2 — 공개 출시 품질

### 6.1 검색과 정리

- normalized token search
- folder/tag/type/date filters
- favorites/recent/images smart views
- duplicate URL/text detection
- batch select/move/tag/delete
- Sort Later swipe triage

### 6.2 저장소 규모 판단

아래 benchmark 후 backend를 결정한다.

| Fixture | 측정 | 통과 기준 |
|---:|---|---|
| 100 clips | launch/save/search | 체감 지연 없음 |
| 1,000 | save p95/search p95 | save <150ms, search <100ms 목표 |
| 5,000 | launch/list/search | launch <2.5s, typing smooth |
| 10,000 | stress | memory 안정, UX 정책 결정 |
| 1GB images | scroll/storage | downsample, no OOM |

- snapshot이 기준을 충족하면 1.0까지 유지 가능
- 실패하면 `SQLiteClipRepository`로 교체
- export schema는 backend와 독립 유지

### 6.3 CI/Release automation

- macOS CI build/test
- migration/failure/accessibility suites
- XcodeGen drift
- secret/license/privacy manifest checks
- protected release archive job
- entitlements/appex/privacy report validator
- TestFlight upload/release notes

### 6.4 App Store 준비

- 소유 HTTPS privacy/support 페이지
- support email 운영
- App Privacy answers
- 실제 release screenshot
- review notes와 Share Extension guide
- physical iPhone/iPad matrix
- TestFlight external feedback/known issues

## 7. 2–4개월 후 제품 확장

### 우선순위 후보

1. Core Spotlight
2. App Intents/Shortcuts
3. on-device OCR
4. URL metadata/cache policy
5. Mac companion feasibility
6. optional CloudKit sync

AI 요약·의미 검색은 데이터 안전과 기본 검색 품질이 완성된 뒤 실험한다. 기본값은 on-device이며 server AI는 개별 항목 단위 opt-in과 명확한 전송 preview가 필요하다.

## 8. 병렬 처리 가능 작업

| Track | 독립 가능 범위 | 의존성 |
|---|---|---|
| Data | repository/recovery/migration | 최우선, 대부분의 기능 선행 |
| Extension | image pipeline/provider timeout | repository와 queue contract 합의 필요 |
| Lock/Privacy | state machine/shield | UI root lifecycle 접근 필요 |
| Design/A11y | typography/adaptive components | transaction과 병렬 가능 |
| Product/Docs | privacy/support pages, onboarding copy | 실제 동작 확정 후 final |
| CI | fast checks/unit workflow | project가 안정되면 즉시 시작 가능 |
| Store assets | screenshot plan/ASO | release UI freeze 후 final capture |

1인 개발이라면 Data → Extension/Lock → Add → UX/A11y → Release 순서를 지킨다. 여러 명이면 Data contract를 먼저 합의한 뒤 Extension, UX, Release track을 병렬화한다.

## 9. 티켓 템플릿

```markdown
### [ID] 제목
- 사용자 문제:
- 현재 증거/관련 파일:
- 범위:
- 비범위:
- 실패 계약:
- 개인정보/접근성 영향:
- 구현 메모:
- 자동 테스트:
- 실기기/수동 테스트:
- migration/rollback:
- 완료 증거:
```

## 10. Definition of Done

모든 기능/수정은 다음 중 해당 항목을 충족해야 한다.

- 코드 리뷰 완료
- 성공과 실패 테스트
- 기존 사용자 데이터 migration 또는 “없음” 명시
- 오류 UI와 접근 가능한 announcement
- 3개 언어 문구
- light/dark/AX5 화면 검증
- 개인정보 영향 검토
- 관련 README/runbook/changelog
- release configuration 검증

P0는 unit test만으로 닫지 않는다. signed build 또는 실제 파일 system fault를 포함한 증거를 남긴다.

## 11. 리스크와 완화

| 리스크 | 가능성 | 영향 | 완화 |
|---|---:|---:|---|
| 데이터 계층 리팩터링이 UI 회귀 유발 | 중 | 높음 | characterization tests, 작은 PR, feature branch migration |
| 이미지 최적화가 원본 보존 약속과 충돌 | 중 | 높음 | 정책 선택·명시, 원본/optimized 별도 metadata |
| 접근성 변경으로 현재 pixel design 변화 | 높음 | 중 | semantic hierarchy를 보존하고 fixed geometry만 제거 |
| SQLite 이전 과투자 | 중 | 중 | benchmark-based decision gate |
| App Review 정책/manifest 변경 | 중 | 높음 | 제출 직전 공식 문서 재확인, archive preflight |
| 혼자 개발해 release 운영 누락 | 높음 | 높음 | checklist evidence와 CI 자동화 |

## 12. 성공 지표

- false-success: 0
- recoverable corruption에서 사용자 데이터 복구율: 100%
- 첫 설치→첫 capture 성공률: QA cohort 90%+
- core capture completion: 99.9% target
- AX5/VoiceOver core-flow blocker: 0
- signed release matrix blocker: 0
- 외부 TestFlight 데이터 손실 report: 0
- 7일 내 saved clip 재검색/열기 성공: 정성 테스트에서 90%+
