# Performance, Reliability & Test Audit

## 결론

현재 테스트는 상태 변경과 일부 설정·현지화·이미지 보존을 확인하는 단위 테스트 한 파일에 집중돼 있다. 가장 큰 공백은 **손상·쓰기 실패·대용량 이미지·App Group 배포 서명·앱 잠금 실패·접근성·Release archive**다. 테스트 수를 늘리는 것보다 P0 사용자 약속을 계약으로 고정하는 것이 우선이다.

## 현재 테스트 상태

| 범주 | 현재 상태 | 평가 |
|---|---|---|
| 단위 테스트 | `ios/ClipInboxTests/AppStoreTests.swift` 한 파일, 저장소 기준 약 14개 테스트 메서드 | 기본 mutation·설정 회귀에는 유효하나 실패 경로가 거의 없음 |
| 통합 테스트 | AppStore와 실제 임시 파일을 사용하는 일부 테스트 | App Group queue·migration·asset transaction 범위 부족 |
| UI/E2E | 자동 UI 테스트 target을 확인하지 못함 | 핵심 Add/Share/Lock 흐름을 보호하지 못함 |
| Share Extension | 저장소의 수동 simulator 증거는 있음 | 대형 이미지·host 차이·timeout·signed build는 미검증 |
| 접근성 | 자동/수동 증거 부족 | 출시 전 별도 gate 필요 |
| 성능 | benchmark·budget 없음 | 현재 전체 JSON 구조의 안전 한계를 모름 |
| CI | `.github/workflows`를 확인하지 못함 | PR 품질 게이트 부재 |

## 성능 병목 후보

| 영역 | 현재 구현 | 사용자 영향 | 측정 방법 | 권장 개선 | 우선순위 |
|---|---|---|---|---|---|
| 영속화 | 매 mutation마다 전체 pretty JSON atomic write | 데이터 증가 시 저장 지연·쓰기 실패 | 100/1k/5k/10k clip save p50/p95 | StorageActor + DB/journal + coalescing | P1 |
| 검색 | 배열 전체 substring scan | 5k+에서 typing lag | signpost query latency | normalized index/SQLite FTS | P2 |
| 썸네일 | 원본 파일 기반 UIImage decode 가능성 | scroll OOM/jank | XCTMemoryMetric, Instruments | ImageIO target-size downsample | P1 |
| Share Extension | 원본 Data/UIImage 전체 적재 | 대형 사진에서 extension 종료 | 12/24/48MP, ProRAW matrix | file copy, byte/pixel cap, preview downsample | P0 |
| 이미지 cache | 비용 제한 증거 없음 | 장시간 사용 메모리 증가 | cache hit/memory warning | totalCostLimit·purge | P1 |
| App Group queue | unbounded files | 저장 공간 누적·import 지연 | 10/100/1k pending items | quota·TTL·quarantine | P1 |

## 권장 성능 예산

- Cold launch to interactive: 보통 기기 p95 1.5초 이하, 5,000 clip fixture 2.5초 이하.
- 검색: 5,000개에서 입력 후 첫 결과 p95 100ms 이하.
- Inbox scroll: 대표 기기에서 55fps 이상, decoded image memory가 화면 수에 비례해 제한됨.
- 단일 공유: URL/text p95 1초 내 durable enqueue; confirmation 대기 제외.
- 이미지 공유: 25MB/48MP 입력에서도 crash 없이 제한·최적화·오류 중 하나로 결정적 종료.
- 주 저장 실패율: release candidate fault injection에서 false-success 0건.

## 필수 테스트 매트릭스

| 기능 | 단위 | 통합 | UI/E2E | 실기기/배포 | 현재 공백 |
|---|---|---|---|---|---|
| snapshot load/save | 필수 | 필수 | 선택 | 파일 보호 | corruption·rollback |
| import/export | 필수 | 필수 | 필수 | 공유 대상 | version·object budget·평문 경고 |
| Share URL/text/image | provider fakes | App Group | host flow | Safari/Photos | timeout·대형 이미지·signing |
| 앱 잠금 | state machine | lifecycle | UI | Face ID/passcode | fail-open·snapshot |
| 검색/필터 | 필수 | DB/index | UI | 성능 | 5k+·Unicode |
| 삭제/복원 | 필수 | asset transaction | UI | 낮은 디스크 | Undo·trash·rollback |
| 현지화/접근성 | formatter | — | snapshot/audit | VoiceOver | AX5·긴 번역·contrast |
| release | — | archive script | smoke | signed install | privacy report·appex embed |

## 상세 테스트 케이스

| ID | 테스트 이름 | 목적 | 사전 조건 | 입력 | 수행 절차 | 예상 결과 | 실패 영향 | 자동화 |
|---|---|---|---|---|---|---|---|---|
| T-001 | 정상 첫 실행 | 저장소가 없을 때 빈 상태가 생성되는지 | 앱 데이터 없음 | 앱 실행 | 저장 파일 없음 상태로 실행 | 샘플이 아닌 안내형 빈 상태; 정상 저장소 생성 | High | 자동화 |
| T-002 | 손상 JSON 복구 | truncated snapshot이 데이터 유실로 위장되지 않는지 | 정상 current와 .bak 준비 | current를 절반으로 자름 | 앱 재실행 | 손상 파일 격리, .bak 복구 안내, 샘플로 대체하지 않음 | Critical | 자동화 |
| T-003 | 미지원 미래 버전 | version=999 import 차단 | 미래 버전 fixture | Import 실행 | 파일 선택 후 확인 | unsupported version 오류; 기존 데이터 불변 | Critical | 자동화 |
| T-004 | v1→현재 migration | 기존 데이터 보존 | v1 fixture | 앱 업그레이드/Import | migration 수행 | 클립 수·폴더·설정 보존, current version 저장 | Critical | 자동화 |
| T-005 | 저장 실패 rollback | mutation false-success 방지 | 쓰기 실패 fake repository | 즐겨찾기 토글 | 토글 후 저장 실패 유도 | UI 원상복구, 오류 배너, 성공 토스트 없음 | Critical | 자동화 |
| T-006 | disk full 삭제 | 삭제 중 영속화 실패 | ENOSPC fake | 클립 삭제 | disk full 유도 | 클립·이미지 모두 유지, 재시도 제시 | Critical | 자동화 |
| T-007 | delete all 실패 | 전체 삭제 원자성 | 여러 클립/이미지 | 모두 삭제 | persist 실패 유도 | 원 데이터 유지, UserDefaults도 롤백 | Critical | 자동화 |
| T-008 | queue 중복 import | 삭제 실패 후 idempotency | 동일 UUID queue item | 앱 두 번 실행 | 첫 import 후 remove 실패 | 클립은 한 번만 생성, cleanup 재시도 | High | 자동화 |
| T-009 | 손상 queue quarantine | 손상 공유 payload 가시성 | 잘못된 JSON 파일 | 앱 실행 | queue import | 파일 quarantine, 진단/복구 수치 증가, 무한 재시도 없음 | High | 자동화 |
| T-010 | queue 시간 정렬 | 연속 공유 순서 보존 | createdAt이 다른 3개 UUID | 3회 공유 | 앱 import | createdAt 순서대로 inbox 삽입 | Medium | 자동화 |
| T-011 | Safari URL quick save | 기본 핵심 흐름 | Quick 모드/앱그룹 정상 | https URL | Safari 공유→ClipInbox | confirmation 후 앱에 URL 1건 저장 | Critical | 실기기/E2E |
| T-012 | 선택 텍스트 review save | 텍스트 캡처 | Review 모드 | 긴 다국어 텍스트 | 공유→폴더/태그/메모 편집→저장 | 정규화된 텍스트·선택값 저장 | High | 실기기/E2E |
| T-013 | Photos HEIC 원본 | 포맷·크기 보존 | HEIC 사진 | 12MP HEIC | Photos 공유 | 지원 정책대로 원본 또는 변환 자산 저장, 메타 정확 | High | 실기기/E2E |
| T-014 | 대형 48MP 사진 | extension memory 안정성 | 저메모리 기기 | 매우 큰 ProRAW/HEIC | Photos 공유 | 명시적 제한/최적화 안내, extension crash 없음 | Critical | 실기기/성능 |
| T-015 | provider timeout | 멈춘 NSItemProvider 처리 | timeout fake provider | 응답 없음 | 공유 실행 | 정해진 시간 후 취소/재시도 UI, host 복귀 가능 | High | 자동화+E2E |
| T-016 | 이미지 저장 중 실패 | asset/queue transaction | 이미지 write 성공, payload write 실패 | 이미지 공유 | enqueue 실패 유도 | 새 이미지 제거, 오류 표시, 고아 없음 | High | 자동화 |
| T-017 | 앱그룹 권한 실패 | 배포 signing 오류 처리 | 잘못된 entitlement build | URL 공유 | Share Extension 실행 | 구체 오류와 취소, 가짜 성공 없음 | Critical | signed E2E |
| T-018 | 잠금 capability 없음 | fail-closed 확인 | 생체/패스코드 사용 불가 | 앱 잠금 켜기 | 설정·재실행 | 설정 차단 또는 잠금 유지; 콘텐츠 노출 없음 | Critical | 실기기 |
| T-019 | Face ID 취소 | 인증 취소 시 상태 | 잠금 켜짐 | 사용자 취소 | 앱 foreground | 잠금 화면 유지, 우회 경로 없음 | Critical | 실기기 |
| T-020 | background snapshot | 앱 전환기 비공개 | 민감 이미지 상세 열림 | 홈 제스처 | 앱 전환기 보기 | opaque shield만 보임 | High | 실기기/UI |
| T-021 | 잠금 중 deep link/share import | lifecycle 경쟁 | 앱 잠금 상태+pending queue | 공유 후 앱 열기 | 인증 전후 관찰 | 인증 전 데이터 노출 없음; 인증 후 한 번 import | High | E2E |
| T-022 | 실제 Add URL | 데모 제거 검증 | 빈 앱 | 정상 URL | Add→URL→저장 | 사용자 입력 URL/제목이 저장, 샘플 값 없음 | Critical | UI 자동화 |
| T-023 | Add 잘못된 URL | 입력 검증 | Add 폼 | javascript: URL | 저장 | 차단과 수정 안내; 기존 데이터 불변 | High | 자동화 |
| T-024 | 중복 URL | canonical duplicate 처리 | 기존 URL 있음 | utm만 다른 동일 URL | 저장 | 중복 안내와 merge/별도 저장 선택 | Medium | 자동화 |
| T-025 | 삭제 Undo | 오삭제 복구 | 클립 1개 | 삭제 후 Undo | 행 삭제→배너 Undo | 원 위치·태그·이미지 복원 | High | UI 자동화 |
| T-026 | 휴지통 만료 | 보존 정책 | 삭제 30일 전 fixture | 시간 진행 | trash cleanup | 만료 항목만 제거, 사용자 설정 준수 | High | 자동화 |
| T-027 | JSON export plaintext warning | 민감정보 고지 | 민감 메모 포함 | Export | 설정→내보내기 | 평문 위험·파일 범위 설명 후 명시적 확인 | Medium | UI 자동화 |
| T-028 | 암호화 export roundtrip | 선택적 안전 백업 | 클립/이미지/설정 | 암호 사용 | export→새 설치 import | 모든 항목 복원, 오암호 시 기존 데이터 불변 | High | 자동화 |
| T-029 | Import 5MB 경계 | 파일 크기 정책 | 4.99/5.01MB fixtures | Import | 두 파일 각각 선택 | 경계 이하 처리, 초과는 즉시 명확히 거절 | Medium | 자동화 |
| T-030 | Import 객체 폭탄 | 개수 제한 | 5MB 내 수만 개 object | Import | 파일 선택 | budget 초과 거절, UI hang 없음 | High | 성능 자동화 |
| T-031 | 검색 5,000개 | typing latency | 5k fixture | 한국어/영어/URL query | 연속 입력 | p95 결과 100ms 목표, frame hitch 없음 | Medium | 성능 |
| T-032 | 목록 1GB 이미지 라이브러리 | thumbnail memory | 대형 이미지 1GB | 빠른 스크롤 | Inbox 스크롤 | downsampled thumbnail, memory 안정, OOM 없음 | High | 성능/실기기 |
| T-033 | Dynamic Type AX5 | 큰 글자 재배치 | AX5 설정 | 모든 화면 | Inbox→Detail→Settings→Share | 잘림/축소/겹침 없이 scroll/reflow | High | UI snapshot+수동 |
| T-034 | VoiceOver 핵심 흐름 | 의미론·순서 | VoiceOver 켬 | 저장/폴더 이동/삭제 | 핵심 플로우 수행 | 라벨·상태·힌트·confirmation이 논리 순서로 읽힘 | High | 접근성 수동 |
| T-035 | 터치 영역 감사 | 44pt 기준 | 일반 설정 | chips/ellipsis/close | hit-test 측정 | 모든 컨트롤 최소 44x44 | High | 자동/수동 |
| T-036 | 영어 긴 번역 | 레이아웃 탄력성 | English | 긴 folder/tag 이름 | 모든 화면 탐색 | 중요 텍스트 잘림 없음; grid reflow | Medium | snapshot |
| T-037 | 일본어 입력/검색 | Unicode 정규화 | Japanese | 전각/반각/조합문자 | 저장 후 검색 | 정규화 결과 일관, 데이터 변형 없음 | Medium | 자동화 |
| T-038 | RTL pseudo-language | 향후 방향성 안전 | RTL pseudo locale | 모든 화면 | 탐색 | 아이콘·정렬·back 의미가 올바름 | Low | snapshot |
| T-039 | iPad split view | 반응형 레이아웃 | iPad | 1/3, 1/2, full widths | 회전·분할 | 정보 손실 없이 적응, 상세 탐색 효율 유지 | Medium | UI 자동/수동 |
| T-040 | 다크/고대비 | 색 대비 | Dark+Increase Contrast | 모든 상태 | 화면 탐색 | 텍스트/상태/선택 대비 기준 충족 | High | 자동 contrast+수동 |
| T-041 | 메모 1,000자 경계 | 길이 정책 | 상세 편집 | 999/1000/1001자 | 저장 | 정확한 제한·counter·데이터 손실 없는 안내 | Medium | 자동화 |
| T-042 | 폴더 rename 충돌 | 참조 일관성 | 2개 폴더/클립 | 기존 이름으로 rename | 저장 | 거절, 모든 clip 참조 불변 | High | 자동화 |
| T-043 | 폴더 삭제/병합 | 안전한 분류 정리 | 폴더 내 여러 clip | 폴더 삭제 | 대상 선택→확인 | 클립 이동·폴더 삭제가 한 transaction | High | 자동화 |
| T-044 | 앱 종료 중 persist | lifecycle durability | 편집 직후 종료 | memo 변경 | 즉시 app kill | 정의된 commit 시점 이전/이후 동작 일관, 손상 없음 | High | 실기기 |
| T-045 | 저장 공간 임계치 | 사전 경고 | 낮은 디스크 | 이미지 공유 | 용량 부족 유도 | 저장 전 예측·오류 후 고아 없음·정리 진입점 | Critical | 실기기 |
| T-046 | Privacy Manifest archive | Required Reason 검증 | Release archive | xcprivacy | archive→privacy report | 선언/실사용 일치, validation warning 0 | Critical | release gate |
| T-047 | Extension embedding | 배포 산출물 확인 | Release archive | 앱 archive | unzip/validate | appex 포함, bundle/app group/signing 일치 | Critical | release gate |
| T-048 | 네트워크 무통신 검증 | local-only 약속 | clean install | 일반 사용 전체 | proxy/network log | 사용자가 요청한 링크 열기 외 개발자 서버 전송 없음 | Critical | release privacy |


## CI 권장 파이프라인

1. **fast checks**: YAML/JSON/plist 검증, XcodeGen generate 후 diff 0, SwiftFormat/SwiftLint(채택 시), secret scan.
2. **unit/integration**: iOS simulator에서 unit tests, corrupt/migration/failing-storage fixtures.
3. **UI/accessibility**: 대표 iPhone/iPad, 3개 언어, light/dark, AX5 snapshot 및 `performAccessibilityAudit`.
4. **extension harness**: mock host/provider와 App Group container로 URL/text/image queue E2E.
5. **release candidate**: Release archive, embedded appex/entitlement/bundle ID 검사, privacy report, export validation.
6. **manual signed gate**: Safari·Photos·Face ID·낮은 저장 공간·앱 전환기·TestFlight 업데이트 검증 증거 첨부.

CI 로그에는 클립 본문·URL·이미지 이름을 남기지 않는다. 실패 fixture는 합성 데이터만 사용한다.
