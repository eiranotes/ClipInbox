# Competitor & Market Analysis

- 조사 기준일: 2026-07-11
- 가격은 국가·통화·세금·프로모션에 따라 달라질 수 있다. 본 표는 확인 가능한 공식 페이지/스토어 또는 명시된 현재 공개 가격을 기준으로 하며, 실제 구매 화면에서 재확인해야 한다.
- ClipInbox는 전통적 clipboard history와 read-later/bookmark manager 사이에 위치한다. 직접 경쟁과 대체 행동을 분리해야 한다.

## 1. 시장 포지셔닝 맵

```text
자동 클립보드 기록  <---------------------------->  사용자가 명시적으로 저장
Paste / PastePal / Maccy                         ClipInbox / Anybox / GoodLinks

단순 재사용  <-------------------------------------------->  장기 지식 관리
Maccy / Pastery                 ClipInbox       Raindrop / Reader / mymind

로컬 전용  <--------------------------------------------->  계정·클라우드 중심
Maccy / Pastery / ClipInbox          GoodLinks     Raindrop / Reader / mymind
```

**권장 포지션:** “iPhone/iPad에서 어디서든 공유하고, 계정 없이 로컬에 모아 두는 가장 단순한 캡처 인박스.”

## 2. 경쟁 제품 비교

| 앱 | 분류 | 플랫폼 | 핵심 기능 | 강점 | 약점/ClipInbox 기회 | 가격(조사 시점) | 개인정보 방식 | ClipInbox가 참고할 점 |
|---|---|---|---|---|---|---|---|---|
| Paste | 직접/상위 clipboard | macOS, iPhone, iPad | 무제한 history, search, pinboards, sync, collaboration | 세련된 UI, 기기간 연속성, 강한 브랜드 | subscription 부담, 광범위 history가 privacy anxiety 유발 가능 | 연간 약 US$29.99, 월 환산 US$2.49; lifetime 옵션 표기 | 동기화형 | 검색 속도, visual timeline, pinboard; 단 자동 수집을 모방하지 않음 |
| PastePal | 직접/clipboard | Apple platforms | history, collections, iCloud sync, keyboard/share/action extensions, widgets, Siri | universal one-time, Apple 생태계 통합 | 기능이 많아 학습 부담; ClipInbox는 더 단순할 수 있음 | 약 US$14.99 one-time | 로컬 + 선택 iCloud | extension 생태계, collection, one-time pricing |
| Maccy | 직접 대체(Desktop) | macOS | lightweight clipboard history, keyboard search | 빠르고 open-source, keyboard-first | 모바일 Share-to-Inbox·이미지 정리에는 약함 | 무료/open-source, 후원/스토어 배포 변동 | 로컬 중심 | 즉시 검색, keyboard efficiency, 최소 UI |
| Pastery | 직접 대체(Desktop) | macOS | local timeline, text/images/links/colors/files, OCR, filters, transforms | local-only와 rich type 처리 | iOS capture inbox가 아님 | 공식 구매 화면 확인 필요 | 로컬 전용 강조 | 콘텐츠 타입별 smart action, OCR는 on-device로 참고 |
| Anybox | 인접/북마크 | iPhone, iPad, Mac | links, notes, images/files, nested tags/folders, smart lists, automation, Spotlight, share extension | 매우 넓은 Apple 통합, local/iCloud 선택, lifetime 제공 | 고급 기능이 많아 가벼운 inbox 사용자에는 과함 | 무료 50 links; Pro 약 US$1.99/mo, US$14.99/yr, US$39.99 lifetime | iCloud, no-data-collection 표방 | smart lists, Spotlight, URL schemes, import/export 완성도 |
| GoodLinks | 인접/read-later | iPhone, iPad, Mac | clean reader, offline article, tags/search, widgets/Shortcuts | no-account/private 메시지, one-time universal purchase | 링크/기사 중심이라 이미지·텍스트 임시 수집 범위 제한 | 약 US$9.99 one-time | iCloud sync, tracking 없음 표방 | 투명한 one-time 가치, reader는 장기 후보 |
| Raindrop.io | 인접/bookmark platform | Web, iOS, Android, desktop, extensions | unlimited bookmarks/collections, full-text, archive, duplicate/broken link, AI suggestions | cross-platform·성숙한 검색·import | 계정/클라우드, 제품이 무겁고 local-only 아님 | Free; Pro 지역별, 공개 자료에서 대략 US$28/yr 수준 | cloud account | duplicate finder, web archive, broad import는 장기 비교 기준 |
| Readwise Reader | 인접/read-it-later | Web, mobile | read-later, highlights, tags, notes, export, feeds/documents | 읽기·하이라이트·knowledge workflow 강함 | 높은 구독료와 복잡성; quick local inbox와 목적 다름 | 연간 결제 월 US$9.99, 월 결제 US$12.99 수준 | cloud account | capture 후 소비 workflow; ClipInbox는 읽기 앱이 되지 않도록 경계 |
| mymind | 인접/AI visual memory | Web, mobile, extensions | AI tagging, OCR/image search, smart spaces, reading mode, backup | 분류 없는 저장과 시각적 재발견 | 구독·AI/cloud 의존, 사용자 제어 약할 수 있음 | Bookmarker 약 US$4.99/mo부터 | cloud/AI | “저장 먼저, 자동 정리 나중” 가치; local AI일 때만 차용 |
| Apple Notes/Files/Photos + Share Sheet | OS 대체 | Apple platforms | 공유, 메모, 파일/사진 보관, iCloud | 이미 설치, 신뢰, 무료, 시스템 통합 | 콘텐츠가 여러 앱에 흩어지고 capture inbox 관점 없음 | OS 포함 | Apple 계정/기기 설정 | ClipInbox의 진짜 경쟁은 별도 앱 설치 비용; 첫 저장을 극단적으로 단순화 |
| Safari Reading List/Bookmarks | OS 대체 | Apple platforms | 링크 저장, offline reading | friction 낮음 | 이미지·텍스트·태그·임시 triage 부족 | OS 포함 | Apple 생태계 | 링크만 저장하려는 사용자에게 더 나은 이유를 명확히 해야 함 |

## 3. 직접 경쟁 vs 간접 경쟁

### 직접 경쟁

- Paste, PastePal: Apple 생태계에서 빠른 재사용과 clipboard history를 제공한다.
- Maccy, Pastery: local-first·빠른 검색·최소 UI의 기준점이다.

ClipInbox는 이들과 “모든 복사를 자동 기록”으로 경쟁하면 iOS 제약과 개인정보 신뢰에서 불리하다. 대신 **명시적으로 공유한 것만 보관**해 데이터 최소화와 의도성을 차별점으로 삼는다.

### 인접 경쟁

- Anybox, GoodLinks, Raindrop, Readwise Reader, mymind
- 이들은 장기 보관·검색·읽기·지식 관리가 강하다.
- ClipInbox는 캡처 순간과 짧은 backlog triage에서 더 빠르고 가벼워야 한다.

### OS 기본 기능

가장 강한 대체재는 유료 경쟁 앱이 아니라 Notes, Safari, Files, Photos에 각각 공유하는 현재 행동이다. 따라서 “한 곳에 모인다” 외에도 다음을 증명해야 한다.

- 분류하지 않고도 1초 내 저장
- 최근/미정리만 빠르게 다시 보기
- 중복·휴지통·검색으로 안전하게 관리
- 계정·업로드 없음

## 4. 시장 표준 기능

### 출시 전 기본값으로 간주해야 할 것

1. 빠른 Share Extension
2. 명확한 search
3. folders/tags 또는 collections
4. favorites/pins
5. import/export
6. dark mode
7. duplicate handling
8. delete recovery
9. storage/privacy explanation
10. 여러 기기 또는 최소한 안전한 백업 경로
11. onboarding/help
12. accessibility

현재 ClipInbox는 1–6의 상당 부분을 갖췄지만 7–12가 약하다.

### 차별화가 가능한 것

- local-only 기본값과 no-account
- 명시적으로 공유한 항목만 수집
- Quick vs Review save
- “Unsorted”를 중심으로 한 inbox triage
- 한국어·영어·일본어를 출시 초기부터 제공
- 원본 이미지/텍스트/URL을 하나의 단순 모델로 보관
- local diagnostic/export로 투명성 제공

### 개발 대비 효과가 낮은 것

- 초기 서버 AI summarization
- social collaboration/team spaces
- full web scraping/archive
- 광고·추천 feed
- 모든 플랫폼 동시 출시
- 전통 clipboard 자동 history를 iOS에서 억지로 재현

## 5. 경쟁 UI 패턴

| 패턴 | 경쟁 제품 경향 | ClipInbox 권고 |
|---|---|---|
| 첫 화면 | timeline 또는 library | Inbox list + Unsorted/Favorites smart views |
| 캡처 | share extension/browser extension/clipboard | Share Extension을 1급 기능으로, manual Add 보조 |
| 검색 | always-visible quick search, filters | Search tab 유지, Inbox 상단 과밀 filter 축소 |
| 분류 | pinboards/collections/tags/spaces | folder=location, tag=attribute, smart view=system으로 역할 분리 |
| 상세 | preview + actions + note | 고정 1 viewport 목표보다 accessible scroll 우선 |
| 이미지 | visual grid/preview/OCR | 기본은 list, image smart view에서 adaptive grid 후보 |
| 삭제 | trash/restore 또는 history retention | 30일 Trash + immediate Undo |
| 개인정보 | local/iCloud/no tracking messaging | “기본 local-only, 공유한 것만”을 모든 onboarding/metadata에 반복 |
| 결제 | subscription, one-time, freemium 혼재 | local-only 동안 one-time 또는 free+one-time Pro |
| 설정 | sync, retention, exclusions, shortcuts | capture behavior, storage, privacy, backup를 상단에 배치 |

## 6. 사용자 불만 기회

경쟁 카테고리에서 반복적으로 발생하는 제품 긴장은 다음과 같다.

- subscription fatigue
- clipboard를 전부 기록하는 privacy concern
- sync conflict/계정 의존
- 기능 과잉과 복잡한 folder/tag 체계
- 검색은 강하지만 삭제/보존 통제가 불명확
- iOS와 Mac 기능 차이
- Share Extension이 느리거나 실패 상태가 불명확

ClipInbox는 “더 많은 기능”이 아니라 아래 약속으로 이 문제를 해결할 수 있다.

> **내가 공유한 것만, 내 기기에, 즉시 저장되고, 언제든 내보내고 완전히 지울 수 있다.**

이 문장은 현재 false-success, 손상 fallback, 영구 삭제, 불완전 export 때문에 아직 코드로 완전히 보장되지 않는다. 제품 마케팅 전에 구현 계약을 먼저 맞춰야 한다.

## 7. 가격·수익화 비교 해석

- Paste는 반복 가치와 sync/collaboration으로 subscription을 정당화한다.
- PastePal·Anybox·GoodLinks는 Apple 생태계의 local/iCloud utility에 one-time/lifetime 옵션을 제공한다.
- Raindrop·Reader·mymind는 서버 검색·archive·AI·feed처럼 지속 비용이 있어 subscription이 자연스럽다.

**ClipInbox 권고:**

- 1.0: one-time purchase 또는 free core + one-time Pro
- 무료/core에서 데이터 안전, export, trash, accessibility를 제한하지 않음
- Pro: OCR, batch actions, Shortcuts/Spotlight, advanced search, large image policy
- subscription: 자체 sync/AI가 실제 반복 비용을 만들 때만 별도 플랜

## 8. 차별화 전략

### 메시지

- “Clipboard manager”보다 “Private capture inbox”
- “No account. No server. No tracking.”은 실제 binary 검증 후 사용
- “Share once, sort later.”

### 1.0에서 이겨야 하는 5개 순간

1. 설치 후 첫 URL을 30초 안에 저장
2. Share Sheet에서 Quick save가 결정적으로 성공/실패
3. 100개가 쌓여도 최근·미정리·검색으로 즉시 찾음
4. 실수 삭제를 되돌림
5. 사용자가 언제든 전체 백업·삭제 범위를 이해함

## 9. 소스 레지스터

- Paste 공식 사이트/가격: https://pasteapp.io/
- PastePal 공식 사이트/App Store 안내: https://indiegoodies.com/pastepal
- Maccy 공식 사이트: https://maccy.app/
- Pastery 공식 사이트: https://pastery.app/
- Anybox 공식 사이트/가격: https://anybox.app/
- GoodLinks 공식 사이트: https://goodlinks.app/
- Raindrop Pro: https://raindrop.io/pro/buy
- Readwise pricing: https://readwise.io/pricing
- mymind pricing: https://mymind.com/pricing
- Apple App Review Guidelines: https://developer.apple.com/app-store/review/guidelines/

가격·기능은 조사일 이후 변경될 수 있으므로 출시 직전 재확인한다.
