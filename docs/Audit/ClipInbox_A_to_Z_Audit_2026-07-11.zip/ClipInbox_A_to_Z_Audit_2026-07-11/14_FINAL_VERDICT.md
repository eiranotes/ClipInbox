# ClipInbox Final Verdict

## 1. 최종 판정

**현재 상태로 공개 App Store 출시는 부적합하다.**

정확한 등급은 **“주요 수정 후 출시 가능”**이다. 네이티브 앱과 Share Extension, 로컬 저장, 폴더·태그·검색, 다국어·다크 모드라는 제품 골격은 이미 있다. 문제는 구현량이 부족해서가 아니라, 개인 데이터 보관 앱의 핵심 계약인 **“저장됐다고 표시되면 실제로 안전하게 저장돼 있고, 손상·삭제·잠금 실패를 사용자가 복구하거나 이해할 수 있어야 한다”**가 아직 보장되지 않는다는 점이다.

종합 점수: **58/100**

## 2. 질문별 최종 답변

### 2.1 현재 상태로 출시 가능한가

아니다.

- 내부 개발/디자인 검증용으로는 충분하다.
- P0 수정 후 제한 TestFlight는 가능하다.
- 공개 출시에는 P0와 데이터·privacy·accessibility 관련 High P1, 정책 URL·signed archive gate가 모두 필요하다.

### 2.2 출시를 막는 문제는 무엇인가

1. 주 데이터 손상을 샘플 데이터로 조용히 대체
2. 다수 mutation이 저장 실패를 무시하고 성공 표시
3. 실제 Add가 아닌 하드코딩 demo 생성
4. Share Extension 대형 이미지 memory/용량 무제한
5. 앱 잠금 fail-open
6. schema version/migration/recovery 부재
7. CI·failure tests·extension E2E·archive validation 부재
8. privacy/support URL과 App Store 자료 미완료
9. signed physical-device App Group/Face ID 검증 미완료
10. 접근성·삭제 복구·storage controls 부족

### 2.3 가장 먼저 수정할 10개 항목

| 순서 | ID | 작업 | 완료 증거 |
|---:|---|---|---|
| 1 | DATA-001/DATA-012 | 손상 감지, previous backup, quarantine, recovery UI | corrupt/truncated fixture 전부 통과 |
| 2 | DATA-002/TEST-002 | 모든 mutation transaction/rollback | disk-full fake에서 false-success 0 |
| 3 | DATA-003/TEST-003 | schema migrator, future version 차단 | v1/v2/current/future fixture matrix |
| 4 | REL-001/REL-002 | 이미지 file ingest, byte/pixel cap, timeout/cancel | 48MP 실기기에서 crash 0 |
| 5 | SEC-001/SEC-002 | lock fail-closed, inactive privacy shield | Face ID cancel/unavailable/switcher tests |
| 6 | UX-001/FEATURE-001 | 실제 URL/text/photo/memo Add | demo 값 0, UI test 통과 |
| 7 | REL-003/005/006 | queue quarantine/quota/idempotency | corrupt/remove-fail/1k queue tests |
| 8 | UI-001~004 | Dynamic Type, 44pt, adaptive filter/reflow | AX5/3언어 snapshot blocker 0 |
| 9 | TEST-001/008 | CI와 Release archive gate | protected main checks + archive report |
| 10 | REL-010/014/015 | 실제 정책 URL, signing, App Store assets | signed TestFlight + metadata checklist |

### 2.4 최소 출시까지 필요한 작업

- 위 Top 10
- 첫 실행 onboarding/empty state
- 휴지통·Undo 또는 최소한의 안전 삭제 복구
- 평문 export 경고·versioned import/rollback
- storage usage·이미지 보존 정책
- VoiceOver core flow
- iPad support를 유지한다면 regular/split layout QA
- privacy policy, support, App Privacy, release notes
- external TestFlight와 rollback archive

### 2.5 완성도 높은 경쟁 제품 수준까지 필요한 작업

- smart views와 advanced filters
- duplicate detection
- batch triage
- fast indexed search
- Core Spotlight/App Intents/Shortcuts
- 온디바이스 OCR
- storage/retention transparency
- 선택적 iCloud sync 또는 Mac companion
- mature import ecosystem
- polished help/recovery/diagnostics

Paste나 Raindrop의 모든 기능을 따라갈 필요는 없다. ClipInbox는 local/no-account/explicit-share의 단순함을 잃지 않으면서 **신뢰·검색·복구·Apple 플랫폼 통합**만 경쟁 수준으로 올리는 것이 맞다.

### 2.6 이 프로젝트의 가장 큰 가능성은 무엇인가

**자동 clipboard history와 무거운 knowledge manager 사이의 공백**이다.

- 사용자가 의도적으로 공유한 것만 저장
- 계정/서버 없이 시작
- 이미지·텍스트·URL을 한 인박스에 모음
- 분류는 나중에
- Apple 생태계에서 native하고 빠른 경험

이 포지션은 개인정보에 민감하고 subscription을 싫어하며, Notes/Files/Photos에 자료가 흩어지는 사용자를 겨냥할 수 있다.

### 2.7 가장 큰 실패 위험은 무엇인가

기능 부족이 아니라 **신뢰 붕괴**다.

- 저장 성공이라고 했지만 재실행하면 사라짐
- 손상됐는데 샘플 데이터가 보임
- 앱 잠금을 켰는데 특정 상태에서 열림
- 대형 사진을 공유하면 확장이 종료됨
- 삭제 후 복구할 수 없음

개인 보관 앱에서 한 번의 데이터 손실은 낮은 별점보다 장기 retention 자체를 무너뜨린다.

### 2.8 계속 개발할 가치가 있는가

있다.

- 프로토타입 수준을 넘어 native app/extension/data flow가 있다.
- 로컬 우선 범위가 명확하다.
- UI 기반이 좋고 localization도 시작돼 있다.
- 외부 runtime dependencies와 서버가 없어 수정 면적이 통제 가능하다.

다만 다음 개발 사이클은 AI·sync·새 플랫폼이 아니라 데이터 안전과 release engineering에 집중해야 한다.

### 2.9 어떤 제품 방향이 가장 적합한가

**Privacy-first Share-to-Inbox for Apple devices**

- 1.0: iPhone/iPad local-only, no account, one-time/free+Pro
- 1.x: OCR, batch, Spotlight, Shortcuts
- 2.0 후보: optional iCloud sync, Mac companion
- 비추천: 광고, 기본 서버 업로드, 자동 clipboard 감시, 초기 team collaboration

### 2.10 최종 권고안

현재 UI와 기능을 폐기하지 말고 6–10주 규모의 “Data-Safe 1.0” 프로그램으로 전환한다.

1. repository/recovery/transaction
2. extension image/queue
3. lock/privacy
4. manual Add/onboarding/trash/storage
5. accessibility/search polish
6. CI/signed TestFlight/App Store

## 3. 종합 점수

| 영역 | 점수 |
|---|---:|
| 제품 컨셉 | 82 |
| 기능 완성도 | 64 |
| 코드 품질 | 56 |
| 아키텍처 | 52 |
| UI | 74 |
| UX | 64 |
| 접근성 | 45 |
| 성능 | 55 |
| 안정성 | 48 |
| 보안 | 56 |
| 개인정보 보호 | 67 |
| 테스트 | 42 |
| 배포 준비도 | 41 |
| 문서화 | 70 |
| 경쟁력 | 56 |
| **종합** | **58** |

## 4. 출시 판정 기준

### 현재

- **현재 출시 부적합**

### 제한 TestFlight 가능 조건

- P0 data/extension/lock/Add 0개
- signed device 핵심 flow 통과
- corrupt/disk-full/migration tests
- 실제 privacy/support 연락 경로

### 공개 App Store 가능 조건

- P0 0개
- data/privacy/accessibility High P1 0개
- onboarding/trash/storage/recovery
- CI + release archive/privacy report
- external TestFlight blocker 0
- 정확한 metadata/screenshots/policy

## 5. Top 10 문제

1. **DATA-001** — 손상 스냅샷의 sample fallback
2. **DATA-002** — persist 실패 무시와 false-success
3. **UX-001** — demo Add
4. **REL-001** — Share Extension 이미지 memory/storage 무제한
5. **SEC-001** — app lock fail-open
6. **DATA-003** — schema migration/version gate 없음
7. **TEST-001/002/003** — CI·failure/migration tests 없음
8. **REL-010/014/015** — 정책 URL·signed release·store assets 미완료
9. **UI-001/002/003/004** — Dynamic Type·touch·adaptive layout 부족
10. **DATA-009/UX-011** — 삭제 복구·storage controls 없음

## 6. Top 10 비용 대비 개선

1. 파일 없음과 decode failure를 분리
2. 성공 toast를 `persist == true` 이후로 제한하고 rollback
3. sample data를 Preview로 이동
4. app switcher privacy cover
5. pending queue를 `createdAt`으로 정렬
6. corrupt queue quarantine
7. chip hit target 44pt
8. 하드코딩 accessibility label localization
9. internal JSON에서 pretty print 제거
10. root README/LICENSE/SECURITY와 실제 support/privacy URL

위 항목 중 1–4는 코드량 대비 위험 감소가 특히 크다. 다만 `persist == true`만 확인하는 임시 patch에 머물지 말고 transaction 구조로 이어가야 한다.

## 7. 오늘 바로 시작할 작업

1. `AppStore.init`을 `firstRun / loaded / corrupt / unsupported` 결과로 분리하는 characterization test 작성
2. 쓰기 실패 fake를 만들고 `deleteClip`, `updateMemo`, `saveNewClip`, `deleteAllData`의 false-success를 재현
3. `ClipRepository`와 `SnapshotRecovery` interface 생성
4. 하드코딩 demo Add를 feature flag 뒤로 숨기고 production UI에서 비활성화
5. app lock capability unavailable test와 privacy shield 구현
6. Share image의 byte/pixel logging-free measurement를 추가하고 임시 hard cap 적용
7. actual support/privacy domain·email 소유 결정
8. GitHub Actions macOS build/unit skeleton 생성
9. Dynamic Type AX5에서 Inbox/Detail/Settings screenshot baseline 생성
10. 모든 P0를 GitHub issue로 옮기고 본 보고서 ID를 유지

## 8. 불확실성과 검증 필요

- Xcode build/test 결과는 독립 재실행하지 못했다.
- 저장소 QA evidence의 simulator 결과는 작성자 기록으로만 인정했다.
- folder deletion, image cache cost limit, 일부 VoiceOver semantic은 전체 checkout/실행에서 재확인해야 한다.
- 실제 App Store Connect, Apple Developer profile, privacy report, physical-device behavior는 접근할 수 없었다.
- 경쟁 제품 가격과 Apple 정책은 변경될 수 있어 제출 직전 공식 페이지를 다시 확인해야 한다.

이 제한은 P0 판단을 약화하지 않는다. 핵심 데이터/잠금/이미지 위험은 공개된 소스의 제어 흐름에서 직접 확인되는 구조적 문제다.

## 9. 최종 한 문장

**ClipInbox는 제품 방향과 시각 기반이 좋은 초기 iOS 앱이지만, “저장·잠금·복구”의 신뢰 계약을 먼저 완성해야만 프라이버시 중심 제품이라는 장점이 실제 경쟁력으로 바뀐다.**
