# Functional Completeness Audit

## 1. 제품 기능 정의

현재 구현의 핵심은 **iOS Share Extension을 통한 명시적 캡처 → 로컬 인박스 → 나중에 분류·검색·재사용**이다. 백그라운드 클립보드 감시, 계정, 서버 동기화, 웹 스크래핑, 소셜 협업은 현재 제품 범위가 아니다.

### 제품 컨셉 평가

| 평가 항목 | 점수 | 근거 | 문제점 | 개선 방향 |
|---|---:|---|---|---|
| 문제 정의 명확성 | 8/10 | 여러 앱에서 본 링크·이미지를 한 곳에 임시 수집 | “Clip” 명칭이 자동 clipboard history로 오해될 수 있음 | Share-to-Inbox 메시지 명확화 |
| 핵심 가치 전달력 | 7/10 | 계정·서버 없이 빠르게 저장 | 온보딩과 실제 Add가 미완성 | 첫 실행에서 30초 내 첫 공유 성공 |
| 사용 흐름 일관성 | 6/10 | 공유→인박스→분류 흐름은 일관 | 중앙 Add는 데모, 삭제는 영구 | 실제 입력·Undo·복구 상태 추가 |
| 차별성 | 7/10 | 로컬 전용·단순한 캡처 인박스 | 경쟁 앱의 동기화·고급 검색과 격차 | 프라이버시·속도·명시적 캡처 집중 |
| 제품 완성도 | 6/10 | 작동 가능한 앱/확장 구조 | 데이터 신뢰·접근성·배포 미완료 | P0/P1 gate 순서대로 완성 |

## 2. 기능 인벤토리

| 기능 | 구현 상태 | 관련 화면/경로 | 관련 파일/영역 | 정상 경로 | 주요 예외·누락 | 출시 준비도 |
|---|---|---|---|---|---|---|
| 앱 최초 실행 | 부분 구현 | App root | `AppStore.init`, DefaultData | JSON load 또는 기본값 | 손상과 첫 실행 미구분, 샘플 데이터 노출 | 차단 |
| 온보딩 | 미구현 | 없음 | 없음 | — | Share Extension 활성화·Favorites·모드 설명 없음 | 차단/High |
| Share URL | 구현 | Share Extension | `ShareViewController.swift` | URL payload enqueue→앱 import | timeout·queue cleanup·signed host 검증 | 베타 전 수정 |
| Share 웹페이지 | 구현 | Share Extension | activation rules/controller | webpage URL/텍스트 수집 | host별 provider 차이 | 검증 필요 |
| Share 선택 텍스트 | 구현 | Share Extension | controller | text enqueue | 매우 긴 텍스트·encoding E2E 부족 | 보강 |
| Share 이미지 | 부분 구현 | Share Extension | controller/queue | 원본 bytes 저장 | 대형 이미지 메모리·용량 무제한 | 차단 |
| Share 스크린샷 | 이미지로 구현 | Share Extension | image path | Photos/host에서 공유 | 별도 screenshot type 추론 일관성 검증 | 검증 필요 |
| Quick save | 구현 | Share Extension | configuration/controller | 즉시 저장 후 confirmation | 고정 2초 대기, 실패 의미론 | 보강 |
| Review save | 구현 | Share Extension | review form | 폴더·메모 검토 후 저장 | 접근성·긴 내용·host keyboard | 보강 |
| 앱 내 수동 추가 | UI/로직 불일치 | 중앙 Add | `saveNewClip` | 하드코딩 데모 생성 | 실제 URL/text/image 입력 없음 | 차단 |
| Inbox 목록 | 구현 | Inbox tab | Inbox/Components | 최근 항목 목록 | 대규모 데이터·빈 상태·sample badge | 보강 |
| 클립 상세 | 구현 | Detail | Detail views | 이미지/링크/메모/태그 조회 | 고정 높이·오류 상태·접근성 | 보강 |
| 검색 | 구현 | Search tab | AppStore/Search views | title/source/tag/memo 등 substring | 고급 필터·오타·날짜·도메인 scope 없음 | 출시 가능, 개선 |
| 최근 검색 | 구현 | Search | UserDefaults | 최근 query 보관 | export에 포함되지 않음 | 출시 가능 |
| 타입 필터 | 구현 | Inbox top | `InboxFilter` | link/image/memo/screenshot | 5열 고정·긴 번역 | 보강 |
| 태그 필터 | 구현 | Inbox top | filter tags | 상단 기본 태그 | 고정 기본 태그와 사용자 태그 관계 불명확 | 보강 |
| 폴더 목록 | 구현 | Folders tab | Folder views | 폴더별 수/진입 | 삭제·병합 정책 확인 필요 | 부분 |
| 폴더 생성 | 구현 | Folder workflow | AppStore | 중복 검사 후 생성 | persist 실패 false-success 가능 | 차단 |
| 폴더 이름 변경 | 구현 | Folder workflow | AppStore | clip 참조 전파/rollback | 충돌·실패 테스트 확대 필요 | 양호 |
| 폴더 삭제/병합 | 미확인/미비 | Folder workflow | 코드에서 명확한 계약 미확인 | — | 포함 클립 이동·기본 폴더 보호 필요 | 검증 필요 |
| 태그 추가 | 구현 | Settings/detail | AppStore | 정규화·catalog merge | persist 실패 처리 | 보강 |
| 태그 이름 변경 | 구현 | Settings | AppStore | clip/folder 참조 전파 | 대규모 transaction·rollback test | 양호/보강 |
| 태그 삭제 | 구현 | Settings | AppStore | 참조 제거 | Undo/영향 미리보기 없음 | 보강 |
| 즐겨찾기 | 구현 | row/detail | AppStore | bookmark toggle | 전용 smart view/발견성 약함 | 개선 |
| Sort Later | 구현 | sorting flow | AppStore/UI | 미정리 1건 분류 | 대량 batch/keyboard 없음 | 출시 가능, 개선 |
| 메모 편집 | 구현 | Detail | AppStore | 1,000자 정규화 저장 | 저장 실패에도 성공 토스트 | 차단 |
| 클립 편집 | 구현 | Detail | AppStore | title/folder/tags/memo 변경 | transaction 일관성 부족 | 차단 |
| 클립 이동 | 구현 | actions/sheet | AppStore | 폴더 변경 | 저장 실패·Undo 부족 | 차단 |
| 클립 삭제 | 구현 | actions/detail | AppStore | 배열 제거→persist→image delete | persist 실패 rollback 없음, 영구 삭제 | 차단 |
| 전체 데이터 삭제 | 구현 | Settings danger zone | AppStore | state/defaults/image 제거 | 부분 실패 시 불일치·복구 없음 | 차단 |
| JSON 내보내기 | 구현 | Settings | import/export service in store | snapshot file 공유 | 평문 위험, 이미지/일부 settings 제외 가능 | 보강 |
| JSON 가져오기 | 구현 | Settings | AppStore | 5MB cap→decode→normalize | version 검증·rollback·object budget 부족 | 차단 |
| 백업/복원 | JSON import/export 수준 | Settings | snapshot | 수동 roundtrip | 완전 백업 아님, 암호화/자산 manifest 부족 | 부분 |
| 기기 간 동기화 | 미구현 | 없음 | 없음 | — | 제품 의도상 선택적 | MVP 비필수 |
| 테마 | 구현 | Settings | Preferences/L10n/design tokens | light/dark/system | 문자열 persistence, contrast 검증 | 보강 |
| 언어 | 구현 | Settings | L10n/Preferences | 한국어/영어/일본어 | 하드코딩 label·긴 번역 QA | 보강 |
| 앱 잠금 | 부분 구현 | Lock/Settings | LocalAuthentication lifecycle | 인증 후 화면 표시 | fail-open·app switcher·암호화 오해 | 차단 |
| 링크 열기 방식 | 구현 | Settings/detail | LinkOpenMode | direct/confirm | direct default와 피싱 인지 | 개선 |
| 전체 화면 이미지 | 구현 | Detail | viewer | pinch/double tap | pan·rotation·VoiceOver 보강 | 개선 |
| 다크 모드 | 구현 | 전체 | theme/tokens | 앱/extension theme 전달 | contrast·모든 상태 검증 | 보강 |
| iPad | target 지원 | 전체 | project.yml | portrait/landscape 허용 | split view·sidebar 최적화 미확인 | 검증 필요 |
| 오프라인 | 기본 지원 | 대부분 | local-only | 저장·검색·정리 | 외부 링크/metadata는 제한 | 강점 |
| 알림 | 미구현 | 없음 | 없음 | — | 핵심에 불필요; reminder 추가 시 opt-in | MVP 비필수 |
| 위젯/Shortcuts/Spotlight | 미구현 | 없음 | 없음 | — | 파워유저 확장 기회 | 후속 |
| 진단/복구 센터 | 미구현 | 없음 | 없음 | — | queue corruption·backup recovery 가시성 없음 | P1 |
| 저장 공간 관리 | 미구현 | Settings 없음 | image store | — | 원본 누적·큰 파일 정리 불가 | P1 |
| 휴지통/Undo | 미구현 | 없음 | data model | — | 영구 삭제 | P1 |
| 중복 감지 | 미구현 | 없음 | capture/import | — | 동일 URL/image 반복 | P2 |

## 3. 사용자 시나리오 감사

### 3.1 최초 설치와 첫 저장

**현재 예상 흐름**

1. 앱 실행
2. 샘플 클립이 있는 Inbox 확인
3. 사용자가 직접 iOS Share Sheet에서 ClipInbox를 찾아야 함
4. Quick 또는 Review 모드로 저장
5. 앱을 다시 열어 queue import

**문제**

- `[확인됨]` Share Extension 사용법을 앱이 단계적으로 가르치는 온보딩이 보이지 않는다.
- `[확인됨]` 샘플이 진짜 사용자 데이터처럼 보여 앱의 실제 상태와 캡처 성공을 혼동한다.
- `[추정]` Share Sheet Favorites에 확장을 고정하지 않으면 첫 저장 마찰이 크다.
- `[중대 위험]` 중앙 Add를 누르면 실제 입력이 아니라 샘플 링크가 추가된다.

**권장 목표 흐름**

1. 빈 Inbox + “공유해서 저장” 설명
2. 20초 interactive guide: Safari 샘플 URL 공유 또는 수동 Add
3. Quick/Review 선택의 의미 설명
4. 첫 성공 후 saved card와 Inbox 하이라이트
5. Share Extension을 Favorites에 두는 방법을 설정에서 언제든 재확인

### 3.2 반복 캡처

- Quick 모드는 제품의 가장 강한 반복 사용 흐름이다.
- 성공은 queue JSON이 durable하게 저장된 뒤에만 표시해야 한다.
- 앱이 열리지 않아도 queue가 쌓이므로 count/bytes/age 상한과 diagnostics가 필요하다.
- 동일 URL/텍스트/이미지를 반복 공유할 때 merge·duplicate UX가 필요하다.

### 3.3 나중에 찾기

현재 검색·타입/태그 필터·폴더·즐겨찾기가 있으나 개념이 겹친다.

- 폴더: 항목이 위치하는 하나의 기본 장소
- 태그: 여러 속성
- Smart view: Inbox, Unsorted, Favorites, Recent, Images, Trash

위처럼 의미를 분리해야 사용자가 “폴더와 태그 중 무엇을 써야 하는가”를 덜 고민한다.

### 3.4 정리와 삭제

- Sort Later는 좋은 제품 컨셉이나 한 번에 1개를 처리하는 현재 형태는 backlog가 커질수록 피로하다.
- swipe triage, batch select, 최근 사용 폴더, tag suggestion을 단계적으로 추가한다.
- 모든 삭제는 soft delete가 기본이며, 이미지 파일도 trash retention이 끝날 때 제거해야 한다.

### 3.5 백업·기기 변경

현재 JSON export/import는 최소 생존 기능이지만 “완전 백업”이라고 부르기 어렵다.

- 일부 UserDefaults 상태가 빠진다.
- 이미지 원본 포함 여부와 manifest 계약이 불명확하다.
- schema version을 검사하지 않는다.
- 평문 파일이 다른 앱/클라우드에 남을 위험을 충분히 알려야 한다.

**1.0 요구:** versioned archive, preview, checksum, optional encryption, atomic restore, 기존 데이터 merge/replace 선택, 실패 rollback.

## 4. 주요 예외 흐름

| 조건 | 현재 위험 | 권장 동작 |
|---|---|---|
| 주 JSON 손상 | 샘플로 조용히 대체 | current 격리→backup 검증→복구 선택 |
| 저장 공간 부족 | mutation은 성공처럼 보일 수 있음 | rollback, 필요한 용량·정리 CTA 표시 |
| 권한/App Group 실패 | Share 저장 실패 또는 config 불일치 | 명시 오류, retry, signing diagnostics |
| 대형 이미지 | extension memory 종료 가능 | 용량/픽셀 제한, file copy, optimize 선택 |
| provider 응답 없음 | extension hang | timeout, cancel, host 복귀 |
| 앱 강제 종료 | 마지막 mutation durability 불명확 | commit 시점 명확화, journal/transaction |
| 미래 버전 import | 기존 데이터 왜곡 가능 | import 차단, 앱 업데이트 안내 |
| 중복 ID/URL | collision·노이즈 | UUID + canonical duplicate UX |
| 매우 긴 다국어 | 잘림·축소·정규화 | semantic layout, explicit limits/counters |
| 저사양/대량 데이터 | 검색·목록·저장 지연 | performance budget, index/downsample |
| 잠금 인증 불가 | 콘텐츠 노출 | fail-closed, recovery 안내 |
| 삭제 실수 | 영구 손실 | Undo + Trash |

## 5. 플랫폼별 기능 상태

### iOS/iPadOS

- 유일한 프로덕션 플랫폼이다.
- iOS 17+, iPhone/iPad target, Share Extension, App Group, LocalAuthentication이 중심이다.
- 물리 기기에서 Face ID, Photos provider, App Group release signing, file protection, iPad split view를 검증해야 한다.

### Android

- `[확인됨]` Android 구현은 없다.
- 현재는 누락 결함이 아니라 iOS 집중 전략으로 본다.
- Android clipboard/background 정책과 구현 비용은 iOS PMF 확인 이후 별도 제품으로 평가한다.

### Web/Desktop

- 루트 웹 앱은 역사적 정적 프로토타입이다.
- production 배포 대상으로 취급하면 persistence/auth/security/hosting/accessibility가 거의 새 프로젝트 수준으로 필요하다.
- 단기에는 “웹 앱도 제공한다”는 마케팅을 하지 않는다.

## 6. MVP 정의 재설정

### 반드시 포함

- 실제 URL/text/image/manual memo 추가
- Share URL/text/image quick/review
- 데이터 손상 복구와 저장 실패 rollback
- Inbox, Search, Folders/Tags, Favorites, Sort Later
- 휴지통/Undo
- JSON versioned backup/restore
- storage controls
- 앱 잠금 fail-closed + privacy shield
- 접근 가능한 3개 언어/다크 모드

### 출시 후 가능

- OCR, semantic search, metadata fetching
- iCloud sync
- Shortcuts/Spotlight/widgets
- Mac companion

### 구현 비추천

- 사용자가 모르는 백그라운드 clipboard 수집
- 광고 SDK
- 기본값 서버 업로드
- 데이터 신뢰를 완성하기 전 AI 요약·자동 분류

## 7. 기능 완성도 판정

- **내부 프로토타입:** 통과
- **제한 TestFlight:** P0 데이터/extension/lock/Add 수정 후 통과 가능
- **공개 App Store:** P0 + 온보딩·접근성·삭제 복구·release/legal gate 완료 전 부적합
