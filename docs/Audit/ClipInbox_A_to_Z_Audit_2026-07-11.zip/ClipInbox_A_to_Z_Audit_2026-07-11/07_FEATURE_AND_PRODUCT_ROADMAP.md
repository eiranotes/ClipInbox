# Feature & Product Roadmap

## 전략 원칙

1. 데이터 신뢰가 기능 수보다 우선이다.
2. 제품의 중심은 “클립보드 감시”가 아니라 **사용자가 공유한 것을 즉시 로컬 인박스에 보관**하는 경험이다.
3. 계정·서버 없는 기본값을 지킨다. 동기화·AI는 명확한 opt-in과 별도 가치로만 추가한다.
4. 분류를 강요하지 않는다. 먼저 저장하고, 나중에 빠르게 정리하는 흐름을 강화한다.
5. iOS에서 PMF를 확인하기 전 Android·웹·팀 협업으로 확장하지 않는다.

## 기능 평가

| 기능 | 사용자 가치(10) | 차별성(10) | 개발 난이도 | 보안/개인정보 위험 | 추천 시점 | 최종 판단 |
|---|---:|---:|---|---|---|---|
| 실제 수동 Add | 10 | 7 | M | Low | P0 즉시 | 즉시 구현 |
| 손상 복구·버전 migration | 10 | 5 | M | Low | P0 즉시 | 즉시 구현 |
| 휴지통·Undo | 9 | 5 | M | Low | 1차 출시 | 즉시 구현 |
| 중복 URL/텍스트 감지 | 8 | 6 | M | Low | 1차 출시 | 즉시 구현 |
| 저장 공간 대시보드·보존 정책 | 9 | 7 | M/L | Low | 1차 출시 | 즉시 구현 |
| Share Extension 온보딩 | 9 | 5 | M | Low | 1차 출시 | 즉시 구현 |
| 고급 검색 필터 | 8 | 5 | L | Low | 1.1 | MVP 이후 |
| 배치 정리·다중 선택 | 8 | 5 | L | Low | 1.1 | MVP 이후 |
| URL 메타데이터/미리보기 | 8 | 4 | L | Medium | 1.1 | MVP 이후 |
| 온디바이스 OCR | 7 | 7 | L | Medium | 1.2 | 유료 기능 후보 |
| Core Spotlight | 7 | 6 | M | Low | 1.2 | MVP 이후 |
| Shortcuts/App Intents | 7 | 6 | L | Low | 1.2 | 유료 기능 후보 |
| 홈/잠금 화면 위젯 | 6 | 4 | M | Medium | 1.2 | 유료 기능 후보 |
| 선택적 iCloud 동기화 | 9 | 6 | XL | High | 2.0 | 유료 기능 후보 |
| Mac companion | 8 | 7 | XL | Medium | 2.0+ | 장기 검토 |
| 로컬 의미 검색 | 7 | 8 | XL | Medium | 2.0+ | 장기 검토 |
| 서버 AI 자동 요약 | 5 | 4 | XL | High | 보류 | 구현 비추천 |
| 광고 기반 무료화 | 2 | 1 | M | High | 보류 | 구현 비추천 |
| 백그라운드 무단 클립보드 감시 | 3 | 2 | XL | High | 보류 | 구현 비추천 |


## Release 0.4 — Data-Safe Alpha

- snapshot 복구·backup rotation·schema migration
- 모든 mutation transaction/rollback
- Share Extension 이미지 limit/timeout/quarantine
- 잠금 fail-closed·app switcher shield
- 실제 Add 폼
- CI 기본 build/unit/migration checks

**Exit criteria:** fault injection에서 false-success 0건, 손상 fixture 전부 복구/명시 오류, 48MP 사진에서 extension crash 0건.

## Release 0.5 — Usable Private Beta

- 첫 실행/Share Extension 온보딩
- 휴지통·Undo
- Dynamic Type/VoiceOver/44pt 전면 개선
- storage dashboard·보존 정책
- queue diagnostics
- 실기기 Safari/Text/Photos/Face ID/iPad matrix

**Exit criteria:** AX5·3개 언어·light/dark blocker 0, signed TestFlight에서 핵심 흐름 통과.

## Release 1.0 — Public App Store

- 실소유 privacy/support URLs, monitored email
- App Store metadata/screenshots/privacy answers
- 정확한 로컬 전용·잠금 범위 설명
- duplicate detection, 안정된 search/filter
- signed archive/privacy report/appex validation
- crash-free 기준과 rollback plan

## Release 1.1–1.2 — Retention & Power User

- batch triage, smart lists, advanced search
- URL metadata·offline preview 정책
- Core Spotlight, App Intents, widgets
- 온디바이스 OCR와 smart actions

## Release 2.0 후보

- 선택적 CloudKit 동기화: 로컬 전용 기본값을 유지하고 conflict history·복구 로그를 제공한다.
- Mac companion: iOS 캡처와 데스크톱 재사용의 결합이 구독/유료 업그레이드의 가장 자연스러운 근거다.
- 로컬 의미 검색: 장치 성능·모델 크기·배터리 예산이 충족될 때만 제공한다.

## 수익화 권고

### 권장안 A — 일회성 구매

- 가장 단순하고 제품 철학과 일치한다.
- 앱 자체가 로컬 기능만 제공하는 동안 구독을 강제할 지속 비용 근거가 약하다.
- 출시 초기에는 지역별 일회성 가격 A/B가 아닌 단일 투명 가격을 권장한다.

### 권장안 B — 무료 Core + 일회성 Pro

- 무료: 무제한 또는 합리적 수의 텍스트/URL 저장, 검색, 폴더, export.
- Pro: 대용량 이미지, OCR, batch actions, Shortcuts, advanced filters, Mac companion.
- 데이터 복구·휴지통·접근성·암호화 같은 신뢰 기능은 유료 장벽 뒤에 두지 않는다.

### 구독이 정당화되는 조건

- 사용자가 선택한 CloudKit 이상의 운영형 동기화 서비스, 지속 서버 AI, 팀 기능처럼 실제 반복 비용이 발생할 때만 별도 플랜으로 검토한다.
- 광고·데이터 판매는 프라이버시 포지셔닝과 직접 충돌하므로 배제한다.

## 성장 전략

- “공유 시트에서 1초, 계정 없음, 서버 없음”을 첫 메시지로 사용한다.
- 인테리어·디자인 레퍼런스 수집, 읽을거리, 쇼핑 후보, 여행 링크 등 3–4개 구체 use case로 스토어 스크린샷을 구성한다.
- 초기 평가는 기능 수가 아니라 저장 성공률, 첫 공유 완료율, 7일 재검색률, 삭제 복구율로 측정한다.
- 개인정보 지표를 보내지 않는다면 사용자가 직접 진단 리포트를 선택적으로 export하는 운영 경로를 만든다.
