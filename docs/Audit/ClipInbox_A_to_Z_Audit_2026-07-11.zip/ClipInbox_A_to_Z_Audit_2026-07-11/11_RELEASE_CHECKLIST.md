# ClipInbox Final Release Checklist

체크 방법: 항목에 코드 PR, CI run, 스크린샷, signed-build 동영상, App Store Connect 화면 중 하나 이상의 증거 링크를 연결한다. P0 관련 항목은 담당자의 구두 확인만으로 닫지 않는다.

## 코드·데이터

- [ ] 손상 스냅샷과 첫 실행을 구분한다
- [ ] current/.bak/quarantine 복구가 자동 테스트된다
- [ ] 모든 mutation이 durable commit 실패 시 rollback된다
- [ ] snapshot version migration과 future-version 거절이 테스트된다
- [ ] 샘플 데이터는 production empty state와 분리된다
- [ ] 실제 Add URL/text/image/memo가 동작한다
- [ ] 휴지통/Undo 또는 동등한 복구가 있다
- [ ] 이미지/queue orphan reconciliation이 있다

## 테스트

- [ ] PR마다 XcodeGen generate drift가 0인지 확인한다
- [ ] Debug/Release simulator build가 통과한다
- [ ] 단위·통합·UI 테스트가 CI에서 통과한다
- [ ] corrupt/disk-full/migration fixtures가 통과한다
- [ ] Share URL/text/image E2E가 통과한다
- [ ] 48MP/대용량 이미지 메모리 테스트가 통과한다
- [ ] 5,000개 검색·스크롤 성능 예산을 통과한다
- [ ] TestFlight update/migration 테스트를 통과한다

## 보안·개인정보

- [ ] 앱 잠금이 capability 오류·취소에서 fail-closed다
- [ ] inactive/background에서 app switcher shield가 즉시 표시된다
- [ ] 주 JSON과 App Group 파일 보호 수준을 실기기에서 확인한다
- [ ] export 평문/암호화 범위를 사용자에게 고지한다
- [ ] 실제 release binary의 네트워크 송신을 점검한다
- [ ] Privacy Manifest Required Reason API 보고서가 오류 없이 생성된다
- [ ] 민감 로그가 없고 OSLog privacy가 적용된다
- [ ] 데이터 삭제·백업·복구·보존 정책이 정책문과 일치한다

## UI·UX·접근성

- [ ] 첫 실행에 Share Extension 사용법과 Favorites 안내가 있다
- [ ] Quick/Review 모드 차이를 이해할 수 있다
- [ ] Dynamic Type AX5에서 핵심 화면 잘림이 없다
- [ ] 모든 핵심 터치 대상이 최소 44x44다
- [ ] VoiceOver로 저장·정리·검색·삭제 복구가 가능하다
- [ ] 한국어·영어·일본어 긴 문자열을 검증했다
- [ ] light/dark/increase contrast 대비를 측정했다
- [ ] iPad portrait/landscape/split view를 검증했다
- [ ] 모든 loading/empty/error/recovery 상태가 행동을 안내한다

## iOS·확장

- [ ] App/Share bundle ID와 App Group entitlement가 release profile과 일치한다
- [ ] Share Extension activation rules가 URL/text/image 요구 범위와 일치한다
- [ ] Safari, Photos, 선택 텍스트 공유를 signed build에서 확인한다
- [ ] provider timeout/cancellation과 host return을 확인한다
- [ ] extension이 containing app을 자동 실행한다고 오해시키지 않는다
- [ ] 앱과 extension의 설정 파일 version/checksum이 일치한다
- [ ] iPhone/iPad 지원 방향과 실제 UI가 일치한다
- [ ] 최소 iOS 17 지원 전략을 스토어 정보와 일치시킨다

## 배포·App Store

- [ ] 실소유 HTTPS privacy URL이 앱 내부와 App Store Connect에 있다
- [ ] 실소유 HTTPS support URL과 모니터링 이메일이 있다
- [ ] placeholder 문구·URL·샘플 화면이 모두 제거됐다
- [ ] Distribution certificate/profile로 signed archive를 생성했다
- [ ] archive에 ClipInboxShare.appex가 올바르게 embed/sign됐다
- [ ] Validate App가 경고/오류 없이 통과한다
- [ ] App Privacy 답변이 release binary와 일치한다
- [ ] 스크린샷이 실제 현재 UI와 기능만 보여준다
- [ ] 심사 노트에 Share Extension 활성화·테스트 방법을 쓴다
- [ ] export compliance·연령 등급·카테고리·가격을 확정한다
- [ ] TestFlight 외부 테스트 피드백과 crash-free gate를 통과한다
- [ ] rollback 가능한 이전 archive와 release notes를 보관한다

## 운영·문서·법무

- [ ] 루트 README, LICENSE, SECURITY.md가 있다
- [ ] THIRD_PARTY_NOTICES에 폰트·이미지 자산 근거가 있다
- [ ] 빌드·테스트·배포·복구 runbook이 있다
- [ ] 데이터 손상·privacy incident 대응 담당과 절차가 있다
- [ ] 지원 문의에서 민감 원문을 요구하지 않는 진단 절차가 있다
- [ ] 버전·changelog·migration notes가 릴리스와 일치한다
- [ ] 앱 이름·상표·도메인 사용 가능성을 확인했다
- [ ] 개인정보 처리방침을 필요한 관할 기준으로 검토했다


## Go/No-Go 서명

- [ ] Engineering: P0 0개, P1 수용 가능한 잔여 목록 승인
- [ ] QA: signed release matrix와 migration 통과
- [ ] Product/Design: 현재 메타데이터와 실제 기능 일치
- [ ] Privacy/Legal: 정책·App Privacy·연락처 승인
- [ ] Release owner: archive hash, version/build, rollback artifact 기록

**No-Go 자동 조건:** 데이터 손상 또는 false-success 재현, extension crash, 잠금 우회, placeholder URL, signed archive/appex 검증 실패, Privacy Manifest 오류, 실제 Add 미구현.
