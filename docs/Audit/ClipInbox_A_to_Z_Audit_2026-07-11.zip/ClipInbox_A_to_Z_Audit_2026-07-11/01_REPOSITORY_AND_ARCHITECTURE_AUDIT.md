# Repository & Architecture Audit

## 1. 감사 범위와 방법

- `[확인됨]` 공개 저장소 `main` 브랜치의 파일 트리, Swift 소스, XcodeGen 설정, plist/entitlement/privacy manifest, 테스트, 내부 문서, QA 증거 화면을 정적 검토했다.
- `[확인됨]` Apple 공식 App Review·Privacy Manifest·접근성 자료와 경쟁 제품의 공식 기능/가격 페이지를 2026-07-11 기준으로 대조했다.
- `[검증 필요]` 감사 런타임은 macOS/Xcode를 제공하지 않아 `xcodegen`, `xcodebuild`, XCTest, Instruments, signed archive를 독립 실행하지 못했다. 저장소의 `.superloopy/evidence`와 문서가 보고한 simulator build/share QA는 참고 증거이며 독립 재현 결과가 아니다.
- `[검증 필요]` Git clone 또한 감사 런타임의 네트워크 제약으로 수행하지 못했으므로, 공개 GitHub 파일 뷰를 기준으로 분석했다. 따라서 숨겨진 branch·비공개 CI·App Store Connect 상태는 범위 밖이다.

## 2. 저장소 개요

| 항목 | 확인 결과 | 평가 |
|---|---|---|
| 저장소 | 공개 GitHub, `main`, 확인 시점 9 commits, release 없음 | 초기 제품 저장소 |
| 프로덕션 소스 | `ios/` | 저장소 `AGENTS.md`가 명시 |
| 역사적 프로토타입 | `src/`, `public/`, `index.html` | 정적 웹 디자인/상호작용 참조 |
| iOS 프로젝트 생성 | `ios/project.yml`, XcodeGen 2.45.4+ | 재현 가능한 project definition은 장점 |
| 언어/프레임워크 | Swift 5.10, SwiftUI + Share Extension의 UIKit | 네이티브 iOS 집중 |
| 최소 OS | iOS 17.0 | 범위는 선명하나 도달 범위 축소 |
| 지원 기기 | iPhone/iPad (`TARGETED_DEVICE_FAMILY=1,2`) | iPad UI 최적화는 별도 검증 필요 |
| 버전 | 0.3.0, build 1 | pre-1.0 단계 |
| 런타임 외부 의존성 | 확인되지 않음 | 공급망·개인정보 측면 강점 |
| 저장소 라이선스 | 루트 LICENSE를 확인하지 못함 | 공개 배포·기여 권리 불명확 |
| CI | `.github/workflows`를 확인하지 못함 | 출시 게이트 부재 |
| 문서 | `docs/CHANGELOG.md`, `CODE_REVIEW.md`, `DECISIONS.md`, `PROJECT_STATUS.md`, `TASKS.md`, app-store 문서 | 내부 진행 기록은 양호 |
| 루트 README | 확인하지 못함 | 외부 DX·제품 설명에 큰 공백 |

## 3. 상위 디렉터리 해석

```text
ClipInbox/
├── ios/                         # 프로덕션 SwiftUI 앱, Share Extension, 테스트, XcodeGen
│   ├── ClipInbox/               # 앱 코드/리소스/entitlement/privacy manifest
│   │   ├── Models/              # Clip, Folder, Preferences, DataSnapshot, DefaultData
│   │   ├── Store/               # AppStore: 상태·검색·mutation·저장·import/export
│   │   ├── Shared/              # 앱/확장 공용 payload, queue, image asset, localization
│   │   └── Views/               # Inbox, Detail, Search, Folders, Settings, 공통 컴포넌트
│   ├── ClipShareExtension/      # ShareViewController, Info.plist, entitlement
│   ├── ClipInboxTests/          # 단위 테스트
│   └── project.yml              # XcodeGen source of truth
├── src/, public/, index.html    # 역사적 정적 웹 프로토타입
├── scripts/                     # 프로토타입 QA/static validation
├── Reference/                   # 디자인 참조
├── docs/                        # 상태·결정·릴리스·App Store 문서
├── .superloopy/evidence/        # 저장소 작성자의 QA 증거
├── AGENTS.md                    # source-of-truth 및 빌드 지침
├── DESIGN.md                    # 디자인 정의
└── package.json                 # 의존성 없는 정적 프로토타입 스크립트
```

`AGENTS.md`가 `ios/`를 프로덕션 source of truth로 명시한 점은 좋다. 그러나 루트에서 웹과 iOS가 같은 무게로 보여 신규 기여자가 잘못된 트리를 수정할 가능성이 있다. 프로토타입을 `prototypes/web/`로 이동하거나 루트 README 첫 화면에서 구조를 시각적으로 구분하는 것이 바람직하다.

## 4. 현재 런타임 아키텍처

```text
SwiftUI Screens / UIKit Share UI
          │
          ▼
     AppStore (@Observable)
  ┌───────┼────────┬───────────┐
  │       │        │           │
검색/필터  Mutation  Import/Export  Preferences
  │       │        │           │
  └───────┴────────┴───────────┘
          │
          ▼
Application Support/clip-inbox-data.json
          ▲
          │ import on app activation
App Group Queue (per-item JSON) + Original Images
          ▲
          │
Share Extension / NSItemProvider
```

### 장점

- `[확인됨]` Share Extension과 앱이 단일 거대한 공유 스냅샷을 동시에 쓰지 않고, **항목별 원자적 queue 파일**을 사용한다. 동시 쓰기 충돌을 줄이는 좋은 선택이다.
- `[확인됨]` queue와 원본 이미지 쓰기에 `.atomic`과 `.completeFileProtectionUnlessOpen`을 사용한다.
- `[확인됨]` 이미지 파일명은 UUID와 허용 확장자로 검증하고 path traversal을 막는다.
- `[확인됨]` 외부 URL은 http/https로 제한하고, 여러 문자열에 길이 상한을 둔다.
- `[확인됨]` XcodeGen이 target·entitlement·resource를 코드화해 project file 수동 drift를 줄인다.

### 구조적 약점

- `[중대 위험]` `AppStore`가 약 662줄로 상태, UI toast, 검색, 정규화, mutation, JSON I/O, Share queue import, import/export, UserDefaults까지 담당한다.
- `[확인됨]` 파일 I/O가 protocol/actor 뒤에 있지 않아 disk full·permission·corruption을 주입하기 어렵고, UI thread 지연 가능성이 있다.
- `[확인됨]` mutation의 성공 계약이 통일돼 있지 않다. 일부 rename은 rollback하지만 대부분은 `persist()` 반환값을 무시한다.
- `[확인됨]` `Preferences`와 Share 설정에 번역된 문자열이 저장돼 도메인 모델과 표현 계층이 결합된다.
- `[확인됨]` `DataSnapshot.version`은 있으나 load/import 단계에서 지원 버전 검증과 migrator가 없다.
- `[확인됨]` 내부 데이터 저장과 사용자 export가 같은 JSON 모델에 가깝게 결합돼 내부 스키마 변경이 public backup contract에 영향을 준다.

## 5. 핵심 파일 리뷰

### 5.1 `ios/ClipInbox/Store/AppStore.swift`

**책임:** 전체 앱 상태, 검색/필터, 폴더·태그·클립 mutation, 저장, Share queue import, JSON import/export, 토스트.

#### 발견 1 — 손상과 첫 실행의 혼동

초기화에서 파일 읽기/디코딩 실패를 `try?`로 처리하고 `DefaultData`로 대체한다. 파일이 없는 정상 첫 실행과 기존 파일이 손상된 상황이 구분되지 않는다.

- 심각도: Critical / P0
- 사용자 영향: 실제 데이터가 보이지 않고 샘플로 바뀌며, 다음 mutation이 샘플을 주 파일에 기록할 수 있음
- 수정: `StoreBootstrapResult`를 `.firstRun`, `.loaded`, `.recoveredBackup`, `.corrupt(URL)`, `.unsupportedVersion`으로 모델링한다.

#### 발견 2 — 저장 전 메모리 mutation

`deleteClip`, `updateMemo`, `updateTags`, `saveNewClip`, 설정 변경 등 다수 경로가 먼저 배열/설정을 변경한 뒤 `persist()` 실패를 무시한다.

- 심각도: Critical / P0
- 수정: `repository.transaction { draft in ... }`가 임시 스냅샷을 작성·검증·교체한 뒤 성공 결과를 반환하고, ViewModel은 성공 후에만 상태를 publish한다.

#### 발견 3 — 실제 Add가 아님

`saveNewClip`은 사용자 입력 URL/콘텐츠가 아니라 `brunch.co.kr` 샘플 제목·URL·이미지를 하드코딩해 새 클립으로 만든다.

- 심각도: Critical / P0
- 영향: 핵심 CTA와 실제 기능 불일치, App Review 최소 기능성·정확한 메타데이터 위험

#### 발견 4 — 전체 스냅샷 재작성

모든 mutation이 pretty-printed 전체 JSON을 다시 인코딩하고 atomic write한다.

- 소규모 MVP에는 단순하고 안전한 장점이 있으나, 수천 항목·다수 이미지 메타에서 main-thread latency와 쓰기 증폭이 커진다.
- 단기: StorageActor + compact encoding + debounce/coalesce
- 중기: SQLite/SwiftData/GRDB 등 record store로 이전하고 JSON은 export 전용으로 유지

### 5.2 `ios/ClipInbox/Models/Models.swift`

- `[확인됨]` `Clip.id`는 `Int`, 시간은 `String`, 폴더·태그는 문자열 참조다.
- `[확인됨]` `Preferences` decoder가 필드별 `try?`와 기본값을 사용한다. 호환성에는 관대하지만 손상을 조용히 숨길 수 있다.
- `[확인됨]` 샘플 클립·폴더가 `DefaultData`에 production 기본값으로 들어 있다.

**권장 모델:**

```swift
struct Clip: Identifiable, Codable, Sendable {
    let id: UUID
    var kind: ClipKind
    var createdAt: Date
    var updatedAt: Date
    var source: ClipSource
    var content: ClipContent
    var folderID: Folder.ID?
    var tags: Set<Tag.ID>
    var deletion: DeletionState
}
```

표현 문자열은 localization 계층에서 생성하고, raw 데이터에는 `Date`, UUID, enum key만 보관한다.

### 5.3 `ios/ClipInbox/Shared/SharedClipQueue.swift`

**좋은 부분:** 항목별 JSON, atomic write, App Group file protection, UUID 이미지 파일명, 이미지 형식 검증.

**문제:**

- queue 정렬이 UUID 파일명 기준이므로 캡처 순서를 보장하지 않는다.
- decode 실패 항목은 `compactMap`으로 조용히 제외돼 파일이 영구 잔류한다.
- queue count/bytes/TTL 제한이 없다.
- config save와 legacy migration 실패가 `try?`로 사라진다.
- clip commit과 이미지 이동/삭제가 하나의 트랜잭션이 아니다.

### 5.4 `ios/ClipShareExtension/ShareViewController.swift`

- `[확인됨]` Quick/Review 두 모드, URL/webpage/text/image 지원, compact confirmation을 구현했다.
- `[중대 위험]` `loadDataRepresentation`, `Data(contentsOf:)`, `UIImage.pngData()`가 원본을 전부 메모리에 올린다.
- `[확인됨]` provider callback에 timeout/cancellation이 없다.
- `[확인됨]` 여러 fallback 오류가 `try?`로 사라진다.
- `[개선 권장]` 파일 representation을 우선하고 byte/pixel budget을 적용한다. 미리보기만 downsample하고, 원본 보존은 용량 정책 내에서 streaming/copy한다.

### 5.5 UI 및 Settings 파일

- `Components.swift` 약 640줄, `SettingsView.swift` 약 473줄로 공통 스타일과 많은 화면 책임이 뭉쳐 있다.
- `[확인됨]` 디자인 토큰과 공통 row 구성은 재사용을 높이지만, fixed size 중심이어서 접근성 적응이 약하다.
- `[개선 권장]` `Primitive`, `Composite`, `Feature` 컴포넌트로 나누고 semantic typography를 토큰의 1급 요소로 만든다.

## 6. 코드 품질 평가

| 항목 | 점수 | 근거 | 개선 |
|---|---:|---|---|
| 네이밍/가독성 | 7/10 | 함수·모델 이름이 대체로 목적을 드러냄 | 표시 문자열과 domain key 분리 |
| 타입 안정성 | 5/10 | Swift enum 일부 사용, 설정·시간·참조는 문자열 | UUID/Date/Codable enum |
| 오류 처리 | 3/10 | `try?`, Bool persist, false-success | typed error/result, rollback |
| 모듈성 | 4/10 | AppStore/Components 과대 | services/use cases/repositories |
| 테스트 가능성 | 4/10 | fileURL 주입 장점, FileManager·queue 직접 결합 | protocols/fakes/clock/id injection |
| 문서/주석 | 7/10 | 내부 결정·작업 기록과 일부 주석 양호 | root README/runbook/API contract |
| 보안 기본기 | 6/10 | 로컬·file protection·URL/path 검증 | fail-closed/file protection/export warning |
| 확장성 | 4/10 | 전체 메모리/JSON 모델 | record store/index/asset lifecycle |
| 일관성 | 6/10 | 디자인·localization 체계 있음 | mutation/error contract 통일 |

## 7. 코드 지표와 핫스팟

| 파일/영역 | 확인된 규모 | 위험 |
|---|---:|---|
| `AppStore.swift` | 662 lines / 588 LOC | God object, 데이터 신뢰 핵심 |
| `Components.swift` | 약 640 lines / 567 LOC | 디자인 primitive와 feature component 혼합 |
| `SettingsView.swift` | 약 473 lines / 429 LOC | 설정·import/export·위험 행동 복잡도 |
| `AppStoreTests.swift` | 약 223 lines / 179 LOC | 기능 대비 테스트 폭이 좁음 |
| Share Extension controller | 단일 대형 UIKit controller | provider·UI·save orchestration 결합 |

정확한 cyclomatic complexity와 dead-code 수치는 로컬 checkout과 SwiftSyntax/Periphery 실행이 필요해 `[검증 필요]`다. 다만 정적 검토만으로도 저장·공유·설정에 고위험 책임이 집중된 것은 명확하다.

## 8. 권장 리팩터링 경로

### 단계 1 — 동작 보존형 분리

1. `ClipRepository`와 `FileClipRepository` 생성
2. `SnapshotCodec`, `SnapshotMigrator`, `SnapshotRecovery` 분리
3. `PreferencesStore`, `SharedCaptureQueue`, `ImageStore` protocol화
4. 모든 mutation을 `Result<CommittedState, StoreError>`로 통일
5. `AppStore`는 화면 상태와 use-case 호출만 담당

### 단계 2 — 안전한 비동기와 자산 트랜잭션

1. `StorageActor`에서 load/save/import 수행
2. `ImageStoreTransaction`으로 write/commit/rollback 제공
3. queue quarantine와 idempotency key 추가
4. UI에 loading/degraded/recovery 상태 추가

### 단계 3 — 규모에 따른 저장소 이전

- 1,000개 이하가 명확한 제품 제한이라면 안전한 versioned snapshot도 유지 가능하다.
- 무제한 보관을 약속한다면 SQLite/SwiftData 기반 record store가 필요하다.
- JSON export contract는 내부 DB와 분리하고 명시적 `ExportSchemaVersion`을 둔다.

## 9. 의존성·공급망·라이선스

- `[확인됨]` iOS 런타임 외부 패키지는 보이지 않아 dependency CVE 표면이 작다.
- `[확인됨]` Pretendard 폰트가 번들된다. 폰트 라이선스 파일/고지는 release bundle과 `THIRD_PARTY_NOTICES`에서 확인해야 한다.
- `[중대 위험]` 루트 LICENSE가 없으면 공개 저장소 코드를 제3자가 합법적으로 재사용·기여할 조건이 명확하지 않다.
- `[검증 필요]` `public/`, `Reference/`, 앱 아이콘·샘플 이미지의 출처와 배포 권리를 자산 인벤토리로 확인해야 한다.

## 10. 최종 아키텍처 판정

**전면 재작성은 권장하지 않는다.** 현재 네이티브 UI, Share Extension, localization, 기본 모델은 보존 가치가 있다. 그러나 데이터 신뢰 경계는 부분 리팩터링이 아니라 **명확한 repository transaction·migration·recovery 계층**으로 구조를 바꿔야 한다. 이 조치 없이 기능을 더하면 false-success와 손상 복구 문제가 더 넓어진다.
