# ClipInbox Master Issue List

- 기준일: 2026-07-11
- 우선순위: P0 출시 차단 / P1 출시 전 권장 / P2 출시 직후 / P3 중장기 / P4 선택
- 노력: S 수 시간 / M 1–3일 / L 4일–2주 / XL 2주+
- 상태는 정적 감사 결과이며, `검증 필요`는 macOS/Xcode·실기기·배포 계정 확인이 필요하다.

## 통계

- 총 101개 항목
- 심각도: Critical 12, High 40, Medium 42, Low 7
- 우선순위: P0 18, P1 51, P2 22, P4 1, P3 6, P0/P1 3
- 상태: 확인됨 78, 추정 9, 검증 필요 7, 기능 제안 7

## 통합 목록

| ID | 제목 | 유형 | 심각도 | 우선순위 | 관련 파일/영역 | 사용자 영향 | 수정 방향 | 작업량 | 상태 |
|---|---|---|---|---|---|---|---|---|---|
| DATA-001 | 손상된 주 스냅샷을 샘플 데이터로 대체 | Data/Reliability | Critical | P0 | ios/ClipInbox/Store/AppStore.swift:init | 손상·호환성 오류가 첫 실행처럼 보이고 이후 실제 파일을 덮어쓸 수 있음 | 파일 없음과 decode 실패를 분리; 손상 파일 격리; 마지막 정상 .bak 복구; 복구 UI 제공 | M | 확인됨 |
| DATA-002 | 다수 변경 작업이 persist 실패를 무시 | Data/Reliability | Critical | P0 | ios/ClipInbox/Store/AppStore.swift:mutate/delete/update/save | 성공 토스트 뒤 재실행 시 변경 유실, 메모리·디스크 불일치 | repository transaction을 도입하고 실패 시 rollback; 성공 UI는 durable commit 이후 표시 | L | 확인됨 |
| DATA-003 | 스냅샷 version 검증·마이그레이션 부재 | Data/Architecture | High | P0 | Models.swift:DataSnapshot, AppStore.swift:importJSON | 업데이트·미래 포맷 import 시 조용한 기본값 대체 또는 데이터 왜곡 | 지원 버전 allowlist, 단계별 Migrator, unsupportedVersion 오류, fixture 회귀 테스트 | M | 확인됨 |
| DATA-004 | localized 표시 문자열을 설정 값으로 영속화 | Data/I18N | Medium | P1 | Models.swift:Preferences, SharedClipConfiguration | 언어 변경·문구 수정 시 설정 해석이 깨지고 마이그레이션이 어려움 | Theme/Language/ShareMode/AppLock을 안정된 enum raw key로 저장하고 UI에서 번역 | M | 확인됨 |
| DATA-005 | 클립 시간을 Date가 아닌 상대 표시 문자열로 저장 | Data/UX | High | P1 | Models.swift:Clip.time, DefaultData | “방금 전”이 영구 고정되고 실제 정렬·날짜 필터·동기화가 불가능 | createdAt/updatedAt Date 저장, 표시 시 RelativeDateTimeFormatter 사용 | M | 확인됨 |
| DATA-006 | JSON 백업이 전체 사용자 상태를 포함하지 않음 | Data/UX | Medium | P1 | AppStore.swift + UserDefaults keys | 최근 검색·태그 카탈로그·링크 열기 설정 등이 복원되지 않아 “전체 백업” 기대와 불일치 | ExportEnvelope에 버전·preferences·catalog·optional assets manifest 포함 | M | 확인됨 |
| DATA-007 | Int 증가 ID와 import ID 범위 검증 부족 | Data | Medium | P2 | Models.swift:Clip.id, AppStore.swift nextID | 극단 값·중복·overflow에서 신규 저장 충돌 가능 | UUID 기본키로 이전; migration에서 기존 Int를 legacyID로 보존 | L | 추정 |
| DATA-008 | 모든 변경마다 전체 pretty JSON 재작성 | Data/Performance | High | P1 | AppStore.swift:persist | 클립·이미지 메타가 늘수록 UI 지연·쓰기 증폭·실패 면적 증가 | actor 기반 repository, SQLite/SwiftData 또는 append journal; 쓰기 coalescing | L | 확인됨 |
| DATA-009 | 휴지통·Undo 없이 영구 삭제 | Data/UX | High | P1 | AppStore.swift:deleteClip/deleteAllData | 오조작으로 복구 불가능; 개인 보관 앱의 신뢰 훼손 | soft delete + 30일 휴지통 + 즉시 Undo + 명시적 영구 삭제 | M | 확인됨 |
| DATA-010 | 중복·유사 항목 감지 부재 | Data/Product | Medium | P2 | Capture/import flow | 같은 URL·텍스트·이미지를 반복 저장해 검색 품질과 저장 공간 악화 | canonical URL/text hash/image perceptual hash; 저장 전 merge/duplicate prompt | L | 확인됨 |
| DATA-011 | 이미지 보존 정책·용량 제한·정리 기능 부재 | Data/Performance | High | P1 | SharedClipQueue.swift, SettingsView.swift | 원본 이미지가 무기한 누적돼 앱/기기 저장 공간을 잠식 | 단건/총량/보존기간 제한, storage dashboard, orphan sweeper, optimize originals 옵션 | L | 확인됨 |
| DATA-012 | 마지막 정상본·checksum·복구 저널 부재 | Data/Reliability | High | P0 | AppStore.swift:persist | 원자적 쓰기만으로 논리 손상·잘못된 import·OS 오류 복구 불가 | write temp→validate→rotate current/bak; checksum/record count; 복구 선택 UI | M | 확인됨 |
| DATA-013 | Application Support 디렉터리 생성 오류 무시 | Data/Reliability | Medium | P1 | AppStore.swift:defaultFileURL | 경로 준비 실패 후 저장이 계속 실패해도 원인을 알 수 없음 | throwing store bootstrap과 fatal/recoverable state 분리; 사용자 안내·로그 | S | 확인됨 |
| DATA-014 | JSON import의 개수·중첩·총 이미지 자산 제한 부족 | Data/Security | Medium | P1 | AppStore.swift:importJSON | 5MB 안에 매우 많은 객체를 넣어 CPU/메모리 과부하 또는 UX 정지 가능 | clip/folder/tag count budget, decode deadline, duplicate validation, preview/dry run | M | 확인됨 |
| DATA-015 | 폴더 삭제/병합 정책이 불명확 | Data/UX | Medium | P2 | AppStore.swift, Folder views | 사용자가 잘못 만든 폴더를 정리하거나 포함 클립을 안전하게 이동하기 어려움 | 삭제 전 이동 대상 선택, 병합, 기본 폴더 보호 규칙 구현 | M | 검증 필요 |
| REL-001 | Share Extension이 원본 이미지를 통째로 메모리에 적재 | Reliability/Performance | Critical | P0 | ios/ClipShareExtension/ShareViewController.swift:loadImageAsset | 대형 사진·스크린샷에서 extension memory pressure로 종료·저장 실패 | file representation 우선, coordinated copy, byte/pixel cap, incremental metadata read, downsample preview | L | 확인됨 |
| REL-002 | NSItemProvider load에 timeout·cancellation 없음 | Reliability | High | P1 | ShareViewController.swift load continuations | 공급자가 응답하지 않으면 확장이 시스템 종료까지 멈출 수 있음 | withThrowingTaskGroup timeout, cancellation handler, 명확한 retry UI | M | 확인됨 |
| REL-003 | 손상된 queue JSON을 조용히 건너뛰고 방치 | Reliability/Data | High | P1 | SharedClipQueue.swift:pendingItems | 저장되지 않은 항목이 영구 고아가 되고 사용자는 알 수 없음 | decode 실패 파일 quarantine, retry count, diagnostics/복구 화면 | M | 확인됨 |
| REL-004 | 공유 큐 정렬이 createdAt이 아닌 UUID 파일명 | Reliability/UX | Medium | P2 | SharedClipQueue.swift:pendingItems | 여러 공유 항목 import 순서가 실제 캡처 순서와 달라짐 | payload.createdAt 기준 안정 정렬; 동일 시간은 UUID tie-break | S | 확인됨 |
| REL-005 | 공유 큐 항목/용량/수명 상한 없음 | Reliability/Storage | High | P1 | SharedClipQueue.swift | 앱을 오래 열지 않거나 실패가 반복되면 App Group이 무한 증가 | queue max count/bytes/TTL, oldest-first cleanup, 사용자 경고 | M | 확인됨 |
| REL-006 | import 후 queue 삭제 실패를 무시 | Reliability | Medium | P2 | AppStore.swift:importSharedClips | 동일 항목이 다음 실행에 다시 import되거나 고아 파일이 남음 | idempotency key와 committed marker; remove 실패 기록·재시도 | M | 확인됨 |
| REL-007 | 빠른 저장 성공 뒤 고정 2초 대기 | UX/Performance | Low | P2 | ShareViewController.swift quick success | 빠른 캡처 약속과 달리 호스트 복귀가 느림 | 0.4–0.8초 접근 가능한 confirmation 또는 즉시 complete + haptic | S | 확인됨 |
| REL-008 | try?로 파일·provider 오류를 광범위하게 삼킴 | Reliability/Maintainability | High | P1 | AppStore.swift, SharedClipQueue.swift, ShareViewController.swift | 원인·빈도·복구 경로를 잃고 false-success 발생 | typed errors, OSLog privacy annotations, 사용자 오류 상태, failure analytics opt-in | M | 확인됨 |
| REL-009 | 크래시/성능 진단 기준 없음 | Operations | Medium | P2 | Repository-wide | 출시 후 extension 종료·데이터 실패를 재현하기 어려움 | 개인정보 최소화된 crash reporter 선택 또는 MetricKit/OSLog 수집 절차 | M | 확인됨 |
| REL-010 | 지원 이메일·개인정보/지원 URL이 placeholder | Release | Critical | P0 | docs/app-store/*, docs/TASKS.md | App Store 메타데이터·앱 내 정책 링크 요건 미충족 | 소유 HTTPS 페이지·모니터링 메일 배포 후 앱/metadata에서 실제 링크 확인 | S | 확인됨 |
| REL-011 | 개발팀 ID가 project.yml에 하드코딩 | Release/Configuration | Medium | P1 | ios/project.yml | fork/CI/release 팀에서 signing 재현성이 낮고 개인 설정이 소스에 결합 | xcconfig/local override, CI secret/keychain, CODE_SIGN_STYLE 분리 | S | 확인됨 |
| REL-012 | Debug/Staging/Release 환경·기능 플래그 분리 부족 | Release/Architecture | Medium | P1 | ios/project.yml | 테스트 데이터·로그·정책 URL을 안전하게 분리하기 어려움 | xcconfig 3종, bundle suffix, compile flags, environment struct | M | 확인됨 |
| REL-013 | 릴리스·태그·TestFlight 증거 없음 | Release | High | P1 | GitHub repository | 재현 가능한 배포 이력·rollback 기준이 없음 | semantic version tags, signed release notes, TestFlight gate, archive retention | M | 확인됨 |
| REL-014 | 배포 전 실기기·signed archive 작업이 미완료 | Release | Critical | P0 | docs/TASKS.md/release checklist | App Group·Face ID·privacy manifest·extension embed가 배포 서명에서 깨질 수 있음 | release team으로 archive/export/install 후 physical matrix 통과 | L | 확인됨 |
| REL-015 | App Store Connect 자산·privacy answers 미완료 | Release | Critical | P0 | docs/TASKS.md, docs/app-store | 제출 자체가 불가능하거나 메타데이터 부정확으로 거절 | 실제 스크린샷·설명·심사 노트·privacy answers·export compliance 완료 | M | 확인됨 |
| REL-016 | Android/웹 제품 구현 없음 | Strategy | Low | P4 | Repository-wide | 크로스플랫폼 사용자에는 가치 제한; 단 현재 iOS 집중 전략에는 정상 | iOS PMF 확인 전 추가 플랫폼 금지; 후속 Mac/Android 수요 검증 | XL | 확인됨 |
| REL-017 | iOS 17 최소 지원으로 시장 범위 제한 | Strategy | Low | P3 | ios/project.yml | 구형 기기 사용자는 설치 불가 | 기능 의존성 분석 후 iOS 16 하향 비용 대비 도달률 검토 | M | 확인됨 |
| SEC-001 | 생체인증 불가 시 앱 잠금 fail-open | Security/Privacy | Critical | P0 | ClipInbox app lock lifecycle | 사용자가 잠겼다고 믿는 민감 클립이 인증 없이 노출 | 잠금 설정 시 capability 확인; 불가/오류는 잠금 유지; recovery 정책 명시 | M | 확인됨 |
| SEC-002 | 앱 전환기 privacy shield/redaction 없음 | Security/Privacy | High | P1 | ClipInboxApp/AppLockView lifecycle | 백그라운드 스냅샷에 최근 클립·이미지가 노출될 수 있음 | scenePhase inactive부터 opaque privacy cover, screenshot-sensitive setting | S | 확인됨 |
| SEC-003 | 앱 잠금이 저장 데이터 암호화처럼 오해될 수 있음 | Security/UX | Medium | P1 | Settings copy/marketing | 백업·파일 접근 공격에 대한 과도한 안전 기대 | “화면 접근 잠금”으로 표현; NSFileProtectionComplete 및 선택적 encrypted vault 검토 | S | 추정 |
| SEC-004 | 주 Application Support JSON의 명시적 file protection 없음 | Security/Privacy | High | P1 | AppStore.swift:persist | 기기 잠금 중 파일 보호 수준이 의도와 다를 수 있음 | 파일 생성 후 .protectionKey=.completeUntilFirstUserAuthentication 또는 요구 수준 결정·테스트 | M | 확인됨 |
| SEC-005 | 공유 설정 저장 실패를 보고하지 않음 | Security/Reliability | Medium | P1 | SharedClipQueue.swift:saveConfiguration | 앱 설정과 Share Extension 동작이 달라져 잠금/테마/저장 방식 기대가 깨짐 | saveConfiguration throws; UI rollback 또는 재시도; config version/checksum | S | 확인됨 |
| SEC-006 | 평문 JSON 내보내기 위험 안내 부족 | Security/Privacy | Medium | P1 | Import/Export UI | 공유 대상·파일 앱·클라우드에 민감 콘텐츠가 평문으로 남음 | export 전 경고, 암호화 ZIP/암호 옵션, share completion 후 temp cleanup | M | 확인됨 |
| SEC-007 | 직접 링크 열기가 기본이며 피싱/추적 URL 경고가 약함 | Security/UX | Medium | P2 | LinkOpenMode/default preferences | 저장된 악성·추적 링크를 실수로 열 수 있음 | 도메인 표시 강화, suspicious scheme/domain check, 사용자 선택 보존 | S | 확인됨 |
| SEC-008 | Privacy Manifest/Required Reason API 최종 archive 검증 미완료 | Security/Release | High | P0 | PrivacyInfo.xcprivacy + archive | manifest 누락·서드파티 집계 오류 시 제출 실패 | Xcode archive privacy report, validate app, App Store upload preflight 자동화 | M | 검증 필요 |
| SEC-009 | 민감정보 보존/자동 삭제 정책 없음 | Security/Product | Medium | P2 | Settings/Capture flow | OTP·계정정보·개인 사진을 장기 저장할 수 있음 | 패턴 감지 opt-in, 앱별/타입별 제외, 1일/7일 자동 삭제, private folder | L | 기능 제안 |
| SEC-010 | SECURITY.md 및 취약점 신고 채널 없음 | Security/Documentation | Low | P2 | Repository root | 공개 저장소에서 안전한 신고·지원 범위가 불명확 | SECURITY.md, supported versions, private reporting 안내 | S | 확인됨 |
| UX-001 | 중앙 추가 CTA가 하드코딩 샘플 클립을 생성 | UX/Functionality | Critical | P0 | AppStore.swift:saveNewClip + Add UI | 핵심 기능이 가짜 데이터 생성이며 사용자 신뢰·App Review 최소 기능성 위험 | URL/텍스트/이미지/메모 입력 폼 구현 또는 탭을 Share Guide로 명확히 변경 | M | 확인됨 |
| UX-002 | 첫 실행 Share Extension 온보딩 부재 | UX/Product | High | P1 | Onboarding flow absent | 사용자가 앱의 핵심 캡처 방법과 Favorites 설정을 발견하기 어려움 | 3단계 온보딩, 실제 공유 연습, quick/review 설명, skip/revisit | M | 확인됨 |
| UX-003 | 샘플 데이터와 사용자 데이터의 구분이 없음 | UX/Data | High | P1 | DefaultData + Inbox | 첫 실행·손상 복구 상황에서 샘플을 실제 저장물로 오해 | 명시적 demo badge/seed choice; production 기본은 진짜 empty state | S | 확인됨 |
| UX-004 | 빈 상태가 핵심 행동을 안내하지 않음 | UX | High | P1 | Inbox empty state | 새 사용자가 무엇을 공유해야 하는지 모르고 이탈 | Share Sheet 추가 방법, 수동 추가 CTA, 샘플 1개 선택적 제공 | S | 추정 |
| UX-005 | 삭제 직후 Undo와 휴지통 없음 | UX/Data | High | P1 | Clip actions | 모바일 오터치가 즉시 영구 손실로 이어짐 | snackbar Undo + Trash tab/filter + retention | M | 확인됨 |
| UX-006 | 빠른 저장/검토 저장 모드의 차이 발견성 부족 | UX | Medium | P1 | Settings + Share Extension | 사용자가 어디서 메모·폴더를 입력할 수 있는지 이해하기 어려움 | 설정 preview, 첫 공유 시 mode coachmark, extension 내 switch link | S | 추정 |
| UX-007 | 즐겨찾기의 목적·진입점이 약함 | UX/Product | Medium | P2 | Bookmark mutation/filters | 중요 항목을 고정했지만 다시 찾는 직접 경로가 부족 | 상단 Saved/Pinned smart view, row affordance, 검색 scope | S | 확인됨 |
| UX-008 | 검색이 단순 substring 중심 | UX/Product | Medium | P2 | AppStore.swift search | 오타·어간·도메인·날짜·타입 조합 검색이 어려움 | tokenized normalized index, filters, search suggestions, Spotlight 연동 | L | 확인됨 |
| UX-009 | Sort Later가 한 항목씩만 처리 | UX/Product | Medium | P2 | Sort Later workflow | 대량 인박스 정리에 반복 탭이 많고 피로함 | swipe triage, batch select, smart suggestions, keyboard shortcuts(iPad/Mac) | L | 확인됨 |
| UX-010 | 전체 화면 이미지 확대 후 pan/회전 경험 미완성 | UX | Medium | P2 | Image viewer | 확대된 이미지의 원하는 영역을 탐색하기 어려움 | UIScrollView zoom wrapper 또는 Magnify+Drag+double-tap focus, reset controls | M | 확인됨 |
| UX-011 | 저장 공간 사용량·정리 시뮬레이션 없음 | UX/Storage | High | P1 | SettingsView.swift | 원본 이미지가 얼마나 공간을 쓰는지 알 수 없음 | 총량/항목별 표시, 큰 파일 정렬, cleanup preview, export-before-delete | M | 확인됨 |
| UX-012 | 제품 명칭이 자동 클립보드 수집으로 오해될 수 있음 | Product/Marketing | High | P1 | Name/ASO copy | 기대 불일치·개인정보 우려·낮은 리뷰 가능 | 서브타이틀과 온보딩에서 “공유해 저장하는 로컬 인박스”를 전면화 | S | 추정 |
| UX-013 | iPad에서 phone-like 단일 컬럼 가능성 | UX/Responsive | Medium | P2 | Root navigation/screens | 넓은 화면 활용이 낮고 상세 이동 반복 | NavigationSplitView, sidebar smart lists, multi-select | L | 검증 필요 |
| UX-014 | 명시적 로딩·복구·오류 상태가 부족 | UX/Reliability | High | P1 | Store bootstrap/import/export/share import | 문제 발생 시 침묵하거나 성공처럼 보여 사용자가 대응할 수 없음 | state machine: loading/ready/degraded/recovery/failed; actionable error copy | M | 확인됨 |
| UX-015 | 폴더·태그·상단 필터 개념이 중첩 | UX/Information Architecture | Medium | P2 | Inbox/Folders/Settings | 어디에 분류해야 하는지 학습 비용 증가 | Folder=위치, Tag=속성, Smart filter=뷰로 명확히 구분·명칭 통일 | M | 추정 |
| UI-001 | 고정 custom font size로 Dynamic Type 미지원 | Accessibility/UI | High | P0/P1 | Design tokens/Components.swift/screens | 큰 글자 사용자에게 잘림·축소·읽기 곤란 | UIFontMetrics 또는 Font.custom(..., relativeTo:), semantic text styles, XXL snapshot tests | L | 확인됨 |
| UI-002 | 40pt chip 등 최소 터치 영역 부족 | Accessibility/UI | High | P1 | Design tokens/selection chips | 운동·시각 장애 및 일반 오터치 증가 | 모든 interactive hit frame 최소 44x44, contentShape, spacing 재조정 | S | 확인됨 |
| UI-003 | 2행×5열 고정 선택기가 번역·큰 글자에 비적응 | Accessibility/UI | High | P1 | Components.swift:TwoRowHorizontalSelection | 영어·일본어·AX 글자에서 축소·잘림·인지 저하 | adaptive LazyVGrid 또는 horizontal chips; 줄바꿈·scroll 지원 | M | 확인됨 |
| UI-004 | 행·미디어·에디터 높이가 고정 | Accessibility/UI | High | P1 | Clip rows/detail screen | Dynamic Type와 긴 메모에서 콘텐츠가 잘리거나 과도한 축소 | minHeight, ViewThatFits, scrollable sections, sizeCategory 조건 레이아웃 | M | 확인됨 |
| UI-005 | 색 대비 측정 증거 없음 | Accessibility/UI | Medium | P1 | Color tokens/light/dark themes | tertiary gray·yellow 조합이 WCAG 대비에 미달할 수 있음 | 모든 text/icon/background pair 자동 contrast audit, high-contrast variant | S | 검증 필요 |
| UI-006 | 커스텀 leading-edge back gesture | UI/Accessibility | Medium | P2 | Navigation helpers | 시스템 제스처·ScrollView·VoiceOver와 충돌 가능 | NavigationStack/native toolbar/back swipe 우선, 꼭 필요할 때만 constrained gesture | M | 확인됨 |
| UI-007 | 커스텀 키보드 dismiss recognizer 복잡성 | UI/Maintainability | Low | P3 | Keyboard dismissal helper | 제스처 우선순위·시트·접근성에 예기치 않은 부작용 | scrollDismissesKeyboard, FocusState, toolbar Done 등 네이티브 API로 단순화 | S | 확인됨 |
| UI-008 | 이미지 접근성 라벨 일부 하드코딩 한국어 | Accessibility/I18N | Medium | P1 | Image viewer/components | 영어·일본어 VoiceOver 사용자에게 잘못된 언어가 읽힘 | L10n key 및 clip title/type/context를 결합한 label/hint | S | 확인됨 |
| UI-009 | 커스텀 버튼·토글·상태의 접근성 의미론 불완전 | Accessibility | High | P1 | ShareViewController custom UI, SwiftUI components | VoiceOver 순서·selected state·저장 성공 공지가 불명확 | accessibilityLabel/Value/Traits, sortPriority, screenChanged/announcement | M | 추정 |
| UI-010 | 상태 변화가 토스트에 과의존 | UI/UX | Medium | P2 | AppStore toast/UI | VoiceOver가 놓치고 실패·undo 같은 행동이 지속되지 않음 | accessible banner/snackbar, inline error, persistent recovery center | M | 확인됨 |
| ARCH-001 | AppStore가 662줄의 God object | Architecture/Maintainability | High | P1 | ios/ClipInbox/Store/AppStore.swift | 상태·검증·저장·import·공유 큐·설정이 결합돼 회귀와 테스트 비용 증가 | Repository/UseCase/ImportExport/Search/Preferences 서비스로 단계 분리 | L | 확인됨 |
| ARCH-002 | UI 상태와 비즈니스 로직·파일 I/O 결합 | Architecture | High | P1 | AppStore + Views | UI thread 블로킹·rollback·headless 테스트가 어려움 | @MainActor view model은 presentation만; actor repository에서 async transactions | L | 확인됨 |
| ARCH-003 | 도메인 상태를 문자열로 표현 | Architecture/Type Safety | Medium | P1 | Preferences/Shared config/models | 오타·번역 변경·불가능 상태가 컴파일 시 방지되지 않음 | Codable enum + stable raw value + migration | M | 확인됨 |
| ARCH-004 | App Group·bundle/team 식별자 하드코딩 | Architecture/Configuration | Medium | P1 | SharedClipQueue.swift, project.yml | 환경·팀·테스트 컨테이너 전환이 어렵고 테스트 격리 불량 | BuildSettings generated config 또는 Info.plist key injection | S | 확인됨 |
| ARCH-005 | 저장소 추상화와 failure injection 지점 부족 | Architecture/Testability | High | P1 | AppStore.swift direct FileManager/Data | disk full·permission·corruption 테스트가 어려움 | ClipRepository/FileSystem/Clock/IDGenerator protocols와 in-memory/failing fakes | M | 확인됨 |
| ARCH-006 | 파일 I/O가 main execution path에서 동기 실행 | Architecture/Performance | High | P1 | AppStore.swift:persist/import | 대형 데이터에서 frame drop·watchdog 위험 | StorageActor, async methods, loading state, coalesced writes | M | 추정 |
| ARCH-007 | 웹 프로토타입과 제품 코드가 같은 루트에 있어 혼동 | Architecture/Documentation | Medium | P2 | src/, public/, ios/ | 신규 기여자가 잘못된 구현을 수정하거나 QA 대상을 혼동 | archive/prototype 하위 이동 또는 root README에 source-of-truth diagram | S | 확인됨 |
| ARCH-008 | 이미지 자산 생명주기와 clip transaction 분리 | Architecture/Data | High | P1 | SharedClipQueue + AppStore | clip commit/삭제와 이미지 이동·삭제가 부분 실패할 수 있음 | two-phase asset transaction, ref count, orphan reconciliation | L | 확인됨 |
| PERF-001 | 선형 in-memory 검색 | Performance | Medium | P2 | AppStore search/filter | 수천 항목에서 입력 지연, 메모리 상주 비용 증가 | SQLite FTS/normalized inverted index, debounce, incremental results | L | 확인됨 |
| PERF-002 | 썸네일에서 원본 이미지를 전체 디코딩할 가능성 | Performance/Memory | High | P1 | Image loading components | 고해상도 사진 목록 스크롤 시 memory spike·jank | CGImageSource thumbnail downsample, target pixel size, async decode/cache | M | 추정 |
| PERF-003 | 이미지 cache cost limit 불명확 | Performance/Memory | Medium | P1 | Image cache helper | OS 압박 전까지 decoded bitmap이 과도하게 남을 수 있음 | NSCache totalCostLimit/countLimit, cost=pixel bytes, memory warning purge | S | 검증 필요 |
| PERF-004 | prettyPrinted JSON으로 저장 크기·쓰기 비용 증가 | Performance | Low | P2 | AppStore.swift:persist | 모바일 내부 저장에는 가독성 이득 없이 I/O 증가 | 내부 스냅샷은 compact; export만 prettyPrinted | S | 확인됨 |
| PERF-005 | 성능 예산·대규모 데이터 기준 없음 | Performance/QA | Medium | P1 | docs/tests | “몇 개까지 빠른가”를 출시 전에 판단할 근거가 없음 | cold launch/search/scroll/share memory budgets와 signpost/MetricKit 측정 | M | 확인됨 |
| TEST-001 | GitHub Actions/CI 워크플로 부재 | Testing/Release | High | P0/P1 | .github/workflows 없음 | 빌드·테스트·manifest·project drift 회귀가 PR에 합쳐질 수 있음 | macOS runner build+test+lint+privacy+artifact workflow; branch protection | M | 확인됨 |
| TEST-002 | 저장 실패·disk full·permission 회귀 테스트 부재 | Testing/Reliability | Critical | P0 | ClipInboxTests/AppStoreTests.swift | 가장 위험한 false-success가 자동 검출되지 않음 | failing repository/file system으로 모든 mutation rollback contract 테스트 | M | 확인됨 |
| TEST-003 | 손상 스냅샷·migration·unsupported version 테스트 부재 | Testing/Data | Critical | P0 | ClipInboxTests | 업데이트 시 데이터 손실 회귀를 차단하지 못함 | golden fixtures, corrupt/truncated/checksum/future-version matrix | M | 확인됨 |
| TEST-004 | Share Extension 실제 E2E·대형 이미지 자동 테스트 부재 | Testing/Reliability | High | P0/P1 | ClipShareExtension | provider·App Group·host별 차이를 단위 테스트로 잡지 못함 | XCUITest host harness + manual release matrix + memory benchmarks | L | 확인됨 |
| TEST-005 | UI/접근성 snapshot·VoiceOver 테스트 부재 | Testing/Accessibility | High | P1 | UI tests absent | Dynamic Type·번역·다크 모드 회귀가 시각 QA에 의존 | XCUITest accessibility audit, snapshot matrix, localization pseudo-language | L | 확인됨 |
| TEST-006 | 성능·메모리·대량 데이터 테스트 부재 | Testing/Performance | Medium | P1 | Tests | 전체 JSON/이미지 설계의 확장 한계를 모름 | XCTest measure, XCTMemoryMetric, signposts, 100/1k/5k/10k fixtures | M | 확인됨 |
| TEST-007 | 물리 기기 release matrix 미완료 | Testing/Release | Critical | P0 | docs/TASKS.md | Face ID·App Group·Photos provider·file protection 차이를 미검증 | 최소 2개 OS/2개 기기/iPad에서 signed release build 체크리스트 | L | 확인됨 |
| TEST-008 | archive/Privacy Report/extension embedding 자동 게이트 부재 | Testing/Release | High | P0 | Release pipeline | Debug simulator 성공과 배포 바이너리 성공이 분리됨 | CI archive 또는 release candidate archive 검증 스크립트 | M | 확인됨 |
| DOC-001 | 루트 README 부재 | Documentation/DX | Medium | P1 | Repository root | 제품·빌드·source-of-truth·privacy·스크린샷을 외부가 파악하기 어려움 | README with product, setup, architecture, tests, release, status, limitations | S | 확인됨 |
| DOC-002 | 저장소 LICENSE 부재 | Legal/Documentation | High | P1 | Repository root | 공개 코드 재사용·기여·상업 사용 권리가 불명확 | 권리자 의도에 맞는 LICENSE 추가; 폰트·이미지 third-party notices 분리 | S | 확인됨 |
| DOC-003 | CONTRIBUTING/CODE_OF_CONDUCT/PR template 부재 | Documentation/DX | Low | P3 | Repository root/.github | 협업 규칙·검증 방법이 사람 기억에 의존 | 기여 가이드, issue/PR templates, commit/release conventions | S | 확인됨 |
| DOC-004 | 운영·복구 runbook 부재 | Documentation/Operations | Medium | P1 | docs/ | 데이터 손상·App Group·스토어 거절 상황 대응이 느림 | corruption recovery, signing, queue cleanup, rollback, privacy incident runbooks | M | 확인됨 |
| LEGAL-001 | 개인정보 처리방침 초안의 실소유 연락처·게시 URL 미완료 | Legal/Release | Critical | P0 | docs/app-store privacy draft | 제출 요건과 사용자 문의·삭제/내보내기 권리 안내 미충족 | 관할·연락처·보존·export·백업·문의 절차를 검토 후 HTTPS 게시 | M | 확인됨 |
| LEGAL-002 | 폰트·이미지·프로토타입 자산 라이선스 인벤토리 부족 | Legal | Medium | P1 | Fonts/public/Reference | 스토어 배포 권리·고지 의무가 불분명할 수 있음 | THIRD_PARTY_NOTICES, asset source/proof, build-time license report | M | 검증 필요 |
| LEGAL-003 | “데이터 미수집” 답변의 release SDK 기준 검증 필요 | Legal/Privacy | High | P0 | App Store privacy answers | 향후 crash/analytics SDK 추가 시 선언과 실제가 어긋날 수 있음 | release binary network/SDK audit; 수집 없음 유지 또는 정확한 disclosure | M | 검증 필요 |
| FEATURE-001 | 실제 수동 캡처 폼 | Feature | High | P0 | Add tab | 공유 시트를 쓰기 어려운 상황에서도 핵심 기능 완결 | URL paste, text, memo, PhotosPicker, duplicate preview | M | 기능 제안 |
| FEATURE-002 | 휴지통·Undo·복원 | Feature | High | P1 | Data/UI | 개인 데이터 신뢰와 오조작 복구 | soft-delete model, trash smart list, retention | M | 기능 제안 |
| FEATURE-003 | 중복 감지 및 병합 | Feature | Medium | P2 | Capture/Search | 노이즈·저장 공간 절감 | URL canonicalization, text SHA-256, image pHash | L | 기능 제안 |
| FEATURE-004 | 온디바이스 OCR·스마트 액션 | Feature | Medium | P3 | Image/detail | 이미지 안 텍스트 재검색과 전화/주소/코드 행동 제공 | Vision framework opt-in index; 원본 외부 전송 없음 | L | 기능 제안 |
| FEATURE-005 | Shortcuts·Spotlight·Widget | Feature | Medium | P3 | Platform integration | 빠른 재검색·저장·자동화로 파워유저 가치 상승 | App Intents, Core Spotlight, widgets; privacy scope 명시 | XL | 기능 제안 |
| FEATURE-006 | 선택적 iCloud 동기화 | Feature | Medium | P3 | Data architecture | 기기 변경·다중 Apple 기기 연속성 | local-only default, CloudKit opt-in, conflict log, E2E expectations 명시 | XL | 기능 제안 |


## Top 10 실행 순서

1. `DATA-001`, `DATA-012`, `TEST-003`: 손상 감지·격리·백업 복구와 fixture 테스트를 한 작업 묶음으로 처리한다.
2. `DATA-002`, `TEST-002`, `ARCH-005`: 모든 mutation을 성공/실패 계약이 있는 repository transaction으로 바꾼다.
3. `REL-001`, `REL-002`, `TEST-004`: Share Extension 이미지 입력의 바이트·픽셀·시간 제한과 실기기 메모리 테스트를 추가한다.
4. `SEC-001`, `SEC-002`: 잠금 fail-closed와 app switcher shield를 적용한다.
5. `UX-001`, `FEATURE-001`: 데모 Add를 실제 캡처 폼으로 교체한다.
6. `DATA-003`: schema migrator와 unsupported-version UX를 도입한다.
7. `UI-001`~`UI-004`, `TEST-005`: Dynamic Type·터치 영역·적응형 레이아웃을 테스트와 함께 수정한다.
8. `TEST-001`, `TEST-008`: PR CI와 release archive gate를 만든다.
9. `REL-010`, `REL-014`, `REL-015`, `LEGAL-001`, `LEGAL-003`: 실소유 정책 페이지·서명·스토어 자료를 완료한다.
10. `DATA-009`, `FEATURE-002`, `UX-011`: 휴지통과 저장 공간 관리로 사용자 신뢰를 완성한다.

## 완료 정의

각 이슈는 코드가 merge되었다는 이유만으로 완료되지 않는다. 관련 자동 테스트, 실패 UI, 문서, 개인정보/접근성 검증, 배포 빌드 검증 중 해당되는 항목이 모두 충족돼야 한다. P0의 경우 실제 Release configuration 또는 signed archive에서 재현 가능한 증거를 남긴다.
