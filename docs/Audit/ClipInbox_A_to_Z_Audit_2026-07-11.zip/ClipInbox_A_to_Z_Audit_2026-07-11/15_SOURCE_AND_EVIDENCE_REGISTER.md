# Source & Evidence Register

## 1. 감사 시점과 신뢰 등급

- 기준일: 2026-07-11
- 저장소: `https://github.com/eiranotes/ClipInbox`, public `main`
- A등급: 공개 소스 코드·project setting에서 직접 확인
- B등급: 저장소 내부 문서·작성자 QA evidence에서 확인했으나 독립 실행하지 못함
- C등급: 정적 제어 흐름·UI evidence를 바탕으로 한 합리적 추정
- D등급: macOS/Xcode·실기기·signed archive·App Store Connect 검증 필요

## 2. 저장소 핵심 근거

| 근거 | 등급 | 사용한 판단 |
|---|---|---|
| `AGENTS.md` | A | `ios/`가 production source of truth, 루트 web은 historical prototype |
| `ios/project.yml` | A | iOS 17, Swift 5.10, version 0.3.0, app/share/test targets, bundle IDs, App Group/signing 설정 |
| `ios/ClipInbox/Store/AppStore.swift` | A | snapshot load/save, mutation, import/export, queue import, demo Add, false-success |
| `ios/ClipInbox/Models/Models.swift` | A | `DataSnapshot.version`, localized preferences, Int ID, String time, DefaultData |
| `ios/ClipInbox/Shared/SharedClipQueue.swift` | A | per-item queue, file protection, UUID image validation, silent corrupt skip, ordering/quota |
| `ios/ClipShareExtension/ShareViewController.swift` | A | provider loading, full Data/UIImage paths, Quick/Review, no timeout |
| `ios/ClipInboxTests/AppStoreTests.swift` | A | 현재 unit-test 범위와 failure/migration/E2E 공백 |
| `docs/TASKS.md` | B | date model, Face ID physical test, release signing, support/privacy URL, App Store tasks가 deferred |
| `docs/app-store/*` | B | ASO copy, privacy draft, screenshot/release checklist, placeholder contacts |
| `.superloopy/evidence/ios/*` | B | simulator build, extension embedding, App Group, Safari/Photos flow의 저장소 작성자 증거 |
| UI evidence screenshots | B/C | list-first Inbox, dark settings/folders, lock, Share Extension, image viewer 시각 감사 |
| GitHub repository root | A | 9 commits, no release, no root README/LICENSE visible, no description/topics |

## 3. 독립 검증하지 못한 항목

- XcodeGen project generation
- Xcode build/XCTest
- simulator interaction
- physical iPhone/iPad behavior
- Face ID/Touch ID/passcode combinations
- Release Distribution signing and App Group profile
- Instruments memory/CPU/battery
- App Store archive/privacy report/validation
- App Store Connect metadata and privacy answers
- file-system protection attributes on installed build
- actual outbound network behavior

저장소 내부에서 “passed”라고 기록된 항목은 본 보고서에서 B등급으로 구분했으며, 최종 출시 gate에서는 다시 실행해야 한다.

## 4. Apple 공식 자료

조사일 이후 내용이 바뀔 수 있으므로 제출 직전에 다시 확인한다.

- App Review Guidelines: https://developer.apple.com/app-store/review/guidelines/
- App privacy details overview: https://developer.apple.com/app-store/app-privacy-details/
- Privacy manifest files: https://developer.apple.com/documentation/bundleresources/privacy_manifest_files
- Required Reason APIs: https://developer.apple.com/documentation/bundleresources/privacy_manifest_files/describing_use_of_required_reason_api
- App extensions: https://developer.apple.com/app-extensions/
- Human Interface Guidelines: https://developer.apple.com/design/human-interface-guidelines/
- Accessibility: https://developer.apple.com/accessibility/
- Supporting Dynamic Type: https://developer.apple.com/documentation/uikit/scaling_fonts_automatically
- LocalAuthentication: https://developer.apple.com/documentation/localauthentication
- File protection: https://developer.apple.com/documentation/foundation/fileprotectiontype

## 5. 경쟁 제품 공식 자료

- Paste: https://pasteapp.io/
- PastePal: https://indiegoodies.com/pastepal
- Maccy: https://maccy.app/
- Pastery: https://pastery.app/
- Anybox: https://anybox.app/
- GoodLinks: https://goodlinks.app/
- Raindrop Pro: https://raindrop.io/pro/buy
- Readwise pricing: https://readwise.io/pricing
- mymind pricing: https://mymind.com/pricing

가격·기능·플랫폼은 지역/시점에 따라 변할 수 있다. 보고서의 가격은 2026-07-11 조사 스냅샷이며 구매 의사결정 전에 공식 결제 화면에서 재확인한다.

## 6. 분석 표식

- `[확인됨]`: A등급 코드/설정 또는 명시 문서로 직접 확인
- `[추정]`: C등급 정적 분석, 실행 검증 필요 가능
- `[검증 필요]`: D등급 환경/계정/실기기 요구
- `[중대 위험]`: 데이터 유실·노출·앱 실행/심사 실패에 직접 연결
- `[개선 권장]`: 출시 차단은 아니나 품질·유지보수 개선
- `[기능 제안]`: 현재 구현 사실이 아닌 후속 제품 제안

## 7. 재현 권장 명령

macOS/Xcode가 있는 clean runner에서 저장소 지침을 일반화해 수행한다.

```bash
cd ios
xcodegen generate --spec project.yml
xcodebuild \
  -project ClipInbox.xcodeproj \
  -scheme ClipInbox \
  -configuration Debug \
  -destination 'platform=iOS Simulator,name=iPhone 17 Pro' \
  -derivedDataPath .build/DerivedData \
  COMPILER_INDEX_STORE_ENABLE=NO \
  build test
```

실제 simulator 이름은 설치된 runtime에 맞춰 선택한다. Release candidate에서는 `archive`, entitlements inspection, privacy report, TestFlight signed install을 별도 수행한다.
