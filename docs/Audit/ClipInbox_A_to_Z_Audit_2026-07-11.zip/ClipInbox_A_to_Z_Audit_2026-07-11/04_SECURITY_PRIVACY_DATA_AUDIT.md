# Security, Privacy & Data Audit

## 1. 범위와 기준

- 로컬 저장, App Group, Share Extension, JSON import/export, 외부 링크, 앱 잠금, 로그, privacy manifest를 검토했다.
- OWASP MASVS의 Storage, Privacy, Platform, Code, Resilience 관점과 Apple 플랫폼 정책을 적용했다.
- `[검증 필요]` binary-level secret scan, network capture, file protection inspection, jailbroken-device behavior, signed archive privacy report는 checkout·실기기·배포 계정이 필요하다.

## 2. 보안/개인정보 요약

### 강점

- `[확인됨]` 계정·서버·광고·트래킹 SDK가 보이지 않는다.
- `[확인됨]` 기본 기능은 오프라인 로컬 동작이다.
- `[확인됨]` Share queue와 이미지에 atomic write 및 `.completeFileProtectionUnlessOpen`을 사용한다.
- `[확인됨]` App Group 이미지 파일명은 UUID와 허용 확장자로 제한해 경로 조작을 방어한다.
- `[확인됨]` 외부 URL은 http/https로 정규화한다.
- `[확인됨]` 입력 문자열 길이, 태그 수, suggestion 수 등에 일부 상한이 있다.
- `[확인됨]` main app과 extension에 privacy manifest 파일이 마련돼 있다.

### 핵심 위험

1. 앱 잠금이 인증 capability 오류에서 fail-open한다.
2. app switcher snapshot privacy shield가 없다.
3. 주 JSON 파일 보호 수준을 명시하지 않는다.
4. 데이터 손상을 샘플로 대체하고 저장 실패를 성공처럼 표시한다.
5. Share Extension 이미지에 용량·픽셀·시간 제한이 없다.
6. JSON export가 평문이고 보호 범위·누락 범위 고지가 약하다.
7. queue corruption과 orphan 자산이 조용히 쌓일 수 있다.
8. release archive 기준 privacy manifest와 “Data Not Collected” 답변을 검증하지 않았다.

## 3. 보호 자산

| 자산 | 민감도 | 위치 | 현재 보호 | 주요 위험 |
|---|---:|---|---|---|
| URL·텍스트·메모 | 높음 | Application Support JSON | 앱 sandbox, atomic write | 명시적 file protection 없음, corruption fallback |
| 이미지 원본 | 매우 높음 | App Group images | UUID filename, image validation, file protection | 무제한 보존, extension memory, app group 접근 |
| pending share payload | 높음 | App Group pending JSON | per-file atomic/protected | corrupt item 방치, queue quota 없음 |
| 폴더·태그 | 중간 | main snapshot/UserDefaults | sandbox | backup 범위 불일치 |
| 잠금 설정 | 높음 | Preferences/Shared config | sandbox/App Group | localized string, config save failure |
| 최근 검색 | 높음 | UserDefaults | sandbox | export/삭제 범위 인지 부족 |
| backup/export | 매우 높음 | temporary/file provider/cloud | 사용자 선택 위치 | 평문, 사본 잔류, 범위 불명확 |
| signing/App Group identifiers | 중간 | project.yml/entitlements | 공개 설정 | team ID 결합, release profile mismatch |

## 4. 위협 모델

| 자산 | 위협 행위자 | 공격/실패 경로 | 영향 | 현재 방어 | 권장 방어 |
|---|---|---|---|---|---|
| 모든 클립 | 기기 일시 접근자 | 잠금 capability 실패, 앱 전환기 preview | 민감 정보 노출 | LocalAuthentication UI | fail-closed, inactive shield, lock timeout |
| 주 JSON | 파일 손상/OS/사용자 | truncated file, disk full, future schema | 데이터 유실·샘플로 위장 | atomic write | rotating backup, checksum, migration, recovery UI |
| 공유 이미지 | 악의적/비정상 provider | 초대형 이미지·decompression bomb | extension OOM/DoS | ImageIO validation | byte/pixel cap, metadata-only inspect, downsample, timeout |
| queue | 손상 파일/중단 | decode failure, remove failure | 반복/누락·storage leak | per-item files | quarantine, idempotency, TTL, reconciliation |
| export | 다른 앱/클라우드/오공유 | 평문 JSON 공유 | 영구 외부 유출 | 사용자 명시 share | warning, encrypted archive, temp cleanup |
| 외부 링크 | 피싱 사이트 | direct-open saved URL | 추적/피싱 | http/https 제한 | domain emphasis, confirmation/suspicion heuristics |
| App Group | signing misconfig | 잘못된 entitlement/profile | 저장 실패·데이터 단절 | static identifiers | release archive entitlement validation |
| 설정 | 파일 write 실패 | app/extension config 불일치 | 사용자의 저장·잠금 기대와 다른 동작 | default fallback | versioned config, throws, status indicator |
| 로그 | 개발/지원 | URL·제목·파일명이 로그에 포함 | 2차 개인정보 노출 | 일부 DEBUG 제한 | privacy redaction, synthetic diagnostics |
| 공급망 | 의존성/자산 | 악성 SDK·권리 불명확 asset | 유출·법적 위험 | 외부 runtime deps 없음 | SBOM, asset notices, release diff review |

## 5. 저장 데이터와 암호화

### 5.1 주 스냅샷

`AppStore.persist()`는 Application Support의 `clip-inbox-data.json`에 atomic write한다. atomic write는 부분 파일 방지에 유효하지만 다음을 해결하지 않는다.

- 이전 정상 파일이 이미 논리적으로 잘못된 경우
- decode 가능한 잘못된 import
- schema incompatibility
- disk full/permission과 UI rollback
- 파일 보호 수준
- 기기 백업 포함 정책

**권장 단기 설계**

```text
clip-inbox/
├── current.snapshot
├── previous.snapshot
├── recovery/
│   └── corrupt-<timestamp>.snapshot
└── manifest.json  # schema, record count, checksum, createdAt
```

1. draft encode
2. draft decode/semantic validate
3. SHA-256/checksum·record count 기록
4. current→previous rotate
5. draft→current atomic replace
6. 성공 후 상태 publish

### 5.2 파일 보호

- App Group queue/images에는 `.completeFileProtectionUnlessOpen`이 명시돼 있다.
- 주 snapshot에는 동일한 옵션 또는 file attribute가 보이지 않는다.

`[개선 권장]` 위협 모델에 따라 `NSFileProtectionCompleteUntilFirstUserAuthentication` 또는 `Complete`를 선택하고, 잠금 상태 Share Extension과 충돌하지 않는지 실기기에서 확인한다. 파일 보호는 앱 자체 암호화와 동일하지 않다.

### 5.3 선택적 암호화 vault

1.0의 필수 조건은 아니지만 “보안 폴더”를 제공한다면:

- CryptoKit AES-GCM
- 키는 Keychain, 가능하면 biometryCurrentSet/access control
- metadata leakage 범위 명시
- recovery key/기기 변경 정책 명시
- 잠금 실패 시 데이터 삭제 같은 위험 기본값 금지

단순 앱 잠금을 “암호화”라고 마케팅하지 않는다.

## 6. 앱 잠금 감사

### 현재 동작 위험

- `.deviceOwnerAuthentication`은 Face ID/Touch ID뿐 아니라 device passcode fallback을 허용한다.
- 인증 policy를 평가할 수 없을 때 콘텐츠를 잠그지 않는 fail-open 경로가 있다.
- background에서 lock하지만 inactive 시점의 system snapshot을 덮는 privacy view가 없다.
- 데이터는 이미 메모리에 있고 저장소도 별도 암호화되지 않는다.

### 요구 동작

| 상황 | 권장 상태 |
|---|---|
| 사용자가 잠금 켜기 | 먼저 capability 확인, 성공해야 설정 commit |
| Face ID/Touch ID 실패/취소 | 잠금 유지 |
| passcode 없음 | 설정 거절 또는 별도 앱 PIN recovery, 절대 자동 unlock 금지 |
| scene `.inactive` | 즉시 privacy cover |
| scene `.background` | authenticated session 만료 |
| foreground | 인증 완료 전 store view 생성/노출 금지 |
| 반복 실패 | OS policy 준수, destructive reset 금지 |
| 마케팅 | “Face ID/Touch ID/기기 암호로 화면 접근 보호”로 정확히 표현 |

## 7. Share Extension 보안·안정성

### 입력 표면

- URL/webpage
- plain text
- image providers
- temporary file URL
- arbitrary provider implementation

### 현재 방어

- activation rule로 지원 타입 범위를 제한
- safe URL 정규화
- 이미지 데이터가 ImageIO로 식별되는지 검사
- 확장자 allowlist와 UUID file name
- queue write가 실패하면 신규 이미지 정리를 시도

### 추가 방어

1. provider당 8–12초 timeout
2. 총 payload byte limit, 예: 원본 50MB 상한과 사용자 설정
3. pixel count limit, decompression bomb 방어
4. `loadFileRepresentation`/security-scoped coordinated copy 우선
5. preview용 downsample과 원본 저장을 분리
6. metadata parsing은 main thread 밖에서 수행
7. extension memory signpost와 release device threshold
8. unsupported format은 host로 돌아갈 수 있는 명확한 오류
9. queue 최대 항목·총 bytes·TTL
10. corrupt queue quarantine와 사용자 진단

## 8. Import/Export 보안

### Import

현재 5MB 파일 크기 상한은 긍정적이지만 충분하지 않다.

- supported schema version 확인
- clip/folder/tag 최대 개수
- ID uniqueness, string normalization, date range
- URL scheme/length
- image manifest path traversal
- dry-run summary: 추가/덮어쓰기/충돌 수
- merge/replace 선택
- transaction/rollback
- unknown fields를 허용하더라도 required semantics는 엄격히 검증

### Export

- 평문임을 명시한다.
- 이미지 포함/제외, 최근 검색·설정 포함 범위를 명시한다.
- 임시 export 파일은 share completion/timeout 뒤 삭제한다.
- password-encrypted archive는 선택 사항으로 제공한다.
- 사용자가 선택한 cloud/file provider로 보내는 행위와 개발자가 데이터를 수집하는 행위를 구분해 정책에 설명한다.

## 9. 네트워크·외부 링크

현재 서버가 없고 외부 SDK도 보이지 않는 점은 큰 장점이다. 그러나 release에서 다음을 확인한다.

- 링크 preview/metadata 기능을 향후 추가한다면 직접 기기 요청으로 IP가 대상 사이트에 노출될 수 있음을 설명한다.
- `UIApplication.open`은 http/https만 허용하고, 표시 domain과 실제 URL을 일치시킨다.
- URL userinfo, punycode, redirect, tracking parameters를 UI에서 명확히 표시한다.
- local-only 약속 검증을 위해 release binary를 proxy로 관찰하고 사용자 동작 없는 outbound connection 0을 기준으로 둔다.

## 10. 로그·진단·모니터링

### 금지 데이터

- 클립 본문/메모
- 전체 URL/query string
- 이미지 bytes/파일 경로
- 검색어
- 폴더·태그 이름
- export 파일명

### 허용 가능한 진단

- 익명 이벤트가 아니라도 로컬 `OSLog`의 category, error code, payload type, byte bucket, duration bucket
- 사용자가 직접 export하는 redacted diagnostics
- MetricKit의 hang/memory/crash 지표

외부 crash SDK를 추가할 경우 기본 local-only/privacy claim과 App Store privacy answer를 다시 검토한다. SDK가 없다는 사실보다 **실제 release binary가 무엇을 보내는지**가 기준이다.

## 11. Privacy Manifest와 App Store Privacy

- `[확인됨]` main app과 extension에 privacy manifest가 존재한다.
- `[검증 필요]` final archive에서 Required Reason API 사용과 선언이 정확히 일치하는지 Xcode Privacy Report로 확인해야 한다.
- `[검증 필요]` “Data Not Collected” 답변은 개발자나 제3자가 데이터를 off-device로 전송·보존하지 않는 release binary에 한해 타당하다.
- 계정이 없으므로 account deletion UI는 현재 비적용이지만, 로컬 전체 삭제·export·backup·OS backup 동작은 정책에 명확히 쓴다.
- privacy policy 링크는 App Store metadata와 앱 내부 양쪽에 실제 HTTPS URL로 제공해야 한다.

## 12. 개인정보 최소화 원칙

| 원칙 | 현재 상태 | 보완 |
|---|---|---|
| 목적 제한 | 사용자가 공유한 콘텐츠 보관 | 자동 monitoring을 추가하지 않음 |
| 최소 수집 | 서버/계정 없음 | 원본 이미지 보존을 선택 가능하게 |
| 투명성 | docs 초안 | 실제 앱 내 privacy center/URL |
| 사용자 통제 | 삭제/export 존재 | Undo, Trash, retention, encrypted export |
| 보안 | sandbox/App Group protection | main file protection, fail-closed lock |
| 보존 제한 | 없음 | 자동 삭제/queue TTL/storage cap |
| 정확성 | mutation 가능 | durable commit과 conflict validation |
| 이동성 | JSON export | versioned complete archive |

## 13. 출시 차단 / 단기 / 장기

### 출시 차단

- 손상 스냅샷 fallback
- persist false-success
- 앱 잠금 fail-open
- 대형 이미지 extension OOM 경로
- privacy/support placeholder
- signed archive/privacy manifest 검증
- 정확한 App Privacy answer

### 출시 전 권장

- app switcher shield
- main snapshot file protection
- export 경고와 temp cleanup
- queue quota/quarantine/idempotency
- redacted diagnostics
- privacy center와 storage/retention

### 장기

- encrypted private folder
- optional iCloud sync threat model
- on-device sensitive-content detection
- SBOM/attestation

## 14. 최종 보안 판정

외부 서버가 없기 때문에 전형적인 API 인증·토큰·SQL injection 위험은 작다. 그러나 이 제품의 가장 중요한 보안 속성은 **개인 데이터가 로컬에서 정확하고 예측 가능하게 보존·차단·삭제되는 것**이다. 현재는 잠금과 영속화의 fail-open/false-success 때문에 공개 출시 전 수정이 필요하다.
