#if canImport(SwiftUI)
import SwiftUI

struct MetadataRemoteImage: View {
    let url: URL
    var contentMode: ContentMode = .fill

    var body: some View {
        AsyncImage(url: url, transaction: Transaction(animation: .easeInOut(duration: 0.2))) { phase in
            switch phase {
            case .success(let image):
                image.resizable().aspectRatio(contentMode: contentMode)
            case .failure:
                placeholder(systemImage: "photo")
            case .empty:
                ZStack {
                    placeholder(systemImage: "photo")
                    ProgressView().controlSize(.small)
                }
            @unknown default:
                placeholder(systemImage: "photo")
            }
        }
        .clipped()
        .accessibilityLabel("링크 대표 이미지")
    }

    private func placeholder(systemImage: String) -> some View {
        ZStack {
            Tokens.bgCard
            Image(systemName: systemImage)
                .foregroundStyle(Tokens.textTertiary)
        }
    }
}

struct MetadataDetailSectionsView: View {
    @Environment(URLMetadataCoordinator.self) private var metadata
    @Environment(AppStore.self) private var store
    let clip: Clip

    var body: some View {
        if let result = metadata.result(for: clip.id) {
            let sections = PresentationBuilder().detailSections(from: result)
            VStack(alignment: .leading, spacing: Tokens.detailGap) {
                ForEach(sections) { section in
                    VStack(alignment: .leading, spacing: Tokens.rowGap) {
                        Text(section.title)
                            .font(Tokens.sectionTitle)
                            .foregroundStyle(Tokens.textPrimary)
                            .accessibilityAddTraits(.isHeader)
                        VStack(alignment: .leading, spacing: 0) {
                            ForEach(section.items) { item in
                                VStack(alignment: .leading, spacing: Tokens.space1) {
                                    Text(item.label)
                                        .font(Tokens.metaBold)
                                        .foregroundStyle(Tokens.textSecondary)
                                    Text(item.value)
                                        .font(Tokens.body)
                                        .foregroundStyle(Tokens.textPrimary)
                                        .textSelection(.enabled)
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.vertical, Tokens.rowGap)
                                .overlay(alignment: .bottom) {
                                    Tokens.borderSoft.frame(height: Tokens.borderChipWidth)
                                }
                            }
                        }
                    }
                }
                Button {
                    Task { await metadata.analyze(clip: clip, store: store, forceRefresh: true) }
                } label: {
                    Label("링크 정보 다시 분석", systemImage: "arrow.clockwise")
                }
                .buttonStyle(.plain)
                .font(Tokens.bodySemibold)
                .foregroundStyle(Tokens.textPrimary)
                .disabled(metadata.isAnalyzing(clip.id))
            }
        } else if metadata.isAnalyzing(clip.id) {
            HStack(spacing: Tokens.rowGap) {
                ProgressView()
                Text("링크 정보를 분석하는 중입니다")
                    .font(Tokens.meta)
                    .foregroundStyle(Tokens.textSecondary)
            }
        } else if !clip.url.isEmpty {
            Button {
                Task { await metadata.analyze(clip: clip, store: store, forceRefresh: false) }
            } label: {
                Label("링크 정보 분석", systemImage: "sparkle.magnifyingglass")
            }
            .buttonStyle(.plain)
            .font(Tokens.bodySemibold)
            .foregroundStyle(Tokens.textPrimary)
        }
    }
}
#endif
