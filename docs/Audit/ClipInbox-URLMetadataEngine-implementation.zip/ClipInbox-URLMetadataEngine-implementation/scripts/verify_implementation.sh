#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
SWIFT_JOBS="${SWIFT_JOBS:-4}"

printf '%s\n' "[verify] Swift core tests (jobs=$SWIFT_JOBS)"
swift test --jobs "$SWIFT_JOBS"

printf '%s\n' "[verify] Swift core release build (jobs=$SWIFT_JOBS)"
swift build -c release --jobs "$SWIFT_JOBS"

printf '%s\n' '[verify] iOS integration syntax parse'
swiftc -frontend -parse ios/ClipInbox/MetadataEngine/iOS/*.swift

printf '%s\n' '[verify] integration script syntax'
python3 -m py_compile scripts/apply_clipinbox_metadata_engine.py

printf '%s\n' '[verify] mock checkout application and idempotency'
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/repo/ios/ClipInbox/App" "$TMP/repo/ios/ClipInbox/Views" "$TMP/repo/ios/ClipInboxTests"
cat > "$TMP/repo/ios/project.yml" <<'YAML'
name: ClipInbox
targets:
  ClipInbox:
    type: application
    platform: iOS
    sources: [ClipInbox]
  ClipInboxTests:
    type: bundle.unit-test
    platform: iOS
    sources: [ClipInboxTests]
YAML
cat > "$TMP/repo/ios/ClipInbox/App/ClipInboxApp.swift" <<'SWIFT'
import SwiftUI

@main
struct ClipInboxApp: App {
    @Environment(\.scenePhase) private var phase
    @State private var store = AppStore()
    @State private var lock = AppLockController()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(store)
                .environment(lock)
                .onAppear {
                    store.importSharedClips()
                }
                .onChange(of: phase) { _, phase in
                    if phase == .active { store.importSharedClips() }
                }
        }
    }
}
SWIFT
cat > "$TMP/repo/ios/ClipInbox/Views/ClipCardView.swift" <<'SWIFT'
import SwiftUI

struct ClipCardView: View {
    @Environment(AppStore.self) private var store
    let clip: Clip
    var body: some View {
        VStack {
            Text(L10n.text(clip.title, locale: locale))
            Text(L10n.text(clip.source, locale: locale))
            if clip.hasImageReference {
                ClipThumbnail(clip: clip, compact: true)
                    .frame(width: Tokens.clipThumbnailWidth, height: Tokens.clipThumbnailHeight)
                    .fixedSize()
            }
        }
    }
}

struct CompactResultRow: View {
    @Environment(AppStore.self) private var store
    let clip: Clip
    var body: some View {
        HStack {
            Text(L10n.text(clip.title, locale: locale))
            Text(L10n.text(clip.source, locale: locale))
            if clip.hasImageReference {
                ClipThumbnail(clip: clip, compact: true)
                    .frame(width: Tokens.resultThumbnailWidth, height: Tokens.resultThumbnailHeight)
            }
        }
    }
}
SWIFT
cat > "$TMP/repo/ios/ClipInbox/Views/DetailView.swift" <<'SWIFT'
import SwiftUI

struct DetailView: View {
    @Environment(AppStore.self) private var store
    let clip: Clip
    @State private var noteDraft = ""
    var body: some View {
        ScrollView {
            VStack {
                Text(L10n.text(clip.title, locale: locale))
                Text(L10n.text(clip.source, locale: locale))
                if clip.hasImageReference {
                    ClipThumbnail(clip: clip)
                        .accessibilityLabel("이미지 크게 보기")
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            VStack(alignment: .leading, spacing: Tokens.rowGap) {
                HStack {
                    Text("노트")
                }
            }
        }
        .onAppear {
            noteDraft = clip.memo ?? ""
        }
    }
}
SWIFT

python3 scripts/apply_clipinbox_metadata_engine.py "$TMP/repo" --skip-xcodegen >/dev/null
python3 scripts/apply_clipinbox_metadata_engine.py "$TMP/repo" --skip-xcodegen >/dev/null

grep -q 'CLIPINBOX_URL_METADATA_ENGINE_V1' "$TMP/repo/ios/ClipInbox/App/ClipInboxApp.swift"
grep -q 'CLIPINBOX_URL_METADATA_ENGINE_V1' "$TMP/repo/ios/ClipInbox/Views/ClipCardView.swift"
grep -q 'CLIPINBOX_URL_METADATA_ENGINE_V1' "$TMP/repo/ios/ClipInbox/Views/DetailView.swift"
test -f "$TMP/repo/ios/ClipInbox/MetadataEngine/Core/URLMetadataEngine.swift"
test -f "$TMP/repo/ios/ClipInboxTests/MetadataEngine/GenericPipelineTests.swift"

printf '%s\n' '[verify] all checks passed'
