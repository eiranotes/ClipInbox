#!/usr/bin/env python3
"""Apply the Clip Inbox URL-only metadata engine overlay to a ClipInbox checkout.

The script is intentionally dependency-free and idempotent. It:
1. validates the target checkout,
2. creates a timestamped backup of files it edits,
3. copies the metadata engine, iOS integration, fixtures and tests,
4. patches app startup, card presentation and detail presentation,
5. regenerates the Xcode project when XcodeGen is available.
"""

from __future__ import annotations

import argparse
import datetime as dt
import difflib
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Callable

OVERLAY_ROOT = Path(__file__).resolve().parents[1]
MARKER = "CLIPINBOX_URL_METADATA_ENGINE_V1"


class ApplyError(RuntimeError):
    pass


def log(message: str) -> None:
    print(f"[clip-metadata] {message}")


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ApplyError(message)


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise ApplyError(f"{label}: expected exactly one match, found {count}")
    return text.replace(old, new, 1)


def regex_once(text: str, pattern: str, replacement: str | Callable[[re.Match[str]], str], label: str) -> str:
    value, count = re.subn(pattern, replacement, text, count=1, flags=re.MULTILINE | re.DOTALL)
    if count != 1:
        raise ApplyError(f"{label}: expected exactly one match, found {count}")
    return value


def backup_file(path: Path, root: Path, backup_root: Path) -> None:
    if not path.exists():
        return
    relative = path.relative_to(root)
    destination = backup_root / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)


def copy_tree(source: Path, destination: Path, dry_run: bool) -> list[Path]:
    copied: list[Path] = []
    for source_file in sorted(source.rglob("*")):
        if not source_file.is_file():
            continue
        relative = source_file.relative_to(source)
        destination_file = destination / relative
        copied.append(destination_file)
        if dry_run:
            continue
        destination_file.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_file, destination_file)
    return copied


def patch_clip_inbox_app(text: str) -> str:
    if MARKER in text:
        return text

    text = regex_once(
        text,
        r"^(?P<indent>[ \t]*)@State\s+private\s+var\s+lock\s*=\s*AppLockController\(\)[ \t]*$",
        lambda match: (
            f"{match.group('indent')}@State private var lock = AppLockController()\n"
            f"{match.group('indent')}// {MARKER}\n"
            f"{match.group('indent')}@State private var metadata = URLMetadataCoordinator()"
        ),
        "ClipInboxApp metadata state",
    )
    text = regex_once(
        text,
        r"^(?P<indent>[ \t]*)\.environment\(lock\)[ \t]*$",
        lambda match: (
            f"{match.group('indent')}.environment(lock)\n"
            f"{match.group('indent')}.environment(metadata)"
        ),
        "ClipInboxApp environment",
    )
    text = regex_once(
        text,
        r"^(?P<indent>[ \t]*)store\.importSharedClips\(\)[ \t]*$",
        lambda match: (
            f"{match.group('indent')}store.importSharedClips()\n"
            f"{match.group('indent')}metadata.synchronize(store: store)"
        ),
        "ClipInboxApp initial synchronization",
    )

    def active_replacement(match: re.Match[str]) -> str:
        indent = match.group("indent")
        return (
            f"{indent}if phase == .active {{\n"
            f"{indent}    store.importSharedClips()\n"
            f"{indent}    metadata.synchronize(store: store)\n"
            f"{indent}}}"
        )

    text = regex_once(
        text,
        r"(?P<indent>^[ \t]*)if\s+phase\s*==\s*\.active\s*\{\s*store\.importSharedClips\(\)\s*\}",
        active_replacement,
        "ClipInboxApp foreground synchronization",
    )
    return text


def patch_clip_card(text: str) -> str:
    if MARKER in text:
        return text

    if text.startswith("import SwiftUI") and "import Foundation" not in text.splitlines()[:4]:
        text = text.replace("import SwiftUI", "import Foundation\nimport SwiftUI", 1)

    text = regex_once(
        text,
        r"^(?P<indent>[ \t]*)struct\s+ClipCardView:\s*View\s*\{[ \t]*$",
        lambda match: (
            f"{match.group('indent')}struct ClipCardView: View {{\n"
            f"{match.group('indent')}    // {MARKER}\n"
            f"{match.group('indent')}    @Environment(URLMetadataCoordinator.self) private var metadata"
        ),
        "ClipCardView environment",
    )
    text = regex_once(
        text,
        r"^(?P<indent>[ \t]*)struct\s+CompactResultRow:\s*View\s*\{[ \t]*$",
        lambda match: (
            f"{match.group('indent')}struct CompactResultRow: View {{\n"
            f"{match.group('indent')}    @Environment(URLMetadataCoordinator.self) private var metadata"
        ),
        "CompactResultRow environment",
    )

    text = text.replace(
        "L10n.text(clip.title, locale: locale)",
        "L10n.text(metadata.cardPresentation(for: clip)?.title ?? clip.title, locale: locale)",
    )
    text = text.replace(
        "L10n.text(clip.source, locale: locale)",
        "L10n.text(metadata.cardPresentation(for: clip)?.subtitle ?? clip.source, locale: locale)",
    )

    main_pattern = r"(?P<indent>^[ \t]*)if\s+clip\.hasImageReference\s*\{\s*ClipThumbnail\(clip:\s*clip,\s*compact:\s*true\)\s*\.frame\(width:\s*Tokens\.clipThumbnailWidth,\s*height:\s*Tokens\.clipThumbnailHeight\)\s*\.fixedSize\(\)\s*\}"

    def main_image(match: re.Match[str]) -> str:
        indent = match.group("indent")
        return (
            f"{indent}if clip.hasImageReference {{\n"
            f"{indent}    ClipThumbnail(clip: clip, compact: true)\n"
            f"{indent}        .frame(width: Tokens.clipThumbnailWidth, height: Tokens.clipThumbnailHeight)\n"
            f"{indent}        .fixedSize()\n"
            f"{indent}}} else if let thumbnailURL = metadata.cardPresentation(for: clip)?.thumbnailURL.flatMap(URL.init(string:)) {{\n"
            f"{indent}    MetadataRemoteImage(url: thumbnailURL)\n"
            f"{indent}        .frame(width: Tokens.clipThumbnailWidth, height: Tokens.clipThumbnailHeight)\n"
            f"{indent}        .fixedSize()\n"
            f"{indent}}}"
        )

    text = regex_once(text, main_pattern, main_image, "ClipCardView remote thumbnail")

    compact_pattern = r"(?P<indent>^[ \t]*)if\s+clip\.hasImageReference\s*\{\s*ClipThumbnail\(clip:\s*clip,\s*compact:\s*true\)\s*\.frame\(width:\s*Tokens\.resultThumbnailWidth,\s*height:\s*Tokens\.resultThumbnailHeight\)\s*\}"

    def compact_image(match: re.Match[str]) -> str:
        indent = match.group("indent")
        return (
            f"{indent}if clip.hasImageReference {{\n"
            f"{indent}    ClipThumbnail(clip: clip, compact: true)\n"
            f"{indent}        .frame(width: Tokens.resultThumbnailWidth, height: Tokens.resultThumbnailHeight)\n"
            f"{indent}}} else if let thumbnailURL = metadata.cardPresentation(for: clip)?.thumbnailURL.flatMap(URL.init(string:)) {{\n"
            f"{indent}    MetadataRemoteImage(url: thumbnailURL)\n"
            f"{indent}        .frame(width: Tokens.resultThumbnailWidth, height: Tokens.resultThumbnailHeight)\n"
            f"{indent}}}"
        )

    text = regex_once(text, compact_pattern, compact_image, "CompactResultRow remote thumbnail")
    return text


def patch_detail_view(text: str) -> str:
    if MARKER in text:
        return text

    text = regex_once(
        text,
        r"^(?P<structIndent>[ \t]*)struct\s+DetailView:\s*View\s*\{[ \t]*\n(?P<propertyIndent>[ \t]*)@Environment\(AppStore\.self\)\s+private\s+var\s+store[ \t]*$",
        lambda match: (
            f"{match.group('structIndent')}struct DetailView: View {{\n"
            f"{match.group('propertyIndent')}@Environment(AppStore.self) private var store\n"
            f"{match.group('propertyIndent')}// {MARKER}\n"
            f"{match.group('propertyIndent')}@Environment(URLMetadataCoordinator.self) private var metadata"
        ),
        "DetailView environment",
    )
    text = text.replace(
        "L10n.text(clip.title, locale: locale)",
        "L10n.text(metadata.cardPresentation(for: clip)?.title ?? clip.title, locale: locale)",
        1,
    )
    text = text.replace(
        "L10n.text(clip.source, locale: locale)",
        "L10n.text(metadata.cardPresentation(for: clip)?.subtitle ?? clip.source, locale: locale)",
        1,
    )

    image_pattern = (
        r"(?P<indent>^[ \t]*)if\s+clip\.hasImageReference\s*\{"
        r"(?P<body>.*?\.accessibilityLabel\(\"이미지 크게 보기\"\)\s*)"
        r"\}"
    )

    def detail_image(match: re.Match[str]) -> str:
        indent = match.group("indent")
        body = match.group("body").rstrip()
        return (
            f"{indent}if clip.hasImageReference {{{body}\n"
            f"{indent}}} else if let thumbnailURL = metadata.cardPresentation(for: clip)?.thumbnailURL.flatMap(URL.init(string:)) {{\n"
            f"{indent}    MetadataRemoteImage(url: thumbnailURL, contentMode: .fit)\n"
            f"{indent}        .frame(maxWidth: .infinity)\n"
            f"{indent}        .frame(height: dynamicTypeSize.isAccessibilitySize\n"
            f"{indent}            ? Tokens.detailImageHeight * 1.6\n"
            f"{indent}            : Tokens.detailImageHeight)\n"
            f"{indent}}}"
        )

    text = regex_once(text, image_pattern, detail_image, "DetailView remote thumbnail")

    sections_pattern = (
        r"(?P<indent>^[ \t]*)\}\s*\n"
        r"(?P=indent)\.frame\(maxWidth:\s*\.infinity,\s*alignment:\s*\.leading\)\s*\n\s*"
        r"(?P=indent)VStack\(alignment:\s*\.leading,\s*spacing:\s*Tokens\.rowGap\)\s*\{\s*\n"
        r"(?P=indent)\s*HStack\s*\{\s*\n"
        r"(?P=indent)\s*Text\(\"노트\"\)"
    )

    def sections_replacement(match: re.Match[str]) -> str:
        indent = match.group("indent")
        return (
            f"{indent}}}\n"
            f"{indent}.frame(maxWidth: .infinity, alignment: .leading)\n\n"
            f"{indent}MetadataDetailSectionsView(clip: clip)\n\n"
            f"{indent}VStack(alignment: .leading, spacing: Tokens.rowGap) {{\n"
            f"{indent}    HStack {{\n"
            f"{indent}        Text(\"노트\")"
        )

    text = regex_once(text, sections_pattern, sections_replacement, "DetailView metadata sections")

    text = regex_once(
        text,
        r"(?P<indent>^[ \t]*)\.onAppear\s*\{\s*\n(?P=indent)\s*noteDraft\s*=\s*clip\.memo\s*\?\?\s*\"\"",
        lambda match: (
            f"{match.group('indent')}.task(id: clip.url) {{\n"
            f"{match.group('indent')}    if metadata.result(for: clip.id) == nil {{\n"
            f"{match.group('indent')}        await metadata.analyze(clip: clip, store: store, forceRefresh: false)\n"
            f"{match.group('indent')}    }}\n"
            f"{match.group('indent')}}}\n"
            f"{match.group('indent')}.onAppear {{\n"
            f"{match.group('indent')}    noteDraft = clip.memo ?? \"\""
        ),
        "DetailView analysis task",
    )
    return text


def format_diff(before: str, after: str, path: Path) -> str:
    return "".join(
        difflib.unified_diff(
            before.splitlines(keepends=True),
            after.splitlines(keepends=True),
            fromfile=f"a/{path.as_posix()}",
            tofile=f"b/{path.as_posix()}",
        )
    )


def run_command(command: list[str], cwd: Path) -> None:
    log("running: " + " ".join(command))
    subprocess.run(command, cwd=cwd, check=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path, help="Path to the ClipInbox repository checkout")
    parser.add_argument("--dry-run", action="store_true", help="Print validation and diffs without writing")
    parser.add_argument("--no-ui-patch", action="store_true", help="Copy the engine but do not patch app/card/detail UI")
    parser.add_argument("--skip-tests", action="store_true", help="Do not copy fixture/unit tests")
    parser.add_argument("--skip-xcodegen", action="store_true", help="Do not run xcodegen even if available")
    parser.add_argument("--require-xcodegen", action="store_true", help="Fail if xcodegen is unavailable")
    args = parser.parse_args()

    root = args.repo.expanduser().resolve()
    ios_root = root / "ios"
    require((ios_root / "project.yml").exists(), f"not a ClipInbox checkout: {ios_root / 'project.yml'} is missing")
    require((ios_root / "ClipInbox").is_dir(), f"missing app source directory: {ios_root / 'ClipInbox'}")

    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_root = root / ".clipinbox-metadata-backup" / timestamp

    overlay_app = OVERLAY_ROOT / "ios" / "ClipInbox" / "MetadataEngine"
    target_app = ios_root / "ClipInbox" / "MetadataEngine"
    require(overlay_app.exists(), f"overlay source is missing: {overlay_app}")

    copied = copy_tree(overlay_app, target_app, args.dry_run)
    log(f"metadata engine files: {len(copied)}")

    if not args.skip_tests:
        overlay_tests = OVERLAY_ROOT / "ios" / "ClipInboxTests" / "MetadataEngine"
        target_tests = ios_root / "ClipInboxTests" / "MetadataEngine"
        copied_tests = copy_tree(overlay_tests, target_tests, args.dry_run)
        log(f"test/fixture files: {len(copied_tests)}")
        if not args.dry_run:
            for test_file in target_tests.glob("*.swift"):
                value = read_text(test_file).replace("@testable import ClipInboxMetadata", "@testable import ClipInbox")
                write_text(test_file, value)

    patches: list[tuple[Path, Callable[[str], str]]] = []
    if not args.no_ui_patch:
        patches = [
            (ios_root / "ClipInbox" / "App" / "ClipInboxApp.swift", patch_clip_inbox_app),
            (ios_root / "ClipInbox" / "Views" / "ClipCardView.swift", patch_clip_card),
            (ios_root / "ClipInbox" / "Views" / "DetailView.swift", patch_detail_view),
        ]

    for path, patcher in patches:
        require(path.exists(), f"required integration file is missing: {path}")
        before = read_text(path)
        after = patcher(before)
        if before == after:
            log(f"already integrated: {path.relative_to(root)}")
            continue
        if args.dry_run:
            print(format_diff(before, after, path.relative_to(root)))
            continue
        backup_file(path, root, backup_root)
        write_text(path, after)
        log(f"patched: {path.relative_to(root)}")

    if args.dry_run:
        log("dry run completed; no files were written")
        return 0

    manifest = backup_root / "APPLY_MANIFEST.txt"
    manifest.parent.mkdir(parents=True, exist_ok=True)
    manifest.write_text(
        "Clip Inbox URL metadata engine overlay\n"
        f"Applied at: {dt.datetime.now(dt.timezone.utc).isoformat()}\n"
        f"Overlay: {OVERLAY_ROOT}\n"
        f"Target: {root}\n",
        encoding="utf-8",
    )

    xcodegen = shutil.which("xcodegen")
    if args.require_xcodegen and not xcodegen:
        raise ApplyError("xcodegen is required but was not found in PATH")
    if not args.skip_xcodegen and xcodegen:
        run_command([xcodegen, "generate"], ios_root)
    elif not args.skip_xcodegen:
        log("xcodegen not found; run `cd ios && xcodegen generate` before opening the generated project")

    log(f"backup: {backup_root}")
    log("application completed")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ApplyError as error:
        print(f"[clip-metadata] ERROR: {error}", file=sys.stderr)
        raise SystemExit(2)
    except subprocess.CalledProcessError as error:
        print(f"[clip-metadata] ERROR: command failed with exit code {error.returncode}", file=sys.stderr)
        raise SystemExit(error.returncode)
