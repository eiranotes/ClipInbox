# Clip Inbox URL-only Metadata Engine

이 디렉터리는 `eiranotes/ClipInbox`에 적용할 수 있는 URL 단독 메타데이터 수집·요약 엔진 완성 오버레이입니다.

입력은 HTTP/HTTPS URL 문자열 하나뿐이며, 플랫폼 API·비공개 endpoint·외부 크롤링 서비스·외부 LLM을 사용하지 않습니다. 입력 URL의 redirect, HTTP 응답, HTML head, JSON-LD/Microdata/RDFa, 의미 기반 DOM, HTML 내부 embedded state, 선택적 로컬 `WKWebView`, 직접 파일만 분석합니다.

## 포함된 산출물

- Swift 코어 엔진과 데이터 모델
- URL 정규화·HTTP 제한·redirect 처리
- Head/OG/Twitter/citation/DC/Microdata/RDFa 파서
- JSON-LD 배열 및 `@graph` 재귀 파서
- semantic DOM 및 embedded state 파서
- YouTube·GitHub 등 플랫폼 Adapter registry
- 직접 PDF·이미지·텍스트·오디오·영상 파일 처리
- 출처·신뢰도 기반 field resolver
- 외부 LLM 없는 결정적 summary builder
- 메인 카드·상세화면 presentation builder
- iOS sidecar 저장소, 비동기 coordinator, `WKWebView` renderer, SwiftUI 표시 컴포넌트
- fixture 기반 XCTest 28개
- 실제 ClipInbox 체크아웃에 적용하는 멱등 패치 스크립트
- 설계·지원 범위·제한·backfill·Adapter 추가 문서

## 빠른 적용

```bash
unzip ClipInbox-URLMetadataEngine-implementation.zip
cd ClipInbox-URLMetadataEngine-implementation
python3 scripts/apply_clipinbox_metadata_engine.py /path/to/ClipInbox
```

스크립트는 다음을 수행합니다.

1. `ios/project.yml`과 앱 소스 구조를 검증합니다.
2. 기존 수정 파일을 `.clipinbox-metadata-backup/<UTC timestamp>/`에 백업합니다.
3. 엔진·iOS 통합·테스트·fixture를 복사합니다.
4. `ClipInboxApp.swift`, `ClipCardView.swift`, `DetailView.swift`를 멱등적으로 패치합니다.
5. `xcodegen`이 설치되어 있으면 `ios/project.yml`에서 Xcode 프로젝트를 다시 생성합니다.

먼저 차이만 확인하려면 다음 명령을 사용합니다.

```bash
python3 scripts/apply_clipinbox_metadata_engine.py /path/to/ClipInbox --dry-run
```

## 코어 검증

```bash
swift test
```

모든 검증을 한 번에 실행하려면 다음을 사용합니다.

```bash
bash scripts/verify_implementation.sh
```

Linux 환경에서는 Foundation 기반 코어와 fixture 테스트를 검증합니다. `WKWebView` 및 실제 iOS 앱 빌드는 macOS/Xcode에서 확인해야 합니다.

## 문서

- [`docs/00_REQUIREMENTS_TRACEABILITY.md`](docs/00_REQUIREMENTS_TRACEABILITY.md)
- [`docs/01_IMPLEMENTATION_PLAN.md`](docs/01_IMPLEMENTATION_PLAN.md)
- [`docs/02_ARCHITECTURE.md`](docs/02_ARCHITECTURE.md)
- [`docs/03_SUPPORT_MATRIX.md`](docs/03_SUPPORT_MATRIX.md)
- [`docs/04_BUILD_TEST_BACKFILL.md`](docs/04_BUILD_TEST_BACKFILL.md)
- [`docs/05_ADAPTER_GUIDE.md`](docs/05_ADAPTER_GUIDE.md)
- [`docs/06_LIMITATIONS.md`](docs/06_LIMITATIONS.md)
- [`docs/07_FILES_CHANGED.md`](docs/07_FILES_CHANGED.md)
- [`docs/08_TEST_REPORT.md`](docs/08_TEST_REPORT.md)
- [`docs/09_VERIFICATION_LOG.txt`](docs/09_VERIFICATION_LOG.txt)

## 핵심 통합 결정

기존 `Clip` JSON 형식과 사용자 편집값을 깨지 않기 위해 전체 추출 결과는 `link-metadata-v1.json` sidecar에 저장합니다. 기존 Clip의 제목·출처·설명은 자리표시자이거나 비어 있을 때만 보수적으로 갱신합니다. Share Extension은 링크를 즉시 저장하고 종료하며, 무거운 분석은 본 앱의 coordinator가 비동기로 수행합니다.

외부 Swift 패키지는 추가하지 않았습니다. HTML 파싱 범위를 이 요구사항에 맞춰 제한된 내부 파서로 구현해 바이너리 크기·라이선스·공급망 의존성을 늘리지 않았습니다.
