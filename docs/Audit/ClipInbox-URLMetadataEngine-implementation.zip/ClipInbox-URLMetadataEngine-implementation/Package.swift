// swift-tools-version: 5.10
import PackageDescription

let package = Package(
    name: "ClipInboxMetadata",
    platforms: [
        .macOS(.v13),
        .iOS(.v17)
    ],
    products: [
        .library(name: "ClipInboxMetadata", targets: ["ClipInboxMetadata"])
    ],
    targets: [
        .target(
            name: "ClipInboxMetadata",
            path: "ios/ClipInbox/MetadataEngine/Core"
        ),
        .testTarget(
            name: "ClipInboxMetadataTests",
            dependencies: ["ClipInboxMetadata"],
            path: "ios/ClipInboxTests/MetadataEngine",
            resources: [.process("Fixtures")]
        )
    ]
)
