# Clip Inbox URL 단독 메타데이터 엔진 — 구현 보고서

검증 기준일: 2026-07-12

## 1. 결과 요약

공개 URL 문자열 하나만 입력받아 링크를 즉시 보존한 뒤, 별도의 플랫폼 API·비공개 endpoint·외부 크롤링 서비스·외부 LLM 없이 공개 응답에서 메타데이터를 수집하는 Swift 구현을 완성했다.

산출물은 두 층으로 구성된다.

1. `ClipInboxMetadata` 독립 Swift Package: Linux/macOS에서 공통 코어와 fixture 테스트를 재현할 수 있다.
2. 기존 `eiranotes/ClipInbox` iOS 소스에 적용하는 오버레이: 메타데이터 코어, iOS sidecar 저장소, 비동기 coordinator, 비영구 `WKWebView` renderer, SwiftUI 카드·상세 표시, XCTest fixture를 복사하고 현재 UI 진입점 세 파일을 멱등적으로 패치한다.

기존 `Clip` JSON 스키마와 사용자가 편집한 제목·출처·설명을 보존하기 위해 전체 추출 결과는 Application Support의 `link-metadata-v1.json` sidecar에 저장한다. 기존 필드는 비어 있거나 알려진 자리표시자일 때만 보수적으로 갱신한다. Share Extension의 즉시 저장 흐름은 분석 완료를 기다리지 않는다.

## 2. 구현 범위

### 2.1 공통 파이프라인

```text
URL 문자열
→ URLNormalizer
→ URLSessionHTTPInspector
→ HeadMetadataParser
→ StructuredDataParser
→ SemanticDOMParser
→ EmbeddedStateParser
→ PlatformRegistry
→ 필요할 때만 OptionalWebViewRenderer 1회
→ FieldResolver
→ SummaryBuilder
→ PresentationBuilder
→ sidecar/cache 저장
```

- HTTP/HTTPS 검증, 인증정보 제거, fragment 분리, 추적 query 제거·정렬, 모바일 호스트 정규화
- redirect 최대 횟수·loop·비 HTTP 목적지 차단
- status/final URL/MIME/length/disposition/charset/language/filename 수집
- `<title>`, 일반 meta, canonical/alternate/icons, Open Graph, Twitter Card, article meta
- Highwire citation, Dublin Core/DCTERMS, Microdata, RDFa
- 모든 `application/ld+json` 블록 독립 파싱, 배열과 `@graph` 재귀 순회, 깨진 블록 격리
- `article → main → [role=main] → 텍스트 밀도 블록` 기반 의미 분석
- HTML 내부 Next/Nuxt/hydration/player/application JSON만 제한적으로 분석
- 직접 PDF·이미지·텍스트·오디오·영상·archive 처리
- 로그인·차단·삭제·부분 성공 상태 분리
- canonical URL 기반 memory/disk cache와 강제 재분석

### 2.2 필드 모델과 해석

모든 값은 `ExtractedField<T>`로 저장한다.

```swift
ExtractedField(
    value: value,
    source: .jsonLD,
    confidence: 0.94,
    rawValue: raw,
    extractedAt: date
)
```

지원 출처는 HTTP header, Open Graph, Twitter Card, JSON-LD, Microdata, RDFa, semantic DOM, embedded state, URL pattern, derived다. 제목·설명·작성자·날짜·이미지·태그마다 출처 우선순위를 적용하며, URL로 확정 가능한 플랫폼·콘텐츠 subtype은 불확실한 DOM 추정보다 우선한다.

조회 수·좋아요·댓글 수 등 동적 값은 `volatileAttributes`로 분리하고 메인 카드에는 사용하지 않는다. 원본 태그와 앱이 파생한 topic도 분리한다.

### 2.3 결정적 요약

외부 LLM을 사용하지 않는다.

- GitHub repository: About → README 첫 유효 문단
- 논문: abstract
- 기사: lead/excerpt → description
- SNS: 본문/caption → description
- 상품·앱·영상: 구조화 description → OG description
- 가입·로그인·쿠키·홍보 문구, URL 나열, hashtag, 제목 반복 제거
- `summaryShort` 60자 이하, `summaryDetail` 240자 이하
- 근거 원문이 부족하면 요약을 만들지 않음

### 2.4 플랫폼 Adapter

- YouTube: watch, youtu.be, Shorts, Live, Playlist, Channel; ID, channel, duration, thumbnail, keywords, embedded player state, 규칙 기반 대표 영상 유형
- GitHub: repository, issue, pull request, release, commit, discussion, gist, user/org; owner/repo/번호/상태/labels, About, README excerpt/headings, topics, primary language, license, archive, branch
- Reddit: post/subreddit/user, flair, NSFW 후보
- 네이버 블로그/포스트: desktop/mobile/wrapper, 명시된 content iframe 한 단계
- Tistory, Brunch, Velog, Naver/Daum news, Naver Cafe
- Instagram, Threads, X, TikTok, Facebook, LinkedIn, Pinterest: 공개 HTML과 URL pattern만; 로그인 wall은 우회하지 않음
- App Store, Google Play, Steam, Epic Games Store
- arXiv, DOI, PubMed, ACM, IEEE, Springer, ScienceDirect
- Stack Overflow, npm, PyPI, crates.io, Hugging Face, Docker Hub
- Notion, Google Docs/Sheets/Slides, Figma, Dropbox, OneDrive
- Vimeo, Twitch, SoundCloud, Spotify, Apple Music
- 주요 국내외 쇼핑 호스트와 generic Product/Offer

Adapter는 각각 `throws` 경계 안에서 실행되고, 실패는 extraction attempt에 기록한 뒤 generic 결과를 유지한다.

### 2.5 iOS 통합

- `LinkMetadataSidecarStore`: Clip ID와 source URL을 키로 전체 결과 저장
- `DiskMetadataCache`: canonical 결과 TTL cache
- `URLMetadataCoordinator`: 앱 활성화·공유 가져오기 이후 비동기 동기화, 중복 실행 방지, backfill, 재분석
- `WKWebViewMetadataRenderer`: `WKWebsiteDataStore.nonPersistent()`, Safari cookie 미사용, 같은 URL 한 번만 렌더링
- `AppStore+Metadata`: 사용자 편집값 보존형 merge
- `MetadataViews`: remote thumbnail, 동적 상세 section, 분석/재분석 상태
- `ClipInboxApp.swift`, `ClipCardView.swift`, `DetailView.swift`: 적용 스크립트가 marker 기반으로 패치

## 3. 주요 파일

```text
Package.swift
README_IMPLEMENTATION.md
IMPLEMENTATION_REPORT.md
scripts/
  apply_clipinbox_metadata_engine.py
  verify_implementation.sh
docs/
  00_REQUIREMENTS_TRACEABILITY.md
  01_IMPLEMENTATION_PLAN.md
  02_ARCHITECTURE.md
  03_SUPPORT_MATRIX.md
  04_BUILD_TEST_BACKFILL.md
  05_ADAPTER_GUIDE.md
  06_LIMITATIONS.md
  07_FILES_CHANGED.md
  08_TEST_REPORT.md
  09_VERIFICATION_LOG.txt
ios/ClipInbox/MetadataEngine/Core/
  *.swift
ios/ClipInbox/MetadataEngine/iOS/
  *.swift
ios/ClipInboxTests/MetadataEngine/
  *Tests.swift
  TestSupport.swift
  Fixtures/*.html
```

전체 파일 목록과 기존 프로젝트에서 수정되는 세 파일은 `docs/07_FILES_CHANGED.md`에 기록했다.

## 4. 자동 검증 결과

최종 명령:

```bash
bash scripts/verify_implementation.sh
```

결과:

```text
Executed 28 tests, with 0 failures (0 unexpected)
```

테스트 구성:

- `URLNormalizerTests`: 3
- `GenericPipelineTests`: 11
- `PlatformAdapterTests`: 8
- `RenderingFileAndStatusTests`: 6

추가 통과 항목:

- `swift build -c release`
- iOS 통합 Swift 파일 `swiftc -frontend -parse`
- 적용 스크립트 Python bytecode compile
- mock ClipInbox checkout 적용
- 같은 checkout에 두 번째 적용해 marker/idempotency 확인

검증 로그 원문은 `docs/09_VERIFICATION_LOG.txt`에 포함했다.

## 5. fixture 검증 범위

- 일반 기사: OG + JSON-LD + semantic DOM
- Open Graph 전용, Twitter Card 전용, JSON-LD 전용
- Microdata 전용, RDFa 전용
- 깨진 JSON-LD와 정상 블록 공존
- client-rendered fallback
- 한국어·영어·일본어, HTML entity, emoji
- YouTube embedded player state
- GitHub repository
- Reddit post/flair/NSFW
- 네이버 wrapper + 명시 iframe
- Instagram login-required 최소 결과
- App Store SoftwareApplication
- Product/Offer
- ScholarlyArticle/citation meta
- 로그인·삭제·차단 상태
- 직접 PDF·PNG·text payload
- redirect, cache, Adapter failure isolation

## 6. 적용 방법

### 6.1 현재 저장소에 적용 전 확인

```bash
python3 scripts/apply_clipinbox_metadata_engine.py /path/to/ClipInbox --dry-run
```

### 6.2 적용

```bash
python3 scripts/apply_clipinbox_metadata_engine.py /path/to/ClipInbox
```

스크립트 동작:

1. `ios/project.yml`과 예상 소스 파일을 검증한다.
2. 기존 수정 대상 파일을 `.clipinbox-metadata-backup/<UTC timestamp>/`에 백업한다.
3. 코어·iOS 통합·테스트·fixture를 복사한다.
4. 앱 시작, 카드, 상세 화면을 멱등적으로 패치한다.
5. `xcodegen`이 설치되어 있으면 프로젝트를 재생성한다.

옵션:

```text
--dry-run
--no-ui-patch
--skip-tests
--skip-xcodegen
--require-xcodegen
```

### 6.3 독립 코어 검증

```bash
swift test
swift build -c release
```

### 6.4 macOS/Xcode 최종 검증

```bash
cd /path/to/ClipInbox/ios
xcodegen generate
xcodebuild \
  -project ClipInbox.xcodeproj \
  -scheme ClipInbox \
  -destination 'platform=iOS Simulator,name=iPhone 16 Pro' \
  test
```

실제 simulator 이름은 설치된 Xcode runtime에 맞춰 조정한다.

## 7. 기존 링크 backfill

앱 coordinator는 다음 동작을 제공한다.

- 앱 활성화 시 메타데이터가 없거나 TTL이 지난 URL Clip만 분석
- 공유 import 직후 새 URL Clip 동기화
- `backfillAll(store:)`로 기존 저장 URL 전체 재생성
- 상세화면의 “링크 정보 다시 분석”으로 단일 Clip 강제 갱신

분석 실패는 기존 Clip 삭제·저장 실패로 연결되지 않으며 sidecar 결과만 partial/failed 상태로 기록된다.

## 8. 보안·네트워크 경계

- `file:`, `javascript:`, `data:` 및 비 HTTP/HTTPS 입력 거부
- URL user/password 제거
- redirect 목적지 scheme 재검증, loop/상한 적용
- ephemeral session, cookie storage 비활성화
- 응답 크기·시간·embedded state 보관 상한
- 파싱 중 script 실행 금지
- WKWebView만 격리된 JavaScript 실행 허용
- 로그 URL의 query 값과 인증정보 마스킹
- private JSON/GraphQL endpoint, 플랫폼 API, 검색 API, 외부 crawler/LLM 미사용

## 9. 외부 라이브러리

새 외부 dependency는 추가하지 않았다.

- 바이너리 크기와 공급망·라이선스 부담을 늘리지 않음
- Foundation 기반 제한적 HTML scanner로 요구된 meta/script/semantic 구조를 처리
- 향후 malformed HTML 정확도가 필요하면 parser protocol 뒤에 SwiftSoup 등의 구현을 교체할 수 있도록 모듈 경계를 유지

## 10. 알려진 제한

현재 실행 환경에는 Xcode, iOS SDK, WebKit runtime, XcodeGen이 없었다. 따라서 다음은 자동 검증에 포함되지 않았다.

- 전체 iOS target compile/link
- 실제 Share Extension → App Group import
- 실기기·simulator의 WKWebView timing과 ATS 동작
- SwiftUI 카드·상세 레이아웃 및 VoiceOver
- 실제 공개 사이트의 시점별 markup 변경

또한 명세에 열거된 모든 외부 서비스마다 10개 fixture를 각각 만든 것은 아니다. 우선 플랫폼과 공통 parser의 성공·실패 경로를 28개 테스트로 검증했고, fixture가 없는 서비스는 hostname/URL Adapter와 generic OG·JSON-LD·DOM fallback을 사용한다. 이 경계는 `docs/06_LIMITATIONS.md`에 명시했다.

## 11. 완료 판정 대응

- URL 문자열 하나로 분석 시작: 완료
- 플랫폼 API 키 불필요: 완료
- unknown site generic fallback: 완료
- YouTube/GitHub/article/product/scholarly 대표 필드: fixture 검증 완료
- SNS 차단 시 URL·플랫폼 최소 결과: 검증 완료
- 메인 카드 단순화/상세 동적 section: 구현 및 코어 presentation 검증 완료
- 저장과 분석 실패 분리: coordinator/sidecar 구조로 완료
- 모든 필드 provenance/confidence: 완료
- fixture 기반 무네트워크 회귀: 28개 통과
- 실제 iOS target/simulator/device: macOS/Xcode 검증 필요

