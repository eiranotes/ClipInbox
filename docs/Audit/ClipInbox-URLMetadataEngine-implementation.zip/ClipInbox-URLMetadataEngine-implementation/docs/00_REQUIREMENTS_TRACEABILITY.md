# 요구사항 추적표

업로드된 URL 단독 메타데이터 명세를 구현 파일·검증 항목에 연결한 표다. `완료`는 소스와 재현 가능한 코어 테스트가 있다는 뜻이며, `macOS 검증 필요`는 현재 실행 환경에 Xcode/iOS SDK/WebKit runtime이 없어 실제 앱 target 실행만 남았다는 뜻이다.

| 명세 영역 | 구현 위치 | 검증/상태 |
|---|---|---|
| URL 하나만 입력 | `URLMetadataEngine.analyze(_:)`, `URLNormalizer` | 완료 |
| 원본/정규화/resolved/canonical 분리 | `URLNormalizer`, `FieldResolver`, `LinkMetadataResult` | redirect/fragment/tracking XCTest |
| HTTP/redirect/header/charset/상태 | `URLSessionHTTPInspector` | mock HTTP/status/redirect + 크기/timeout 코드 |
| Head/OG/Twitter/article/citation/DC | `HeadMetadataParser` | OG-only, Twitter-only, article, scholarly fixture |
| JSON-LD 배열/`@graph`/깨진 블록 격리 | `StructuredDataParser` | JSON-LD-only + broken/valid coexist fixture |
| Microdata/RDFa | `HeadMetadataParser` | 각각 전용 fixture와 provenance assertion |
| 의미 기반 DOM | `SemanticDOMParser` | article/GitHub/Reddit/다국어 fixture |
| HTML 내부 embedded state만 분석 | `EmbeddedStateParser`, YouTube/GitHub Adapter | YouTube player state fixture |
| 필요할 때만 같은 URL WKWebView 1회 | `WKWebViewMetadataRenderer`, render heuristic | mock renderer 1회 XCTest; 실제 WebKit은 macOS 검증 필요 |
| 직접 PDF/이미지/text/audio/video | `FileMetadataParser` | PDF, PNG, text XCTest |
| 공통 parser 우선 + Adapter 실패 격리 | `PlatformRegistry`, `MetadataFragment.adapterFailures` | throw Adapter 뒤 generic fallback XCTest |
| YouTube | `YouTubeAdapter` | URL ID, channel, duration, thumbnail, genre, volatile count fixture |
| GitHub | `GitHubAdapter` | repository About/README/topics/language/license/branch fixture |
| Reddit | `RedditAdapter` | post/subreddit/flair/NSFW fixture |
| 네이버 블로그 | `NaverBlogAdapter` | wrapper + 명시 iframe 한 단계 fixture |
| 국내 발행/뉴스 | `KoreanPublishingAdapter` + 공통 parser | 구현; 서비스별 추가 fixture 권장 |
| Instagram/Threads/X/TikTok/Facebook/LinkedIn/Pinterest | `SocialPlatformAdapter` | Instagram login-required 최소 fallback fixture; 나머지는 URL pattern + 공통 fallback |
| 상품/앱/학술/개발/문서/미디어 | 구조화 parser + 그룹 Adapter | Product, App Store, Scholarly fixture; 나머지는 공통 fallback |
| 모든 필드 source/confidence | `ExtractedField<T>`, `FieldResolver` | 주요 fixture에서 source/confidence assertion |
| 동적 수치 분리 | `volatileAttributes` | YouTube view count assertion |
| 외부 LLM 없는 요약 | `SummaryBuilder` | short/detail 길이·원문 기반 assertion |
| 메인/상세 표현 | `PresentationBuilder`, `MetadataViews` | card/detail XCTest; 실제 SwiftUI layout은 macOS 검증 필요 |
| 저장과 분석 분리 | 기존 Share 저장 흐름 + `URLMetadataCoordinator` | 통합 소스와 patch script; 앱 런타임은 macOS 검증 필요 |
| 기존 Clip schema/사용자 편집 보존 | `LinkMetadataSidecarStore`, `AppStore+Metadata` | sidecar 설계 및 보수적 merge |
| cache/reanalyze/backfill | `MemoryMetadataCache`, disk cache, coordinator | cache XCTest + backfill API |
| 보안/민감 로그/비 HTTP 거부 | `URLNormalizer`, `URLSessionHTTPInspector` | unsafe URL/redacted log XCTest |
| fixture/네트워크/render/cache 테스트 | `ios/ClipInboxTests/MetadataEngine` | 28 tests, 실제 네트워크 미사용 |
| 현재 저장소 자동 통합 | `scripts/apply_clipinbox_metadata_engine.py` | mock checkout 적용 + 두 번째 적용 멱등 검증 |
| 빌드·실행·Adapter 추가·제한 문서 | `docs/` | 완료 |

## 의도적으로 남긴 경계

- 플랫폼 API, private JSON/GraphQL endpoint, external crawler/search/LLM은 사용하지 않는다.
- 로그인 wall·bot challenge를 우회하지 않는다.
- 익명 공개 페이지에서 보이지 않는 작성자·가격·기간·태그를 추측하지 않는다.
- 모든 열거 사이트마다 10개 fixture를 각각 만든 상태는 아니다. 우선 플랫폼과 공통 parser의 대표 경로를 검증했고, 나머지는 공통 fallback을 유지하면서 운영 fixture를 추가하는 구조다.
- 실제 ClipInbox iOS target build, Share Extension/App Group, WebKit timing, simulator/device UI는 macOS/Xcode에서 최종 확인해야 한다.
