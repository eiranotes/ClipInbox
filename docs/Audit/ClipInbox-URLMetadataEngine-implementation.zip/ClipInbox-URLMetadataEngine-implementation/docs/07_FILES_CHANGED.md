# 수정·추가 파일 목록

## 1. 적용 스크립트가 기존 ClipInbox에서 수정하는 파일

- `ios/ClipInbox/App/ClipInboxApp.swift`
  - `URLMetadataCoordinator` 생성 및 environment 주입
  - shared Clip import 뒤/앱 활성화 뒤 async synchronize
- `ios/ClipInbox/Views/ClipCardView.swift`
  - metadata card presentation 사용
  - 로컬 이미지가 없을 때 remote thumbnail 표시
- `ios/ClipInbox/Views/DetailView.swift`
  - metadata title/subtitle/remote image
  - 동적 detail sections와 다시 분석
  - 화면 진입 시 필요한 경우 분석

각 파일은 수정 전 timestamp backup이 만들어지고 marker 기반으로 두 번째 적용을 건너뜁니다.

## 2. 앱에 추가하는 코어 파일

```text
ios/ClipInbox/MetadataEngine/Core/
  EmbeddedStateParser.swift
  FieldResolver.swift
  FileMetadataParser.swift
  GitHubAdapter.swift
  HTMLUtilities.swift
  HTTPInspector.swift
  HeadMetadataParser.swift
  MetadataCache.swift
  MetadataFragment.swift
  MetadataModels.swift
  PlatformAdapter.swift
  PlatformAdapters.swift
  PresentationBuilder.swift
  RenderedPageParser.swift
  SemanticDOMParser.swift
  StructuredDataParser.swift
  SummaryBuilder.swift
  URLMetadataEngine.swift
  URLNormalizer.swift
  YouTubeAdapter.swift
```

## 3. 앱에 추가하는 iOS 통합 파일

```text
ios/ClipInbox/MetadataEngine/iOS/
  AppStore+Metadata.swift
  LinkMetadataSidecarStore.swift
  MetadataViews.swift
  URLMetadataCoordinator.swift
  WKWebViewMetadataRenderer.swift
```

## 4. 테스트와 fixture

```text
ios/ClipInboxTests/MetadataEngine/
  GenericPipelineTests.swift
  PlatformAdapterTests.swift
  RenderingFileAndStatusTests.swift
  TestSupport.swift
  URLNormalizerTests.swift
  Fixtures/*.html
```

적용할 때 test import는 독립 package의 `ClipInboxMetadata`에서 앱 target인 `ClipInbox`로 자동 변경됩니다.

## 5. 오버레이 도구와 문서

- `Package.swift`: 코어 독립 build/test
- `scripts/apply_clipinbox_metadata_engine.py`: 실제 checkout 적용
- `scripts/verify_implementation.sh`: 검증 자동화
- `docs/*.md`: 설계·지원·제한·운영·요구사항 추적 문서
- `docs/09_VERIFICATION_LOG.txt`: 최종 자동 검증 원문

## 6. 새 외부 라이브러리

없음.

- 추가 이유: 해당 없음
- 바이너리 크기 증가: 내부 소스 코드만 추가
- 라이선스: 외부 dependency 없음
- 유지보수: ClipInbox source tree 안에서 관리
- 대체 가능성: 향후 malformed HTML 정확도가 더 필요하면 SwiftSoup 같은 parser를 추상화 뒤 교체 가능하나, 현재는 package/license/size 의존성을 피함
