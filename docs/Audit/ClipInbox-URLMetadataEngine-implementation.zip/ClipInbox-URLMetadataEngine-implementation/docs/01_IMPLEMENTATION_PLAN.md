# 구현 계획 및 완료 상태

## 1. 목표

URL 문자열 하나만으로 링크 레코드를 먼저 저장하고, 공개 페이지에서 읽을 수 있는 정보만 비동기로 수집해 메인 카드와 상세화면에 반영한다. 분석 실패·차단·로그인 요구·삭제 상태는 링크 저장 성공과 분리한다.

## 2. 프로젝트 분석 결과에 따른 통합 전략

Clip Inbox는 Swift/SwiftUI 기반 iOS 앱, Share Extension, 로컬 JSON 저장, XcodeGen 프로젝트 정의를 사용한다. 기존 구조를 재작성하지 않고 다음 원칙으로 확장한다.

- Share Extension의 즉시 저장 경로는 유지한다.
- 본 앱 활성화 후 `URLMetadataCoordinator`가 저장된 링크를 비동기로 분석한다.
- 전체 결과는 기존 Clip schema와 분리된 sidecar에 저장한다.
- 기존 제목·출처·설명에 사용자가 입력한 값이 있으면 덮어쓰지 않는다.
- 카드와 상세화면은 presentation model만 사용하고 플랫폼별 attribute 구조에 직접 결합하지 않는다.
- XcodeGen의 디렉터리 단위 source 포함 방식을 활용해 새 Swift 파일을 자동 포함한다.

## 3. 단계별 계획과 결과

| 단계 | 계획 | 완료 결과 |
|---|---|---|
| 0. 저장소 분석 | 앱·Share Extension·Clip 모델·저장·UI·테스트·XcodeGen 확인 | 완료 |
| 1. 공통 엔진 | URL 정규화, redirect, HTTP, Head, JSON-LD, DOM, resolver, summary | 완료 |
| 2. 핵심 유형 | Article, Video, Product, Software, Scholarly, 직접 파일 | 완료 |
| 3. 우선 Adapter | YouTube, GitHub, Reddit, 네이버 블로그, 국내 발행 사이트 | 완료 |
| 4. 제한형 Adapter | Instagram, Threads, X, TikTok, Facebook, LinkedIn, Pinterest | 공개 HTML/URL 패턴 범위로 완료 |
| 5. iOS 통합 | sidecar, coordinator, WKWebView, 카드·상세 UI, backfill | 완료 |
| 6. 안정화 | fixture, mock network/render/cache, 실패 격리, 보안 제한 | 완료 |
| 7. 저장소 적용 | 백업·복사·UI patch·XcodeGen 실행 스크립트 | 완료 |
| 8. iOS 실기기 검증 | Xcode 빌드, 실제 사이트 샘플, 네트워크 프로파일링 | macOS/Xcode 환경에서 수행 필요 |

## 4. 구현 우선순위

### P0 — 링크 저장 안정성

- 분석 시작 전 Clip 저장을 끝낸다.
- 분석 실패가 기존 링크 삭제·저장 실패로 전파되지 않는다.
- URL 원문과 정규화·redirect·canonical 값을 분리한다.

### P1 — 일반 웹 fallback

- 특정 Adapter가 없어도 Head, JSON-LD, semantic DOM, HTML title, URL slug, domain 순으로 최소 결과를 만든다.
- Adapter 예외는 시도 로그에 남기되 generic 결과를 유지한다.

### P2 — 표현 일관성

- 모든 필드는 `value/source/confidence/rawValue/extractedAt`를 유지한다.
- 메인 카드는 제목·출처/작성자·유형·핵심값 하나만 표시한다.
- 상세화면은 값이 있는 섹션만 만든다.

### P3 — 비용·보안 제한

- redirect 5회, 요청 5초, 전체 12초, HTML 2 MiB, embedded state 512 KiB를 기본값으로 둔다.
- WKWebView는 정보가 부족할 때 같은 URL을 한 번만 익명 세션으로 렌더링한다.
- 쿠키·Safari 세션·OAuth·API 키를 사용하지 않는다.

## 5. 수용 기준 매핑

- URL 하나로 분석 시작: `URLMetadataEngine.analyze(_:)`
- API 키 불필요: URLSession/HTML/WKWebView만 사용
- 일반 페이지 fallback: 공통 parser stack
- YouTube: URL ID, OG, VideoObject, embedded player state
- GitHub: URL owner/repo, About, README, topics, language, license, branch
- 기사: headline/creator/date/lead/reading time
- 상품: Product/Offer 기반 name/image/brand/price/currency/availability
- 논문: citation/DC/ScholarlyArticle 기반 title/author/abstract/publication/DOI/PDF 후보
- 차단 SNS: platform, URL 식별자, content subtype, 상태 유지
- 카드/상세 분리: `PresentationBuilder`
- 저장/분석 분리: Share 저장 경로 + 본 앱 coordinator
- provenance: `ExtractedField<T>`
- 네트워크 없는 검증: fixture + mock inspector/renderer/cache
