# 테스트 보고서

검증일: 2026-07-12

## 1. 자동 테스트 결과

```text
Executed 28 tests, with 0 failures (0 unexpected)
```

테스트 suite:

- `URLNormalizerTests` — 3
- `GenericPipelineTests` — 11
- `PlatformAdapterTests` — 8
- `RenderingFileAndStatusTests` — 6

## 2. 검증 항목

### URL/보안

- `file:`, `javascript:`, `data:` 및 비 HTTP URL 거부
- 인증정보와 query 값을 숨긴 log URL
- tracking query 제거, query 정렬, fragment 별도 보존
- original/resolved/canonical URL 분리

### Generic parser

- Open Graph 전용, Twitter Card 전용, JSON-LD 전용 fallback
- Microdata 및 RDFa provenance
- JSON-LD title/creator 우선순위와 provenance
- OG image 우선순위
- Article section/word count/reading time
- 결정적 short/detail summary 길이
- 깨진 JSON-LD 격리
- 일본어, HTML entity, emoji
- Adapter throw 뒤 generic fallback

### Platform/type

- Reddit URL pattern + flair/NSFW 공개 DOM
- 네이버 블로그 wrapper가 명시한 iframe 1단계 분석
- 로그인 제한 Instagram URL 최소 식별자 유지
- App Store URL 분류 + SoftwareApplication JSON-LD
- YouTube URL ID + embedded player state + duration + channel + volatile view count
- GitHub owner/repo + About + README + topics + language + license + branch + presentation
- Product/Offer 가격·통화·브랜드·재고, 임의 숫자 비가격 처리
- Scholarly citation/JSON-LD title/author/abstract/DOI/publication/PDF URL

### Rendering/files/status/cache

- 직접 PNG dimensions/thumbnail 및 단일 요청 확인
- 직접 text file excerpt/summary/reading time
- client-rendered 페이지에서 renderer 한 번만 실행
- 직접 PDF file metadata/page candidate
- login/removed/blocked 상태 우선순위
- 네트워크 실패 후 URL pattern fallback
- 동일 URL 두 번째 분석의 cache hit

## 3. 추가 정적 검증

- `swift build -c release`
- `swiftc -frontend -parse ios/ClipInbox/MetadataEngine/iOS/*.swift`
- `python3 -m py_compile scripts/apply_clipinbox_metadata_engine.py`
- mock ClipInbox checkout에 적용 스크립트 실행
- 같은 checkout에 두 번째 실행해 marker/idempotency 확인

## 4. 미검증 범위

현재 실행 환경에 Xcode/iOS SDK/WebKit runtime이 없어 다음은 macOS에서 확인해야 합니다.

- 전체 ClipInbox iOS target compile/link
- Share Extension → App Group import 실동작
- 실제 WKWebView render timing
- SwiftUI card/detail layout과 accessibility
- 실사이트 응답 및 ATS/network behavior
