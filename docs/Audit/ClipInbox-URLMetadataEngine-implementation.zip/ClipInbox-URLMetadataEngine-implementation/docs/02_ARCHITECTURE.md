# 아키텍처

## 1. 상위 데이터 흐름

```text
Share Extension
  └─ URL Clip 즉시 저장
       └─ 본 앱 활성화
            └─ URLMetadataCoordinator
                 ├─ sidecar/cache 조회
                 └─ URLMetadataEngine
                      1. URLNormalizer
                      2. HTTPInspector
                      3. HeadMetadataParser
                      4. StructuredDataParser
                      5. SemanticDOMParser
                      6. EmbeddedStateParser
                      7. PlatformRegistry
                      8. Optional WKWebView render pass
                      9. FieldResolver
                     10. SummaryBuilder
                     11. PresentationBuilder
```

## 2. 모듈

### URLNormalizer

- HTTP/HTTPS만 허용
- user/password 제거
- fragment를 별도 보존
- 추적 query 제거 및 안정적 정렬
- 모바일 host alias 정규화
- redirect 목적지 재검증
- YouTube/GitHub/Reddit 등 URL 확정 식별자는 Adapter가 `urlPattern` 출처로 기록
- 로그용 URL은 query 값과 인증정보를 숨김

### URLSessionHTTPInspector

- ephemeral session, cookie storage 비활성화
- redirect 수·loop·scheme 검증
- 응답 크기 상한을 `Content-Length`와 스트리밍 누적 양쪽에서 확인
- Content-Type/charset/language/disposition/filename 추출
- 로그인·차단·삭제 상태 판별
- 일시적 네트워크 오류만 설정 횟수만큼 재시도

### Generic parsers

`HeadMetadataParser`는 title, description, author, keywords, canonical, alternate, favicon, Apple touch icon, Open Graph, Twitter Card, article meta, Highwire citation, Dublin Core, Microdata, RDFa를 읽는다.

`StructuredDataParser`는 각 `application/ld+json` 블록을 독립적으로 파싱하고 배열과 `@graph`를 재귀 순회한다. 깨진 블록 하나는 다른 블록을 폐기하지 않는다. 현재 URL/canonical/mainEntity 관계를 이용해 관련 객체 신뢰도를 조정한다.

`SemanticDOMParser`는 `article → main → [role=main] → 텍스트 밀도 블록` 순으로 본문 후보를 고르고, header/nav/footer/aside/광고/쿠키/로그인/추천/댓글/공유/숨김 요소를 제거한다. 영구 저장용 전체 본문 대신 제한된 excerpt와 글자 수·읽기 시간 후보만 만든다.

`EmbeddedStateParser`는 HTML에 이미 포함된 `__NEXT_DATA__`, Nuxt/hydration/player state, `application/json`, data attribute 후보만 읽는다. 스크립트를 실행하거나 별도 endpoint를 요청하지 않는다.

### PlatformRegistry

Adapter는 hostname/URL pattern으로 실행되며 공통 parser 결과를 보완한다. 각 Adapter는 `throws` 경계를 가지며 예외는 `adapterFailures`와 extraction attempt에 기록된다. 하나의 Adapter 실패가 전체 분석 실패가 되지 않는다.

### FieldResolver

- title/description/creator/date/image/tag별 출처 우선순위 적용
- 플랫폼 URL pattern은 content type/subtype처럼 URL로 확정 가능한 분류에서 generic DOM 추정보다 우선
- 동일 attribute는 source rank와 confidence로 선택
- 이미지 URL 중복 제거 및 최대 5개 제한
- 원본 태그와 파생 topic 분리
- 조회수·좋아요 등 동적 값은 `volatileAttributes`로 분리
- status 우선순위: removed → blocked → loginRequired → status hint → complete/partial/failed

### SummaryBuilder

외부 LLM 없이 페이지 원문을 선택·정제·절단한다.

- 저장소: About → README 첫 유효 문단
- 논문: abstract
- 기사: lead/excerpt → description
- SNS: 본문/caption → description
- 상품/앱/영상: 구조화 description → OG description
- 로그인·쿠키·가입 문구, URL 나열, hashtag, 제목 반복 제거
- `summaryShort` 최대 60자, `summaryDetail` 최대 240자
- 원문이 부족하면 요약 필드를 만들지 않음

### iOS integration

`LinkMetadataSidecarStore`는 Clip ID와 원본 URL을 키로 전체 결과를 Application Support의 `link-metadata-v1.json`에 저장한다. canonical 결과 cache는 별도 `canonical-cache-v1.json`을 사용한다.

`URLMetadataCoordinator`는 앱 활성화/공유 가져오기 후 분석 대상을 동기화하고, 중복 실행을 막고, TTL 이후 재분석하며, 명시적 `backfillAll`과 강제 재분석을 제공한다.

`WKWebViewMetadataRenderer`는 `WKWebsiteDataStore.nonPersistent()`를 사용하고 Safari cookie를 주입하지 않는다. 같은 URL을 한 번 렌더링한 뒤 document URL/title/meta/JSON-LD/H1/main text/creator/date/image/language만 직렬화한다.

`AppStore+Metadata`는 사용자 편집값을 보존한다. 기존 값이 자리표시자이거나 비어 있을 때만 title/source/description을 반영한다.

## 3. 데이터 모델

`LinkMetadataResult`는 다음을 분리한다.

- URL: original/resolved/canonical/normalized/fragment
- 분류: platform/contentType/contentSubtype
- 공통 필드: title/description/summary/site/creator/date/image/tags/duration/reading
- 플랫폼 확장: `attributes`
- 동적 수치: `volatileAttributes`
- 상태와 HTTP inspection
- 단계별 `extractionAttempts`

모든 추출 필드는 다음 provenance를 가진다.

```swift
ExtractedField<T>(
    value: T,
    source: .jsonLD,
    confidence: 0.94,
    rawValue: ...,
    extractedAt: ...
)
```

## 4. 캐시

- 메모리 cache: 독립 코어 기본값
- 디스크 canonical cache: iOS coordinator 구성
- 원본/정규화/resolved/canonical URL을 cache key 후보로 저장
- 기본 TTL 7일
- `forceRefresh`로 우회
- Clip URL이 바뀌면 sidecar entry를 무효로 보고 재분석

## 5. 실패 처리

- 정규화 실패: failed result와 normalization attempt
- HTTP 실패: URL pattern Adapter로 최소 정보 생성 후 partial/failed
- parser 오류: parser/Adapter 경계에서 격리
- render 실패: 초기 HTTP 결과 유지
- sidecar 저장 실패: 화면 결과는 유지하고 coordinator `lastError`에 기록
- 분석 실패는 기존 Clip 저장 상태를 변경하지 않음
