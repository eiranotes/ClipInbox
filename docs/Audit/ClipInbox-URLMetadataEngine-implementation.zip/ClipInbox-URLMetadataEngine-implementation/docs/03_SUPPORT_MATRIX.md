# 지원 사이트 및 추출 필드 매트릭스

## 1. 모든 HTTP/HTTPS 페이지

| 계층 | 지원 |
|---|---|
| URL | original/resolved/canonical/normalized/fragment, redirect chain |
| HTTP | status, final URL, MIME, length, disposition, charset, language, filename |
| Head | title, description, author, keywords, canonical/alternate, icons |
| Social meta | Open Graph, Twitter Card, article meta |
| 학술 meta | Highwire citation, Dublin Core/DCTERMS |
| 구조화 데이터 | JSON-LD 배열/`@graph`, Microdata, RDFa |
| DOM | H1/headings, lead/excerpt, byline, dates, tags, images, text length, reading time |
| Embedded | HTML 내부 Next/Nuxt/hydration/player/application JSON |
| 상태 | complete/partial/blocked/loginRequired/removed/unsupported/failed |
| 표현 | main card, 값이 있는 section만 포함하는 detail model |

## 2. JSON-LD 우선 타입

Article, NewsArticle, BlogPosting, TechArticle, SocialMediaPosting, DiscussionForumPosting, VideoObject, AudioObject, Product, Offer, AggregateOffer, SoftwareApplication, MobileApplication, WebApplication, Recipe, Place, LocalBusiness, Event, ScholarlyArticle, Report, Book, ProfilePage, Person, Organization, BreadcrumbList.

## 3. 플랫폼 Adapter

| 그룹 | 호스트/형태 | URL/HTML 보완 필드 | 상태 |
|---|---|---|---|
| YouTube | youtube.com, youtu.be, watch/shorts/live/playlist/channel | video/channel/playlist ID, short/live/playlist, duration, keywords, thumbnail, embedded player fields, 규칙 기반 영상 유형 | 구현 + fixture |
| GitHub | repository, issue, PR, release, commit, discussion, gist, profile/org | owner/repo/number/state/labels, About, README excerpt/headings, topics, primary language, license, archive, branch | 구현 + repository fixture |
| Reddit | post/subreddit/user/redd.it | subreddit, post ID, username, flair, NSFW 후보 | 구현 + fixture |
| 네이버 블로그/포스트 | desktop/mobile/wrapper | blog ID, post ID, 명시적 content iframe 1단계 | 구현 + wrapper/content fixture |
| 국내 발행 | Tistory, Brunch, Velog, Naver/Daum news, Naver Cafe | platform/content subtype; 본문은 공통 parser | 구현 |
| SNS 제한형 | Instagram, Threads, X, TikTok, Facebook, LinkedIn, Pinterest | username/status/post/video/shortcode/pin ID, 공개 caption hashtag; 차단 시 최소 URL 정보 | 구현 + Instagram login fixture |
| 앱/게임 | App Store, Google Play, Steam, Epic Games Store | target platform, bundle ID 후보; SoftwareApplication 공통 필드 | 구현 + App Store fixture |
| 학술 | arXiv, DOI, PubMed, ACM, IEEE, Springer, ScienceDirect | paper type, arXiv ID/DOI; citation/JSON-LD 공통 필드 | 구현 + fixture |
| 개발 자료 | Stack Overflow, npm, PyPI, crates.io, Hugging Face, Docker Hub | platform/resource type; package/version/description은 공개 metadata | 구현 |
| 공개 문서 | Notion, Google Docs/Sheets/Slides, Figma, Dropbox, OneDrive | document subtype/service; 공개 metadata와 render fallback | 구현 |
| 영상/음악 | Vimeo, Twitch, SoundCloud, Spotify, Apple Music | media type/platform; OG/VideoObject/AudioObject | 구현 |
| 쇼핑 | SmartStore, Coupang, 11st, Gmarket, Auction, Musinsa, Ohouse, Amazon, AliExpress, Etsy | platform/product type; Product/Offer 가격·통화·브랜드·재고 | 구현 + generic product fixture |

## 4. 직접 파일

| 종류 | 추출 |
|---|---|
| PDF | 파일명, 크기, MIME, 확장자, 제한적 page count 후보 |
| PNG/JPEG/GIF/WebP | 파일명, MIME, 크기, 이미지 URL, PNG/JPEG dimensions |
| text/JSON/XML/Markdown/CSV/log | 제한 excerpt, 읽기 시간, 파일 정보 |
| audio/video | 파일 정보와 content type |
| archive/기타 binary | 파일명, MIME, 크기, archive subtype 후보 |

## 5. fixture 범위

- 일반 기사: OG + JSON-LD + semantic DOM
- Open Graph 전용, Twitter Card 전용, JSON-LD 전용
- Microdata 전용, RDFa 전용
- 깨진 JSON-LD와 정상 JSON-LD 공존
- client-rendered fallback
- 한국어·영어·일본어, HTML entity, emoji
- YouTube embedded player state
- GitHub repository
- Reddit post/flair/NSFW
- 네이버 wrapper + 명시적 content iframe
- Instagram login-required 최소 fallback
- App Store SoftwareApplication
- Product/Offer
- ScholarlyArticle/citation meta
- 로그인·삭제·mock 차단 상태
- 직접 PDF·PNG·text payload
- redirect chain, cache, adapter failure isolation

## 6. 지원 수준 해석

“구현”은 익명 공개 HTML에서 정보를 읽을 수 있을 때 동작한다는 뜻이다. 사이트가 로그인 wall, bot challenge, 지역 제한, 빈 client shell만 반환하면 우회하지 않고 `partial`, `blocked`, `loginRequired` 중 하나와 URL pattern 기반 최소 정보만 보존한다.
