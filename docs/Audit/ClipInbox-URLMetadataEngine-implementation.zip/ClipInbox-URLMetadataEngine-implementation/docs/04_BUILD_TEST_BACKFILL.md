# 빌드·적용·테스트·Backfill

## 1. 준비물

- ClipInbox 체크아웃
- Python 3.10 이상
- Swift 5.10 이상
- iOS 앱 빌드: macOS, 현재 ClipInbox가 요구하는 Xcode/iOS 17 SDK
- 프로젝트 재생성: XcodeGen 권장

외부 Swift package는 필요하지 않습니다.

## 2. 적용 전 확인

```bash
python3 scripts/apply_clipinbox_metadata_engine.py /path/to/ClipInbox --dry-run
```

UI patch 없이 엔진만 복사하려면 다음을 사용합니다.

```bash
python3 scripts/apply_clipinbox_metadata_engine.py /path/to/ClipInbox --no-ui-patch
```

## 3. 실제 적용

```bash
python3 scripts/apply_clipinbox_metadata_engine.py /path/to/ClipInbox
```

주요 option:

- `--skip-tests`: XCTest/fixture 미복사
- `--skip-xcodegen`: 자동 프로젝트 재생성 생략
- `--require-xcodegen`: XcodeGen이 없으면 실패

수정 전 파일은 다음에 백업됩니다.

```text
/path/to/ClipInbox/.clipinbox-metadata-backup/<UTC timestamp>/
```

## 4. Xcode 프로젝트

스크립트가 XcodeGen을 찾으면 자동 실행합니다. 직접 실행할 때는:

```bash
cd /path/to/ClipInbox/ios
xcodegen generate
open ClipInbox.xcodeproj
```

Xcode에서 `ClipInbox` scheme과 `ClipInboxTests`를 빌드·실행합니다.

## 5. 독립 코어 테스트

오버레이 루트에서:

```bash
swift test
```

테스트는 실제 네트워크를 사용하지 않고 fixture, `MockHTTPInspector`, `MockRenderer`, memory cache를 사용합니다.

```bash
bash scripts/verify_implementation.sh
```

검증 스크립트는 다음을 실행합니다.

1. Swift Package test
2. Swift core release build
3. iOS-only 파일 Swift syntax parse
4. Python integration script compile
5. 임시 mock ClipInbox checkout에 overlay 적용
6. 같은 checkout에 두 번째 적용하여 멱등성 확인

## 6. 앱 동작 확인 시나리오

1. Safari에서 공개 기사 URL을 Share Extension으로 저장합니다.
2. Share Extension이 즉시 닫히고 링크가 Inbox에 나타나는지 확인합니다.
3. 본 앱 활성화 후 카드 제목/출처/thumbnail이 갱신되는지 확인합니다.
4. 상세화면에서 summary, creator/date, type-specific attributes, URL/status가 값이 있는 경우만 표시되는지 확인합니다.
5. 로그인 요구 SNS 링크에서 Clip 자체는 남고 상태가 `로그인 필요` 또는 `일부 정보`인지 확인합니다.
6. “다시 분석”으로 `forceRefresh`가 동작하는지 확인합니다.

## 7. 기존 링크 Backfill

코디네이터에는 전체 링크를 순차 재분석하는 명시적 진입점이 포함됩니다.

```swift
Task {
    await metadata.backfillAll(store: store, forceRefresh: false)
}
```

- `false`: 유효한 cache/sidecar는 재사용
- `true`: 네트워크와 parser를 강제로 다시 실행
- 삭제된 Clip은 sidecar prune 대상
- URL이 변경된 Clip은 기존 entry를 재사용하지 않음

대량 backfill은 앱 foreground에서 순차 실행됩니다. 배터리·데이터 사용을 줄이려면 Wi-Fi/충전 상태 조건을 Settings 화면에서 추가해 이 method를 호출하는 것이 권장됩니다.

## 8. Sidecar migration

현재 engine version은 `1`입니다. 추후 data model 변경 시:

1. `engineVersion` 증가
2. `LinkMetadataSidecarStore` load 시 구버전 decode/migration 추가
3. migration 불가 entry만 삭제 후 backfill
4. 기존 Clip JSON schema는 그대로 유지

이 설계는 기존 백업/복원 형식을 메타데이터 엔진 변경과 분리합니다.
