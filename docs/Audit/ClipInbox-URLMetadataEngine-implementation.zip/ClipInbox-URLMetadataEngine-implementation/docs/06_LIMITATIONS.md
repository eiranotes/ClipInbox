# 알려진 제한사항

## 1. 공개 익명 페이지 경계

Instagram, Threads, X, TikTok, Facebook, LinkedIn, 일부 쇼핑몰·지도·공개 문서는 익명 요청에서 로그인 wall, bot challenge, 지역별 shell을 반환할 수 있습니다. 이 구현은 이를 우회하지 않습니다. URL pattern 기반 platform/ID/type과 접근 상태만 남길 수 있습니다.

## 2. HTML parser 범위

외부 HTML parser package를 추가하지 않고, 깨진 HTML을 허용하는 제한적 scanner/정규식 기반 parser를 구현했습니다. 일반적인 meta/script/semantic element에는 강하지만, 매우 비정상적인 quoting, template-generated tag, malformed nesting은 일부 놓칠 수 있습니다.

## 3. JavaScript rendering

- WKWebView render는 같은 URL에서 최대 한 번입니다.
- 비영구 data store를 사용하므로 Safari 로그인 상태를 공유하지 않습니다.
- 무한 scroll, 사용자 클릭, shadow DOM 내부, canvas에만 그려진 정보는 수집하지 않습니다.
- client app이 첫 render 후 늦게 데이터를 가져오는 경우 timeout 전에 노출되지 않을 수 있습니다.

## 4. 직접 파일

- PDF page count는 2 MiB 안의 단순 `/Pages /Count` 후보를 읽는 보수적 추정이며 완전한 PDF object/xref parser가 아닙니다.
- 암호화 PDF, object stream에만 count가 있는 PDF는 page count가 비어 있을 수 있습니다.
- JPEG/PNG dimension만 직접 파싱하며 EXIF, PDF 본문, Office 문서 내부 텍스트는 추출하지 않습니다.
- HTML 상한과 같은 2 MiB 응답 상한 때문에 큰 직접 파일은 `responseTooLarge`가 될 수 있습니다. 파일 metadata만 HEAD로 따로 수집하는 경로는 현재 없습니다.

## 5. 가격과 동적 값

가격은 Product/Offer/meta처럼 명시적 구조에서만 선택합니다. variant 선택, 회원가, 쿠폰가, 배송비는 기본 가격과 혼동하지 않기 위해 비어 있을 수 있습니다. 조회수·좋아요·별점 수·GitHub stars 등은 핵심 카드에 쓰지 않고 `volatileAttributes`로 분리합니다.

## 6. 언어·읽기 시간

언어는 HTML/meta/HTTP 후보를 사용하며 통계적 language detector는 포함하지 않았습니다. 읽기 시간은 제한된 excerpt/본문 후보를 기반으로 하므로 전체 기사 실제 시간과 차이가 날 수 있습니다.

## 7. 테스트와 실사이트

fixture 기반 코어 테스트는 재현 가능하게 통과하지만, 공개 사이트 markup은 변경됩니다. 릴리스 전 macOS/Xcode 환경에서 대표 실사이트 샘플과 실제 Share Extension 흐름을 추가 검증해야 합니다.

## 8. 현재 실행 환경 검증 범위

이 산출물은 Linux Swift toolchain에서 코어 build/test와 iOS 파일 syntax parse를 검증했습니다. 이 환경에는 Xcode, iOS SDK, WebKit runtime, XcodeGen이 없어 실제 iOS target compile·simulator/device 실행은 검증하지 못했습니다. 적용 스크립트는 해당 검증을 macOS checkout에서 재현하도록 준비되어 있습니다.

## 9. 플랫폼별 fixture 깊이

공통 파서와 우선 플랫폼의 대표 성공·실패 경로는 28개 XCTest로 검증합니다. 다만 요구사항에 열거된 모든 외부 서비스마다 10개 상태 fixture를 각각 보유한 것은 아닙니다. 현재 fixture가 없는 서비스는 hostname/URL Adapter와 공통 OG·JSON-LD·DOM fallback으로 지원되며, 실제 릴리스 운영에서는 수집 성공률 진단을 바탕으로 서비스별 fixture를 점진적으로 추가해야 합니다.
