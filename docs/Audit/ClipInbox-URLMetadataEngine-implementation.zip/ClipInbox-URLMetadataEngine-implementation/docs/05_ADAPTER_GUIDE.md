# 새 사이트 Adapter 추가 방법

## 1. Adapter가 필요한 경우

공통 Head/JSON-LD/DOM parser로 충분하지 않고, URL 구조로 확정할 수 있는 식별자 또는 공개 HTML의 안정적 의미 구조를 보완해야 할 때만 추가합니다. 단순 CSS selector를 대량 복제하는 용도로 사용하지 않습니다.

## 2. 구현 골격

```swift
struct ExampleAdapter: PlatformAdapter {
    let identifier = "example"

    func matches(_ url: URL) -> Bool {
        url.lowercasedHost == "example.com"
    }

    func extract(_ context: PlatformAdapterContext) throws -> MetadataFragment {
        var fragment = MetadataFragment()
        fragment.platformCandidates.append(
            .init(value: "Example", confidence: 1.0, source: .urlPattern)
        )

        // URL로 확정할 수 있는 값만 urlPattern 사용
        if let id = context.url.decodedPathComponents.last {
            fragment.addAttribute(
                "itemID",
                value: .string(id),
                source: .urlPattern,
                confidence: 1.0
            )
        }

        // HTML에 실제 포함된 값만 semanticDOM/embeddedState 사용
        if let document = context.document {
            // 제한적이고 실패 안전한 보완 parsing
        }
        return fragment
    }
}
```

그다음 `PlatformRegistry.defaultAdapters`에 등록합니다.

```swift
static let defaultAdapters: [any PlatformAdapter] = [
    ExampleAdapter(),
    // existing adapters...
]
```

## 3. 필수 규칙

- 입력 URL 또는 같은 콘텐츠를 명시하는 canonical/alternate/iframe 한 단계 외의 추가 crawl 금지
- 플랫폼 API, private JSON/GraphQL endpoint, raw mirror, external search 금지
- HTML script를 Swift parser에서 실행하지 않음
- embedded state는 HTML에 이미 포함된 데이터만 크기 제한 안에서 읽음
- URL에서 얻은 값은 `urlPattern`, 계산값은 `derived`
- 불확실한 작성자·가격·길이·날짜를 만들지 않음
- 동적 카운트는 `volatileAttributes`
- Adapter는 throw 가능하며 실패해도 generic fragment가 유지되어야 함
- 사용자 cookie/login session을 사용하지 않음

## 4. 테스트 추가

1. `ios/ClipInboxTests/MetadataEngine/Fixtures/example.html`
2. Adapter test에서 `MockHTTPInspector`로 fixture 전달
3. value뿐 아니라 source/confidence/content type/status 검증
4. Adapter가 throw하는 별도 test 또는 generic fallback test
5. CSS 구조를 일부 제거해도 OG/JSON-LD 최소 결과가 유지되는지 검증

권장 assertion:

```swift
XCTAssertEqual(result.attributes["itemID"]?.source, .urlPattern)
XCTAssertGreaterThanOrEqual(result.attributes["itemID"]?.confidence ?? 0, 0.9)
XCTAssertNotEqual(result.status, .failed)
```

## 5. Selector 안정성

- `itemprop`, `property`, `data-*`, `aria-*`, semantic element를 class보다 우선
- class selector가 필요하면 여러 후보를 작은 함수 안에 격리
- 첫 실패 시 빈 fragment를 반환하고 전체 engine을 실패시키지 않음
- selector 변경 감지는 fixture snapshot과 extraction attempt 진단으로 수행
